//
//  CustomKeyboard.swift
//  NumberKeyboardWithAlphabets
//
//  Created by Bigscal on 3/21/16.
//  Copyright © 2016 BigScal. All rights reserved.
//

import UIKit

protocol CustomKeyboardDelegate {
    func didTapButton(sender: UIButton)
}

class CustomKeyboard: UIView {
    
    @IBOutlet var btn1 : UIButton!
    @IBOutlet var btn2 : UIButton!
    @IBOutlet var btn3 : UIButton!
    @IBOutlet var btn4 : UIButton!
    @IBOutlet var btn5 : UIButton!
    @IBOutlet var btn6 : UIButton!
    @IBOutlet var btn7 : UIButton!
    @IBOutlet var btn8 : UIButton!
    @IBOutlet var btn9 : UIButton!
    @IBOutlet var btnDot : UIButton!
    @IBOutlet var btn0 : UIButton!
    @IBOutlet var btnC : UIButton!
    
    var textField: UITextField!
    
    var delegate: CustomKeyboardDelegate!
    
    override func awakeFromNib() {
        
    }
    
    @IBAction func btnTap(sender: UIButton)
    {
        delegate.didTapButton(sender)
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
