//
//  ViewController.swift
//  NumberKeyboardWithAlphabets
//
//  Created by Bigscal on 3/21/16.
//  Copyright © 2016 BigScal. All rights reserved.
//

import UIKit

var Timestamp: String {
    return "\(NSDate().timeIntervalSince1970 * 1000)"
}

class keyMetaData {
    
    var arrChar = NSArray()
    var currentCharIndex : Int = -1
    var keyTapTimeStamp = String()
    var tag : Int = -1
}

class ViewController: UIViewController, UITextFieldDelegate, CustomKeyboardDelegate {
    
    @IBOutlet var customView: UIView!
    @IBOutlet var txtField: UITextField!
    
    var mainArr : NSArray = NSArray(objects: "1","2ABC","3DEF","4GHI","5JKL","6MNO","7PQRS","8TUV","9WXYZ","0",".","-")
    var char : [String] = []
    
    var lastKeyTap : keyMetaData = keyMetaData()
    var currKeyTap : keyMetaData = keyMetaData()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.txtField.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
        let keyboard = NSBundle.mainBundle().loadNibNamed("CustomKeyboard", owner: self, options: nil)[0] as! CustomKeyboard
        keyboard.delegate = self
        keyboard.autoresizingMask = self.customView.autoresizingMask
        self.customView.addSubview(keyboard)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func didTapButton(sender: UIButton)
    {
        let currArr = self.getCharArrayFromString(self.mainArr.objectAtIndex(sender.tag) as! String)
        self.currKeyTap.arrChar = currArr
        self.currKeyTap.tag = sender.tag
        self.currKeyTap.keyTapTimeStamp = Timestamp
        
        if (self.currKeyTap.tag == self.lastKeyTap.tag)
        {
            if currKeyTap.tag == 11 {
                if self.char.count > 0 { self.char.removeLast() }
            }
            if(self.currKeyTap.tag == 10){
                
            } else {
                let diff = Double(self.currKeyTap.keyTapTimeStamp)! - Double(self.lastKeyTap.keyTapTimeStamp)!
                if diff <= 1000 {
                    if self.currKeyTap.currentCharIndex == self.currKeyTap.arrChar.count-1 {

                        self.currKeyTap.currentCharIndex = 0
                    }else{

                        self.currKeyTap.currentCharIndex++
                    }
                    let char = self.currKeyTap.arrChar[self.currKeyTap.currentCharIndex]
                    if self.char.count > 0 { self.char.removeLast() }
                    self.char.append(char as! String)
                } else {
                    self.char.append(self.currKeyTap.arrChar[0] as! String)
                }
            }
        }else if (self.currKeyTap.tag == 11) { // Tag - 11 for clear
            if self.char.count > 0 { self.char.removeLast() }
        }
        else if(self.currKeyTap.tag == 10){
            
        }else {
            let char = self.currKeyTap.arrChar[0]
            self.char.append(char as! String)
        }
        self.txtField.text = self.char.joinWithSeparator("")
        self.lastKeyTap  = keyMetaData()
        self.lastKeyTap.arrChar = self.currKeyTap.arrChar
        self.lastKeyTap.currentCharIndex = self.currKeyTap.currentCharIndex
        self.lastKeyTap.tag = self.currKeyTap.tag
        self.lastKeyTap.keyTapTimeStamp = self.currKeyTap.keyTapTimeStamp
    }
    
    func getCharArrayFromString(str: String) -> NSMutableArray
    {
        let charArray = NSMutableArray()
        for char in str.characters {
            charArray.addObject(String(char))
        }
        return charArray
    }
}
