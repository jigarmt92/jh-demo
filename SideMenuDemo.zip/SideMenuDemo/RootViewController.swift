//
//  RootViewController.swift
//  SideMenuDemo
//
//  Created by BIGSCAL on 1/2/16.
//  Copyright © 2016 BIGSCAL. All rights reserved.
//

import UIKit

class RootViewController: RESideMenu, RESideMenuDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func awakeFromNib() {
        
        self.contentViewController = self.storyboard!.instantiateViewControllerWithIdentifier("Nav") 
        self.leftMenuViewController = self.storyboard?.instantiateViewControllerWithIdentifier("left") as! LeftMenuViewController
     }

    func sideMenu(sideMenu: RESideMenu!, willShowMenuViewController menuViewController: UIViewController!) {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
