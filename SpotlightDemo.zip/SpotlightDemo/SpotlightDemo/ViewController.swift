//
//  ViewController.swift
//  SpotlightDemo
//
//  Created by Bigscal Mini on 03/05/16.
//  Copyright © 2016 Bigscal Mini. All rights reserved.
//

import UIKit
import CoreSpotlight
import MobileCoreServices

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    var listDic : NSMutableArray = NSMutableArray()
    //var headerArr : NSMutableArray = NSMutableArray()
    
    @IBOutlet var tblList : UITableView!
    var selectedMovieIndex: Int!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.loadData()
        self.navigationController?.navigationBar.translucent = true
        self.navigationController?.navigationBar.tintColor = UIColor.grayColor()
    
    }
    
    func loadData()
    {
        if let path = NSBundle.mainBundle().pathForResource("MovieData", ofType: "plist")
        {
            self.listDic =  NSMutableArray(contentsOfFile: path)! //NSMutableDictionary(contentsOfFile: path)!
        }
        
        /*if(self.listDic.count > 0)
        {
            self.headerArr.addObjectsFromArray(self.listDic.allKeys)
        }*/
        
        self.tblList.reloadData()
        self.setupSearchableContent()
    }
    
    /*func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.headerArr.count
    }*/
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //let arr = self.listDic.valueForKey(self.headerArr.objectAtIndex(section) as! String) as! NSMutableArray
        return self.listDic.count
    }
    
    /*func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.headerArr.objectAtIndex(section) as? String
    }*/
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .Default, reuseIdentifier: "Cell")
        cell.imageView?.image = UIImage(named: (self.listDic.objectAtIndex(indexPath.row).valueForKey("Image") as? String)!)
        //let arr = self.listDic.valueForKey(self.headerArr.objectAtIndex(indexPath.section) as! String) as! NSMutableArray
        cell.textLabel?.text = self.listDic.objectAtIndex(indexPath.row).valueForKey("Title") as? String
        //cell.textLabel?.text = arr.objectAtIndex(indexPath.row) as? String
        return cell
    }
    
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        //self.selectedMovieIndex = indexPath.row
        let detailVC = self.storyboard?.instantiateViewControllerWithIdentifier("DVC") as! DetailViewController
        detailVC.dic = (self.listDic.objectAtIndex(indexPath.row) as? NSMutableDictionary)!
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    // For SpotLight
    
    func setupSearchableContent()
    {
        var searchableItems = [CSSearchableItem]()
        
        for i in 0...(self.listDic.count - 1) {
            let movie = self.listDic[i] as! [String: String]
            
            let searchableItemAttributeSet = CSSearchableItemAttributeSet(itemContentType: kUTTypeText as String)
            
            // Set the title.
            searchableItemAttributeSet.title = movie["Title"]!
            
            // Set the movie image.
            //let imagePathParts = movie["Image"]!.componentsSeparatedByString(".")
            //print(NSBundle.mainBundle().URLForResource(imagePathParts[0], withExtension: imagePathParts[1]))
            //searchableItemAttributeSet.thumbnailURL = NSBundle.mainBundle().URLForResource(imagePathParts[0], withExtension: imagePathParts[1])
            
            let imageData : NSData = UIImagePNGRepresentation(UIImage(named: movie["Image"]!)!)!
            searchableItemAttributeSet.thumbnailData = imageData
            
            // Set the description.
            searchableItemAttributeSet.contentDescription = movie["Category"]!
            
            // Set keywords for searching
            var keywords = [String]()
            let movieCategories = movie["Category"]!.componentsSeparatedByString(", ")
            for movieCategory in movieCategories {
                keywords.append(movieCategory)
            }
            
            let stars = movie["Actor"]!.componentsSeparatedByString(", ")
            for star in stars {
                keywords.append(star)
            }

            searchableItemAttributeSet.keywords = keywords
            
            let searchableItem = CSSearchableItem(uniqueIdentifier: "com.appcoda.SpotIt.\(i)", domainIdentifier: "movies", attributeSet: searchableItemAttributeSet)
            
            searchableItems.append(searchableItem)
        }
        
        CSSearchableIndex.defaultSearchableIndex().indexSearchableItems(searchableItems) { (error) -> Void in
            if error != nil {
                print(error?.localizedDescription)
            }
        }
    }
    
    override func restoreUserActivityState(activity: NSUserActivity)
    {
        if activity.activityType == CSSearchableItemActionType
        {
            if let userInfo = activity.userInfo
            {
                let selectedMovie = userInfo[CSSearchableItemActivityIdentifier] as! String
                selectedMovieIndex = Int(selectedMovie.componentsSeparatedByString(".").last!)
                
                let detailVC = self.storyboard?.instantiateViewControllerWithIdentifier("DVC") as! DetailViewController
                detailVC.dic = (self.listDic.objectAtIndex(selectedMovieIndex) as? NSMutableDictionary)!
                self.navigationController?.pushViewController(detailVC, animated: true)
                
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

