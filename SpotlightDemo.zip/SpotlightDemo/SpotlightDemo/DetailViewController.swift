//
//  DetailViewController.swift
//  SpotlightDemo
//
//  Created by Bigscal Mini on 03/05/16.
//  Copyright © 2016 Bigscal Mini. All rights reserved.
//

import UIKit
import SafariServices

class DetailViewController: UIViewController, UITextFieldDelegate, SFSafariViewControllerDelegate {

    @IBOutlet var lblTitle : UILabel!
    @IBOutlet var lblCategory : UILabel!
    @IBOutlet var lblActor : UILabel!
    @IBOutlet var txt : UITextField!
    @IBOutlet var btn : UIButton!
    
    var dic : NSMutableDictionary = NSMutableDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(self.dic.count > 0)
        {
            self.lblActor.text = self.dic.valueForKey("Actor") as? String
            self.lblTitle.text = self.dic.valueForKey("Title") as? String
            self.lblCategory.text = self.dic.valueForKey("Category") as? String
            self.navigationItem.title = self.dic.valueForKey("Title") as? String
        }
        
        self.btn.frame = CGRectMake(70, 300, 100, 100)
        self.btn.setBackgroundImage(UIImage(named: "1024"), forState: UIControlState.Normal)
        self.btn.layer.borderWidth = 1
        self.btn.layer.masksToBounds = false
        self.btn.layer.borderColor = UIColor.blackColor().CGColor
        self.btn.layer.cornerRadius = self.btn.frame.height/2
        self.btn.clipsToBounds = true
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.txt.resignFirstResponder()
        return true
    }
    
    @IBAction func textFieldEditingChanged(sender: UITextField) {
        if sender.text?.characters.count == 4
        {
            view.endEditing(true)
        }
    }
    
    @IBAction func btnClick(sender : UIButton)
    {
        let safariVC = SFSafariViewController(URL: NSURL(string: "http://www.google.com")!)
        safariVC.delegate = self
        self.presentViewController(safariVC, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
