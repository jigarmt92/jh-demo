//
//  ViewController.swift
//  testCoredata
//
//  Created by Bigscal Mini on 09/06/16.
//  Copyright © 2016 Bigscal Mini. All rights reserved.
//

import UIKit
import CoreData
import MediaPlayer

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, AddRecordVCDelegate {
    
    @IBOutlet var tblList : UITableView!
    
    var objModel = [NSManagedObject]()

    override func viewDidLoad() {
        super.viewDidLoad()

        //let vc = self.storyboard?.instantiateViewControllerWithIdentifier("vc") as? SecondViewController
        //self.view.addSubview((vc?.view)!)
        //self.addChildViewController(vc!)
        
        let volumeView = MPVolumeView()
        if let view = volumeView.subviews.first as? UISlider{
            view.value = 0.1 //---0 t0 1.0---
            
        }
    
    }
    
    override func viewWillAppear(animated: Bool) {
        self.loadData()
        
        
    }
    
    func loadData()
    {
        let app = UIApplication.sharedApplication().delegate as! AppDelegate
        let context = app.managedObjectContext
        let fetchReq = NSFetchRequest(entityName: "Student")
        var fetchResult = [NSManagedObject]()
        
        let err : NSError! = nil
        do{
            fetchResult = try context.executeFetchRequest(fetchReq) as! [NSManagedObject]
            self.objModel = fetchResult
            self.tblList.reloadData()
            
        }
        catch{
            print(err)
        }
        
    }
    
    func cellHightWithMessage(message: NSString) -> CGFloat {
        
        let lSize = message.boundingRectWithSize(CGSizeMake(218, CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.UsesLineFragmentOrigin, attributes: nil, context: nil)
        let height = lSize.size.height
        return height
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.objModel.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell")
        cell.textLabel?.text = self.objModel[indexPath.row].valueForKey("fname") as? String
        return cell
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if(editingStyle == UITableViewCellEditingStyle.Delete)
        {
            let app = UIApplication.sharedApplication().delegate as? AppDelegate
            let context = app?.managedObjectContext
            context?.deleteObject(self.objModel[indexPath.row])
            let err : NSError! = nil
            do{
                try context!.save()
            }
            catch
            {
                print(err)
            }
            self.loadData()
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let vc = self.storyboard?.instantiateViewControllerWithIdentifier("AddVC") as! addRecordViewController
        vc.delegate = self
        vc.str = "update"
        vc.obj = indexPath
        vc.objDataModel = self.objModel
        vc.fname = self.objModel[indexPath.row].valueForKey("fname") as! String
        vc.lname = self.objModel[indexPath.row].valueForKey("lname") as! String
        self.navigationController?.pushViewController(vc, animated: true)
//        vc.modalTransitionStyle = UIModalTransitionStyle.FlipHorizontal
//        vc.modalPresentationStyle = UIModalPresentationStyle.FormSheet
//        vc.modalPresentationStyle = UIModalPresentationStyle.OverFullScreen
//        self.presentViewController(vc, animated: true, completion: nil)
    }
    
    func sendRecord(str: String) {
        print(str)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }


}

