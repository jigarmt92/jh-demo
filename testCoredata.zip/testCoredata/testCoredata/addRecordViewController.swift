//
//  addRecordViewController.swift
//  testCoredata
//
//  Created by Bigscal Mini on 09/06/16.
//  Copyright © 2016 Bigscal Mini. All rights reserved.
//

import UIKit
import CoreData

@objc protocol AddRecordVCDelegate
{
    func sendRecord(str : String)
}

class addRecordViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var txtFirstName : UITextField!
    @IBOutlet var txtLastName : UITextField!
    @IBOutlet var btnSubmit : UIButton!
    
    var objDataModel = [NSManagedObject]()
    var obj = NSIndexPath()
    var str = ""
    var fname = ""
    var lname = ""
    var delegate : AddRecordVCDelegate!

    let gradientLayer: CAGradientLayer = CAGradientLayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.callApi()
        //self.callPostApi()
        
        if(str == "update")
        {
            self.txtFirstName.text = fname
            self.txtLastName.text = lname
        }
        
        let validationErrorResponse = "{\"errors\": {\"name\": [\"a\", \"b\", \"c\"]}}"
        
        let data: NSData = validationErrorResponse.dataUsingEncoding(NSUTF8StringEncoding)!

        let dt = try! NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.AllowFragments)
        print(dt)
        
        let img = UIImage(named: "fb")
        let imgView = UIImageView(image: img)
        
        self.navigationItem.titleView = imgView
        
        let arr = ["Apple ", "Bike ", " Cat", " Dog "] as NSArray
        
        let trim = arr.map { $0.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()) }
        print(trim)
    
        let topColor = UIColor(red: 28/255.0, green: 25/255.0, blue: 127/255.0, alpha: 1)
        let bottomColor = UIColor(red: 0/255.0, green: 0/255.0, blue: 25/255.0, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        let gradientLocations: [Float] = [0.0, 1.0]
        
        
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations

        gradientLayer.frame = self.view.bounds

        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
        let timestamp = "2016-06-10"
        let formatter = NSDateFormatter()
//        formatter.timeZone = NSTimeZone(name: "UTC")
        formatter.dateFormat = "yyyy-MM-dd"
        let date = formatter.dateFromString(timestamp)
        formatter.dateFormat = "dd MMM, yyyy"
        let st = formatter.stringFromDate(date!)
        print(st)
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd MMM, yyyy"
        let myDate  = dateFormatter.dateFromString("2016-06-10")
        print(myDate)

    }
    
    override func viewDidLayoutSubviews() {
        gradientLayer.frame = self.view.bounds
    }

    
    func loadData()
    {
        let app = UIApplication.sharedApplication().delegate as! AppDelegate
        let context = app.managedObjectContext
        let fetchReq = NSFetchRequest(entityName: "Student")
        var fetchResult = [NSManagedObject]()
        
        let err : NSError! = nil
        do{
            fetchResult = try context.executeFetchRequest(fetchReq) as! [NSManagedObject]
            self.objDataModel = fetchResult
            
        }
        catch{
            print(err)
        }
        
    }

    
    // Submit button click event
    @IBAction func btnSubmitClick(sender : UIButton)
    {
        if((self.txtFirstName.text! as NSString).length > 0 || (self.txtLastName.text! as NSString).length > 0)
        {
            let app = UIApplication.sharedApplication().delegate as! AppDelegate
            let context = app.managedObjectContext
            
            if(str == "update")
            {
                // Custom delegate protocol
                self.delegate.sendRecord("Fire delegate method...!")
                
                let objModel = self.objDataModel[self.obj.row]
                objModel.setValue(self.txtFirstName.text, forKey: "fname")
                objModel.setValue(self.txtLastName.text, forKey: "lname")
               
                let err : NSError! = nil
                do
                {
                    try context.save()
                }
                catch
                {
                    print(err)
                }
            }
            else
            {
                let entity = NSEntityDescription.entityForName("Student", inManagedObjectContext: context)

                   let objModel = NSManagedObject(entity: entity!, insertIntoManagedObjectContext: context)
                    objModel.setValue(self.txtFirstName.text, forKey: "fname")
                    objModel.setValue(self.txtLastName.text, forKey: "lname")
                
                let err : NSError! = nil
                do{
                    try context.save()
                }
                catch
                {
                    print(err)
                }
                self.objDataModel.append(objModel)
            }
            
            
            let alert = UIAlertView(title: "Alert", message: "Data saved!", delegate: nil, cancelButtonTitle: "OK")
            alert.show()
        }
        else
        {
    
            
            let alert = UIAlertView(title: "Alert", message: "Please fill all data", delegate: nil, cancelButtonTitle: "OK")
            alert.show()
        }
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func callApi()
    {
        let url = NSURL(string: "http://api.topcoder.com/v2/challenges?pageSize=2")
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(url!) { (data, response, error) -> Void in
            
            if(error == nil)
            {
                let err : NSError! = nil
                do
                {
                    
                    let json = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments)
                    print(json)
                        
                }
                catch{
                    
                    print(err)
                    
                }
            }
            else
            {
                print(error?.description)
            }
            
        }
        task.resume()
    }
    
    func callPostApi()
    {
        let baseUrl : NSString = NSString(format: "http://atlant.cearsinfotech.com/api.php") //?username=%@&password=%@&method=%@", "test","12345","login
        let request = NSMutableURLRequest(URL: NSURL(string: baseUrl as String)!)
        let session = NSURLSession.sharedSession()
        
        request.HTTPMethod = "POST"
        let stringPost = "username=test&password=12345&method=login" // Key and Value
        
        let data = stringPost.dataUsingEncoding(NSUTF8StringEncoding)
        
        request.timeoutInterval = 60
        request.HTTPBody=data
        
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            
            let err1: NSError? = nil
            do
            {
                let json = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers)
                print(json)
            }
            catch
            {
                print(err1)
            }
        })
        
        task.resume()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
    

}
