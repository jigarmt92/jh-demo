//
//  SecondViewController.swift
//  testCoredata
//
//  Created by Bigscal Mini on 13/06/16.
//  Copyright © 2016 Bigscal Mini. All rights reserved.
//

import UIKit

class SecondViewController: addRecordViewController {

    @IBOutlet var btnSegment: UISegmentedControl!
    
    @IBOutlet var displayView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.fname = ""
        
        let firstVC = self.storyboard?.instantiateViewControllerWithIdentifier("firstvc") as! OneViewController
        self.displayView.addSubview(firstVC.view)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func segmentClick(sender: AnyObject)
    {
        if(self.btnSegment.selectedSegmentIndex == 0)
        {
            let firstVC = self.storyboard?.instantiateViewControllerWithIdentifier("firstvc") as! OneViewController
            self.displayView.addSubview(firstVC.view)
        }
        else
        {
            let secondVC = self.storyboard?.instantiateViewControllerWithIdentifier("secondvc") as! TwoViewController
            self.displayView.addSubview(secondVC.view)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
