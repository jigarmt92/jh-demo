//
//  ViewController.swift
//  eFastB2B
//
//  Created by Darshan Gajera on 6/19/16.
//  Copyright © 2016 denny. All rights reserved.
//

import UIKit

class ViewController: UIViewController, SKSTableViewDelegate {
    
    @IBOutlet var tblView : SKSTableView!

    var myArray : NSArray = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tblView.SKSTableViewDelegate = self
        
        myArray  = [[["Section0_Row0", "Row0_Subrow1"], ["Section0_Row1", "Row1_Subrow1"], ["Section0_Row2"]]]
        
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.myArray.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.myArray[section].count
    }
    
    func tableView(tableView: SKSTableView!, numberOfSubRowsAtIndexPath indexPath: NSIndexPath!) -> Int {
        
        return self.myArray[indexPath.section][indexPath.row].count - 1;
    }
    
    func tableView(tableView: SKSTableView!, shouldExpandSubRowsOfCellAtIndexPath indexPath: NSIndexPath!) -> Bool {
        if (indexPath.section == 1 && indexPath.row == 0)
        {
            return true
        }
        
        return false
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell: SKSTableViewCell = SKSTableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell")
        
        cell.textLabel!.text = "\(self.myArray[indexPath.section][indexPath.row][0])"
        
        if ((indexPath.section == 0 && (indexPath.row == 1 || indexPath.row == 0)) || (indexPath.section == 1 && (indexPath.row == 0 || indexPath.row == 2)))
        {
            cell.expandable = true
        }
        else
        {
            cell.expandable = false
        }
    
        return cell
        
    }
    
    func tableView(tableView: SKSTableView!, cellForSubRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell! {
        
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell")
        
        cell.textLabel!.text = "\(self.myArray[indexPath.section][indexPath.row][indexPath.subRow])"
        cell.accessoryType = .DisclosureIndicator
        return cell
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("Section:, Row:, Subrow:", indexPath.section, indexPath.row, indexPath.subRow)
    }
    
    func tableView(tableView: SKSTableView!, didSelectSubRowAtIndexPath indexPath: NSIndexPath!) {
        print("Section:, Row:, Subrow:", indexPath.section, indexPath.row, indexPath.subRow)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

