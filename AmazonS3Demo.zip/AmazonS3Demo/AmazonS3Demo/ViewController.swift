//
//  ViewController.swift
//  AmazonS3Demo
//
//  Created by Bigscal on 3/15/16.
//  Copyright © 2016 BigScal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var selectedImage: UIImageView!
    
    //let transferManager: AWSS3TransferManager = AWSS3TransferManager.defaultS3TransferManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func download(sender: UIButton)
    {
        let transferManager = AWSS3TransferManager.defaultS3TransferManager()
        
        let downloadingFilePath1 = (NSTemporaryDirectory() as NSString).stringByAppendingPathComponent("temp-download")
        let downloadingFileURL1 = NSURL(fileURLWithPath: downloadingFilePath1 )
        
        let downloadReadRequest1 : AWSS3TransferManagerDownloadRequest = AWSS3TransferManagerDownloadRequest()
        downloadReadRequest1.bucket = "albumapp"
        downloadReadRequest1.key =  "20150404165551210.png"
        downloadReadRequest1.downloadingFileURL = downloadingFileURL1
        
        let task = transferManager.download(downloadReadRequest1)
        task.continueWithBlock { (task) -> AnyObject? in
            print(task.error)
            if task.error != nil {
                print("Download Error: ",task.error?.localizedDescription)
            } else {
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    self.selectedImage.image = UIImage(contentsOfFile: downloadingFilePath1)
                    self.selectedImage.setNeedsDisplay()
                    self.selectedImage.reloadInputViews()
                })
                print("Fetched image")
            }
            return nil
        }
    }
    
    @IBAction func upload(sender: UIButton)
    {
        let transferManager: AWSS3TransferManager = AWSS3TransferManager.defaultS3TransferManager()
        
        let testFileURL1 = NSURL(fileURLWithPath: (NSTemporaryDirectory() as NSString).stringByAppendingPathComponent("temp"))
        let uploadRequest1 : AWSS3TransferManagerUploadRequest = AWSS3TransferManagerUploadRequest()
        
        let image = UIImage(named: "baby.jpg")!
        let data = UIImageJPEGRepresentation(image, 0.5)
        
        let dtFormatter: NSDateFormatter = NSDateFormatter()
        dtFormatter.dateFormat="yyyyMMddHHmmssSSS"
        let imageName = dtFormatter.stringFromDate(NSDate())
        let imageFullName = imageName + ".png" as NSString
        //var pngData = UIImagePNGRepresentation(image)
        print("imageFullName : ",imageFullName)
        
        data!.writeToURL(testFileURL1, atomically: true)
        uploadRequest1.bucket = "albumapp"
        uploadRequest1.key =  imageFullName as String
        uploadRequest1.body = testFileURL1
        uploadRequest1.contentType="image/png"
        uploadRequest1.ACL=AWSS3ObjectCannedACL.PublicRead
        
        let task = transferManager.upload(uploadRequest1)
        task.continueWithBlock { (task) -> AnyObject? in
            if task.error != nil {
                print("Upload Error: \(task.error)")
            } else {
                print("Upload successful")
            }
            return nil
        }
    }


}

