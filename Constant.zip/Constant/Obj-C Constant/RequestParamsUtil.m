//
//  RequestParamsUtil.m
//  LawyerOnDemand
//
//  Created by Ali Taher on 6/17/14.
//  Copyright (c) 2014 Metova. All rights reserved.
//

#import "RequestParamsUtil.h"
#import "WebConstants.h"
#import "NSString+StringUtils.h"
#import "UserManager.h"

@implementation RequestParamsUtil

#pragma mark Account
+ (NSDictionary *)createAccountParamsWithFirstName:(NSString *)aFirstName
                                          lastName:(NSString *)aLastName
                                             email:(NSString *)aEmail
                                          password:(NSString *)aPassword
                                          referral:(NSString *)aReferral
{
    
    NSMutableDictionary *accountInfo = [@{kAccountFirstName:aFirstName,
                                          kAccountLastName:aLastName,
                                          kAccountEmail:aEmail,
                                          kAccountPassword:aPassword,
                                          kAccountReferralAnswer: aReferral ? aReferral : @"",
                                          @"type": @"User"
                                          }mutableCopy];
    
    NSString *deviceToken = [[UserManager sharedManager]getDeviceToken];
    
    if (deviceToken) {
        [accountInfo setObject:kDevicePlatformIOS forKey:kAccountDevicePlatform];
        [accountInfo setObject:deviceToken forKey:kAccountDeviceToken];
    }
    
    return @{kAccountRoot : accountInfo};
}

+ (NSDictionary *)createAccountParamsWithFacebookID:(NSString *)aFBID
                                          firstName:(NSString *)aFirstName
                                           lastName:(NSString *)aLastName
                                              email:(NSString *)aEmail
                                           password:(NSString *)aPassword
                                           referral:(NSString *)aReferral
                                        accessToken:(NSString *)aAccessToken
{
    
    NSDictionary *facebookInfo = @{
                                   kAccountFacebookID: aFBID,
                                   kAccountFacebookAccessToken: aAccessToken,
                                   kAccountProvider: kAccountProviderFacebook
                                   };
    
    
    NSMutableDictionary *accountInfo = [@{kAccountFirstName:aFirstName,
                                          kAccountLastName:aLastName,
                                          kAccountEmail:aEmail,
                                          kAccountPassword:aPassword,
                                          kAccountReferralAnswer: aReferral ? aReferral : @"",
                                          @"type": @"User",
                                          kAccountFacebookInfoRoot: @[facebookInfo]
                                          }mutableCopy];
    
    NSString *deviceToken = [[UserManager sharedManager]getDeviceToken];
    
    if (deviceToken) {
        [accountInfo setObject:@{kAccountDevicePlatform:kDevicePlatformIOS, kAccountDeviceToken:deviceToken} forKey:kAccountRoot];
        
    }
    
    return @{kAccountRoot : accountInfo};
}


+ (NSDictionary *)loginParamsWithEmail:(NSString *)aEmail
                              password:(NSString *)aPassword
{
    NSString *deviceToken = [[UserManager sharedManager]getDeviceToken];
    
    NSDictionary *accountInfo;
    if (deviceToken) {
        accountInfo = @{kAccountEmail:aEmail,
                        kAccountPassword:aPassword,
                        kAccountDevicePlatform: kDevicePlatformIOS,
                        kAccountDeviceToken:deviceToken
                        };
    }else{
        accountInfo = @{kAccountEmail:aEmail,
                        kAccountPassword:aPassword
                        };
    }
    
    return @{kAccountRoot:accountInfo};
}

+ (NSDictionary *)loginParamsWithFacebookID:(NSString *)aFBID accessToken:(NSString *)aAccessToken
{
    
    NSDictionary *facebookInfo = @{kAccountFacebookAccessToken: aAccessToken,
                                   kAccountFacebookID: aFBID,
                                   kAccountProvider: kAccountProviderFacebook
                                   };
    
    NSMutableDictionary *accountInfo = [[NSMutableDictionary alloc]init];
    [accountInfo setObject:facebookInfo forKey:kAccountFacebookInfoRoot];
    
    NSString *deviceToken = [[UserManager sharedManager]getDeviceToken];
    
    if (deviceToken) {
        [accountInfo setObject:@{kAccountDevicePlatform:kDevicePlatformIOS, kAccountDeviceToken:deviceToken} forKey:kAccountRoot];
    }
    
    return accountInfo;
}

+ (NSDictionary *)forgotPasswordParamsWithEmail:(NSString *)aEmail
{
    NSDictionary *accountInfo = @{kAccountEmail:aEmail};
    
    return @{kAccountRoot:accountInfo};
}

+ (NSDictionary *)updateAccountParamsWithPhone:(NSString *)aPhone
                                         email:(NSString *)aEmail
                                      password:(NSString *)aPassword
                               currentPassword:(NSString *)aCurrentPassword
{
    
    NSMutableDictionary *accountInfo = [[NSMutableDictionary alloc]init];
    if (aPhone && ![aPhone isEqualToString:@""]) {
        [accountInfo setObject:aPhone forKey:kAccountPhone];
    }
    if (aEmail && ![aEmail isEqualToString:@""]) {
        [accountInfo setObject:aEmail forKey:kAccountEmail];
    }
    if (aPassword && ![aPassword isEqualToString:@""]) {
        [accountInfo setObject:aPassword forKey:kAccountPassword];
    }
    
    //current password is only required by the backend for email or password updates, ugh!
    if (aCurrentPassword && ![aCurrentPassword isEqualToString:@""] && (aEmail || aPassword)) {
        [accountInfo setObject:aCurrentPassword forKey:kAccountCurrentPassword];
    }
    
    return @{kAccountRoot : accountInfo};
}

#pragma mark Question
+ (NSDictionary *)sendQuestionWithSubject:(NSString *)aSubject
                              description:(NSString *)aDescription
                              specialtyID:(NSString *)aSpecialtyID
                                  usState:(NSString *)aState
                           adverseParties:(NSString *)aAdverseParties
{
    NSMutableDictionary *questionInfo = [[NSMutableDictionary alloc]init];
    [questionInfo setObject:aSubject forKey:kQuestionSubject];
    [questionInfo setObject:aDescription forKey:kQuestionDescription];
    
    if (aSpecialtyID) {
        NSString *check = [NSString stringWithFormat:@"%@", aSpecialtyID ];
        if (![check isEqualToString:@"-1"]) {
            [questionInfo setObject:aSpecialtyID forKey:kSpecialtyID];
        }
    }
    if (aState) {
        [questionInfo setObject:aState forKey:kQuestionLocation];
    }
    if (aAdverseParties) {
        [questionInfo setObject:aAdverseParties forKey:kCallAdverseParties];
    }
    
    return @{kQuestionRoot: questionInfo};
}

+ (NSDictionary *)replyToQuestionWithMessage:(NSString *)aMessage
{
    NSMutableDictionary *replyInfo = [[NSMutableDictionary alloc]init];
    [replyInfo setObject:aMessage forKey:kMessage];
    
    return @{kReplyRoot: replyInfo};
}

+ (NSDictionary *)startCallParamsWithSpecialty:(NSString *)aSpecialty
                                       message:(NSString *)aMessage
                                      location:(NSString *)aLocation
                                    attorneyID:(NSString *)aAttorneyID
                                        amount:(NSNumber *)aAmount
                               stripeCardToken:(NSString *)aCardToken
                                adverseParties:(NSString *)aAdverseParties
                                     promoCode:(NSString *)aPromoCode
                                      callType:(NSString *)callType
{
    NSMutableDictionary *callInfo = [[NSMutableDictionary alloc]init];
    if (aSpecialty) {
        [callInfo setObject:aSpecialty forKey:kSpecialtyID];
    }
    if (aMessage) {
        [callInfo setObject:aMessage forKey:kMessage];
    }
    if (aLocation) {
        [callInfo setObject:aLocation forKey:kCallLocation];
    }
    if (aAdverseParties) {
        [callInfo setObject:aAdverseParties forKey:kCallAdverseParties];
    }
    if (callType) {
        [callInfo setObject:callType forKey:KCallType];
    }
    
    NSDictionary *params;
    if (aCardToken) {
        params = @{kCallRoot: callInfo, kStripeToken: aCardToken, kAmount: aAmount, kAttorneyIDKey: aAttorneyID};
    }
    else if(aPromoCode && aAttorneyID)
    {
        params = @{kCallRoot: callInfo, @"promo_code": aPromoCode, kAttorneyIDKey: aAttorneyID};
    }
    else if(aAttorneyID)
    {
        params = @{kCallRoot: callInfo, kAmount: aAmount, kAttorneyIDKey: aAttorneyID};
    }
    else
    {
        params = @{kCallRoot: callInfo, kAmount: aAmount};
    }
    
    return params;
}

+ (NSDictionary *)getTokenForCallParamsCallId:(NSString *)callId
{
    NSDictionary *params;
    params = @{@"call_id": callId};

    return params;
}

+ (NSDictionary *)stopCallParams:(NSString *)status
{
    NSDictionary *params;
    params = @{KCallStatusKey: status};

    return params;
}

+ (NSDictionary *)callNextAvailableParamsWithSpecialty:(NSString *)aSpecialty
                                              location:(NSString *)aLocation

{
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    if (aSpecialty) {
        [params setObject:aSpecialty forKey:kSpecialtyID];
    }
    if (aLocation) {
        [params setObject:aLocation forKey:kCallLocation];
    }
    return params;
}

+ (NSDictionary *)extendCallParamsWithCallID:(NSString *)aCallID
                                      amount:(NSNumber *)aAmount
{
    
    return @{@"id": aCallID, kAmount: aAmount};
}

+ (NSDictionary *)reviewLawyerParamsWithRating:(NSNumber *)aRating
                                       comment:(NSString *)aComment
{
    NSMutableDictionary *reviewInfo = [[NSMutableDictionary alloc]init];
    if (aRating) {
        [reviewInfo setObject:aRating forKey:kStarRating];
    }
    if (aComment) {
        [reviewInfo setObject:aComment forKey:kReviewComment];
    }
    
    return @{kReviewLawyerRoot: reviewInfo};
}

#pragma mark Search Lawyers
+ (NSDictionary *)searchLawyerWithSpecialty:(NSString *)aSpecialty
                                        zip:(NSString *)aZip
                                        lat:(NSString *)lat
                                        lng:(NSString *)lng
                                    initialSearch:(BOOL)isInialSearch
{
    NSLog(@"zip %@, last %@, long %@",aZip, lat, lng);
    NSMutableDictionary *searchInfo = [[NSMutableDictionary alloc]init];
    if (aSpecialty) {
        [searchInfo setObject:aSpecialty forKey:kAttorneySearchSpecialties];
    }
    
    if (aZip) {
        [searchInfo setObject:aZip forKey:kAttorneySearchState];
    }
    if (lat && lng) {
        [searchInfo setObject:@[lat,lng] forKey:kGeoLocation];
    }
    
    NSString *initialValue;
    if (isInialSearch) {
        initialValue = @"1";
    }
    else
    {
        initialValue = @"0";
    }
    return @{kAttorneySearchRoot:searchInfo, KAttorneySearchInitial:initialValue};
}

#pragma mark Attorney Contact Info
+ (NSDictionary *)createAttorneyContactInfoParamsWithFirstName:(NSString *)aFirstName
                                                      lastName:(NSString *)aLastName
                                                         email:(NSString *)aEmail
                                                   phoneNumber:(NSString *)aPhone
                                                     specialty:(NSString *)aSpecialty
                                                 contactMethod:(NSString *)aContactMethod
{
    NSDictionary *contactInfo = @{kFirstNameKey:aFirstName,
                                  kLastNameKey:aLastName,
                                  kEmailKey:aEmail,
                                  kPhoneNumberKey:aPhone,
                                  kSpecialtyKey:aSpecialty ? aSpecialty : @"not specified",
                                  kContactMethodKey:aContactMethod
                                  };
    
    return @{kContactInfoRoot : contactInfo};
}

@end
