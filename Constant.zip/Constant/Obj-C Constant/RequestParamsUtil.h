//
//  RequestParamsUtil.h
//  LawyerOnDemand
//
//  Created by Ali Taher on 6/17/14.
//  Copyright (c) 2014 Metova. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RequestParamsUtil : NSObject

+ (NSDictionary *)createAccountParamsWithFirstName:(NSString *)aFirstName
                                          lastName:(NSString *)aLastName
                                             email:(NSString *)aEmail
                                          password:(NSString *)aPassword
                                          referral:(NSString *)aReferral;

+ (NSDictionary *)createAccountParamsWithFacebookID:(NSString *)aFBID
                                          firstName:(NSString *)aFirstName
                                           lastName:(NSString *)aLastName
                                              email:(NSString *)aEmail
                                           password:(NSString *)aPassword
                                           referral:(NSString *)aReferral
                                        accessToken:(NSString *)aAccessToken;

+ (NSDictionary *)loginParamsWithFacebookID:(NSString *)aFBID
                                accessToken:(NSString *)aAccessToken;

+ (NSDictionary *)loginParamsWithEmail:(NSString *)aEmail
                              password:(NSString *)aPassword;

+ (NSDictionary *)forgotPasswordParamsWithEmail:(NSString *)aEmail;

+ (NSDictionary *)updateAccountParamsWithPhone:(NSString *)aPhone
                                         email:(NSString *)aEmail
                                      password:(NSString *)aPassword
                               currentPassword:(NSString *)aCurrentPassword;

+ (NSDictionary *)searchLawyerWithSpecialty:(NSString *)aSpecialty
                                        zip:(NSString *)aZip
                                        lat:(NSString *)lat
                                        lng:(NSString *)lng
                              initialSearch:(BOOL)isInialSearch;

+ (NSDictionary *)createAttorneyContactInfoParamsWithFirstName:(NSString *)aFirstName
                                                      lastName:(NSString *)aLastName
                                                         email:(NSString *)aEmail
                                                   phoneNumber:(NSString *)aPhone
                                                     specialty:(NSString *)aSpecialty
                                                 contactMethod:(NSString *)aContactMethod;

+ (NSDictionary *)sendQuestionWithSubject:(NSString *)aSubject
                              description:(NSString *)aDescription
                              specialtyID:(NSString *)aSpecialtyID
                                  usState:(NSString *)aState
                           adverseParties:(NSString *)aAdverseParties;

+ (NSDictionary *)replyToQuestionWithMessage:(NSString *)aMessage;

+ (NSDictionary *)startCallParamsWithSpecialty:(NSString *)aSpecialty
                                       message:(NSString *)aMessage
                                      location:(NSString *)aLocation
                                    attorneyID:(NSString *)aAttorneyID
                                        amount:(NSNumber *)aAmount
                               stripeCardToken:(NSString *)aCardToken
                                adverseParties:(NSString *)aAdverseParties
                                     promoCode:(NSString *)aPromoCode callType:(NSString *)callType;

+ (NSDictionary *)getTokenForCallParamsCallId:(NSString *)callId;

+ (NSDictionary *)stopCallParams:(NSString *)status;

+ (NSDictionary *)callNextAvailableParamsWithSpecialty:(NSString *)aSpecialty
                                              location:(NSString *)aLocation;

+ (NSDictionary *)extendCallParamsWithCallID:(NSString *)aCallID
                                      amount:(NSNumber *)aAmount;

+ (NSDictionary *)reviewLawyerParamsWithRating:(NSNumber *)aRating
                                       comment:(NSString *)aComment;

@end
