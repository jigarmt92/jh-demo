//
//  APIManager.h
//  LawyerOnDemand
//
//  Created by Ali Taher on 6/10/14.
//  Copyright (c) 2014 Metova. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LawyerCall, BillingInfo, QuestionHistory, Lawyer;

@interface APIManager : NSObject

+ (APIManager *)sharedManager;

- (NSMutableURLRequest *)uploadImageRequestForImage:(UIImage *)aImage;

- (void)listOfSpecialties:(void (^)(NSArray *response, NSError *error))completion;

- (void)listOfReferrals:(void (^)(NSArray *response, NSError *error))completion;

- (void)getAboutInfo:(void (^)(NSDictionary *aboutInfo, NSError *error))completion;

//Account
- (void)createAccountWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion;

- (void)loginWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion;

- (void)forgotPasswordWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion;

- (void)getBillingHistory:(void (^)(NSArray *history, NSError *error))completion;

- (void)getCurrentBillingInfo:(void (^)(BillingInfo *account, NSError *error))completion;

- (void)updateAccountWithParams:(NSDictionary *)params completion:(void (^)(NSError *error, NSDictionary *response))completion;

- (void)updateUsersBillingWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion;

//Favorites
- (void)getListOfFavorites:(void (^)(NSArray *favoriteAttorneys, NSError *error))completion;

- (void)addToFavoritesAttorney:(NSString *)aAttorneyID completion:(void (^)(NSError *error))completion;

- (void)deleteFromFavoritesAttorney:(NSString *)aAttorneyID completion:(void (^)(NSError *error))completion;

//Calls
- (void)searchForLawyerWithParams:(NSDictionary *)params completion:(void (^)(NSArray *response, NSError *error))completion;

- (void)startCallWithParams:(NSDictionary *)params lawyerID:(NSString *)aLawyerID completion:(void (^)(LawyerCall *callInfo, NSError *error))completion;

- (void)callPaymentWithParams:(NSDictionary *)params lawyerID:(NSString *)aLawyerID completion:(void (^)(NSDictionary *response, NSError *error))completion;

- (void)nextAvailableLawyerCallWithParams:(NSDictionary *)params completion:(void(^)(Lawyer *lawyer, NSError *error))completion;

- (void)stopCallWithParams:(NSDictionary *)params completion:(void (^)(LawyerCall *callInfo, NSError *error))completion;

- (void)extendCallWithParams:(NSDictionary *)params completion:(void (^)(LawyerCall *callInfo, NSError *error))completion;

- (void)getStatusForCallWithID:(NSString *)aCallID completion:(void (^)(NSError *error, BOOL status))completion;

- (void)reviewLawyerWithParams:(NSDictionary *)params lawyerID:(NSString *)aLawyerID completion:(void (^)(NSError *error))completion;

- (void)getReviewsForLawyer:(NSString *)aLawyerID completion:(void (^)(NSError *error, NSArray *reviews))completion;

- (void)getCallPriceCompletion:(void (^)(NSDictionary *response, NSError *error))completion;

- (void)getCallInfoParams:(NSString *)callId completion:(void (^)(NSError *error, LawyerCall *call))completion;

//Questions
- (void)sendQuestionWithParams:(NSDictionary *)params completion:(void (^)(QuestionHistory *question, NSError *error))completion;

- (void)getQuestionWithID:(NSString *)aQuestionID completion:(void (^)(QuestionHistory *question))completion;

- (void)getRepliesToQuestionID:(NSString *)aQuestionID completion:(void (^)(NSArray *replies))completion;

- (void)postReplyToQuestionID:(NSString *)aQuestionID params:(NSDictionary *)params completion:(void (^)(NSArray *replies))completion;

- (void)getQuestionHistoryWithCompletion:(void (^)(NSArray *response, NSError *error))completion;

- (void)deleteQuestionByID:(NSString *)aQuestionID completion:(void (^)(bool deletedSuccesfuly))completion;

//Random
- (void)sendAttorneyContactInfo:(NSDictionary *)params completion:(void (^)(NSError *error))completion;

- (void)getActivityHistoryWithCompletion:(void (^)(NSArray *response, NSError *error))completion;

@end
