//
//  APIManager.m
//  LawyerOnDemand
//
//  Created by Ali Taher on 6/10/14.
//  Copyright (c) 2014 Metova. All rights reserved.
//

#import "APIManager.h"
#import "WebConstants.h"
#import <Overcoat/Overcoat.h>
#import "UserManager.h"
#import <AFNetworking/AFNetworking.h>
#import "ActivityHistoryUtils.h"

//Models
#import "User.h"
#import "Lawyer.h"
#import "Specialty.h"
#import "LawyerCall.h"
#import "CallHistory.h"
#import "QuestionHistory.h"
#import "QuestionReply.h"
#import "Referral.h"
#import "BillingHistory.h"
#import "BillingInfo.h"
#import "LawyerReview.h"
#import "LawyerCall.h"

@interface APIManager ()
{
    OVCClient *_client;
}
@end

@implementation APIManager

+ (APIManager *)sharedManager
{
    static APIManager *_sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedManager = [[self alloc] init];
    });
    
    return _sharedManager;
}

- (instancetype)init
{
    self = [super init];
    
    if (self) {
        _client = [[OVCClient alloc] initWithBaseURL:[NSURL URLWithString:kBaseURL]];
        _client.securityPolicy.allowInvalidCertificates = YES;
        if ([[UserManager sharedManager] userIsAuthenticated]) {
            [self setupCurrentProfileHeader:[[UserManager sharedManager] currentAuthToken]];
        }
    }
    return self;
}

- (void)setupCurrentProfileHeader:(NSString *)token
{
    AFHTTPRequestSerializer *request = [[AFHTTPRequestSerializer alloc]init];
    [request setValue:[NSString stringWithFormat:@"Token token=\"%@\"", token] forHTTPHeaderField:@"Authorization"];
    [_client setRequestSerializer:request];
}

#pragma mark General Info
- (void)listOfSpecialties:(void (^)(NSArray *response, NSError *error))completion
{
    [_client GET:LOD_SpecialtiesList parameters:nil resultClass:[Specialty class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject,error);
        }
        else{
            completion(nil, error);
        }
    }];
}

- (void)listOfReferrals:(void (^)(NSArray *response, NSError *error))completion
{
    [_client GET:LOD_ReferralList parameters:nil resultClass:[Referral class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject,error);
        }
        else{
            completion(nil, error);
        }
    }];
}

- (void)getAboutInfo:(void (^)(NSDictionary *aboutInfo, NSError *error))completion
{
    [_client GET:LOD_About parameters:nil resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject, nil);
        }
        else{
            completion(nil, error);
        }
    }];
}


#pragma mark Account
- (void)createAccountWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion
{
    
    [_client POST:LOD_CreateAccountPath parameters:params resultClass:[User class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            //  [[UserManager sharedManager]saveUser:(User *)responseObject];
            User *user = (User *)responseObject;
            // [self setupCurrentProfileHeader:user.authToken];
            if ([user.is_active isEqualToString:@"inactive"]) {
                //give alert
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAlertViewTitle message:@"Please check email. Verification link has been sent." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
                [alert show];
            }
            completion(nil);
        }
        else
        {
            if ([error.localizedDescription rangeOfString:@"422"].length) { //account already exists
                NSError *myError = [[NSError alloc]initWithDomain:@"what" code:422 userInfo:@{NSLocalizedDescriptionKey:@"There already is an account with that email."}];
                completion(myError);
            }
            else{
                NSError *myError = [[NSError alloc]initWithDomain:@"what" code:0 userInfo:@{NSLocalizedDescriptionKey:@"There was a problem creating your account.  Please try again."}];
                completion(myError);
            }
        }
    }];
}

- (void)loginWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion
{
    [_client POST:LOD_LoginAccountPath parameters:params resultClass:[User class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {

        if (!error) {
            //DDLogVerbose(@"%@", responseObject);
            User *user = (User *)responseObject;
            if ([user.is_active isEqualToString:@"active"])
            {
                [[UserManager sharedManager]saveUser:(User *)responseObject];
                [self setupCurrentProfileHeader:user.authToken];
                completion(nil);
            }
            else
            {
                //give alert
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAlertViewTitle message:@"Your account is not verified yet." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
                [alert show];
                NSError *error = [[NSError alloc] initWithDomain:kAlertViewTitle code:100 userInfo:nil];
                completion(error);
            }
        }
        else
        {
            completion(error);
        }
    }];
}

- (void)forgotPasswordWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion
{
    [_client POST:LOD_ForgotPasswordAccountPath parameters:params resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (error) {
            if ([error.localizedDescription rangeOfString:@"404"].length) { //account doesn't exist
                NSError *myError = [[NSError alloc]initWithDomain:@"what" code:422 userInfo:@{NSLocalizedDescriptionKey:@"There is no account with that email."}];
                completion(myError);
            }
            else{ //No idea what kind of message to give a user ... hmmm
                completion(error);
            }
        }
        else{
            completion(nil);
        }
    }];
}

- (void)getBillingHistory:(void (^)(NSArray *history, NSError *error))completion
{
    [_client GET:LOD_BillingHistory parameters:nil resultClass:[BillingHistory class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject, nil);
        }
        else
        {
            completion(nil, error);
        }
    }];
}

- (void)getCurrentBillingInfo:(void (^)(BillingInfo *account, NSError *error))completion
{
    [_client GET:LOD_BillingInfoCurrent parameters:nil resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            NSDictionary *card = responseObject[@"cards"][@"data"][0];
            BillingInfo *info = [MTLJSONAdapter modelOfClass:[BillingInfo class]
                                          fromJSONDictionary:card
                                                       error:nil];
            completion(info, nil);
        }
        else
        {
            completion(nil, error);
        }
    }];
}

- (void)updateAccountWithParams:(NSDictionary *)params completion:(void (^)(NSError *error, NSDictionary *response))completion
{
    [_client PUT:LOD_CreateAccountPath parameters:params resultClass:[User class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        
        if (!error) {
            [[UserManager sharedManager]updateUser:(User *)responseObject];
            completion(nil, nil);
        }
        else
        {
            //response has a message as to why the update failed
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:operation.responseData options:kNilOptions error:nil];
            completion(error, json);
        }
    }];
    
}

- (void)updateUsersBillingWithParams:(NSDictionary *)params completion:(void (^)(NSError *error))completion
{
    [_client POST:LOD_UpdateBilling parameters:params resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            //[[UserManager sharedManager]saveUser:(User*)responseObject];
            NSDictionary *response = (NSDictionary*)responseObject;
            
            if ([[response valueForKey:@"value"] isEqualToString:@"success"]) {
                completion(nil);
            }
            else
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAlertViewTitle message:[response valueForKey:@"message"] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
                [alert show];
                completion(nil);
            }
        }
        else
        {
            completion(error);
        }
    }];
}

#pragma mark Favorites
- (void)getListOfFavorites:(void (^)(NSArray *favoriteAttorneys, NSError *error))completion
{
    [_client GET:LOD_Favorites parameters:nil resultClass:[Lawyer class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject, nil);
        }
        else{
            completion(nil, error);
        }
    }];
}

- (void)addToFavoritesAttorney:(NSString *)aAttorneyID completion:(void (^)(NSError *error))completion
{
    [_client POST:LOD_AddFavorite parameters:@{@"attorney_id":aAttorneyID} resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        completion(error);
    }];
}

- (void)deleteFromFavoritesAttorney:(NSString *)aAttorneyID completion:(void (^)(NSError *error))completion
{
    [_client DELETE:LOD_RemoveFavorite parameters:@{@"attorney_id":aAttorneyID} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        completion(nil);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        completion(error);
    }];
}

#pragma mark Lawyer Search
- (void)searchForLawyerWithParams:(NSDictionary *)params completion:(void (^)(NSArray *response, NSError *error))completion
{
    [_client GET:LOD_SearchAttorneysPath parameters:params resultClass:[Lawyer class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject,error);
        }
        else{
            completion(nil, error);
        }
    }];
}

#pragma mark Call Lawyer
- (void)startCallWithParams:(NSDictionary *)params lawyerID:(NSString *)aLawyerID completion:(void (^)(LawyerCall *callInfo, NSError *error))completion
{
    NSString *url = [NSString stringWithFormat:LOD_StartCallAttorneyFormatPath, aLawyerID];
    [_client POST:url parameters:params resultClass:[LawyerCall class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        completion(responseObject, error);
    }];
}

- (void)callPaymentWithParams:(NSDictionary *)params lawyerID:(NSString *)aLawyerID completion:(void (^)(NSDictionary *response, NSError *error))completion
{
    [_client POST:LOD_Payment parameters:params resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        completion(responseObject,error);
    }];
}

- (void)getCallInfoParams:(NSString *)callId completion:(void (^)(NSError *error, LawyerCall *call))completion
{
    NSString *url = [NSString stringWithFormat:LOD_GetToken,callId];
    [_client GET:url parameters:nil resultClass:[LawyerCall class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            NSLog(@" call info....%@", responseObject);
            LawyerCall *callInfo = (LawyerCall *)responseObject;
            completion(nil,callInfo);
        }
        else
        {
            completion(error,nil);
        }
    }];
}


- (void)nextAvailableLawyerCallWithParams:(NSDictionary *)params completion:(void(^)(Lawyer *lawyer, NSError *error))completion
{
    [_client GET:LOD_NextAvailableAttorney parameters:params resultClass:[Lawyer class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject, nil);
        }
        else{
            completion(nil, error);
        }
    }];
}

- (void)extendCallWithParams:(NSDictionary *)params completion:(void (^)(LawyerCall *callInfo, NSError *error))completion
{
    [_client POST:LOD_ExtendCall parameters:params resultClass:[LawyerCall class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        completion(responseObject, error);
    }];
}

- (void)stopCallWithParams:(NSDictionary *)params completion:(void (^)(LawyerCall *callInfo, NSError *error))completion
{
   
    NSString *lawyerID = params[@"lawyerID"];
    NSString *callID = params[@"callID"];
   
    NSString *url = [NSString stringWithFormat:LOD_StopCallAttorneyFormatPath, lawyerID, callID];
      NSLog(@" stop call url%@",url);
    [_client POST:url parameters:params resultClass:[LawyerCall class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
          NSLog(@" response %@",responseObject);
        completion(responseObject, error);
        
    }];
}

- (void)getStatusForCallWithID:(NSString *)aCallID completion:(void (^)(NSError *error, BOOL status))completion
{
    [_client GET:LOD_CallStatus parameters:@{@"id": aCallID} resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        completion(error, YES);
    }];
}

- (void)reviewLawyerWithParams:(NSDictionary *)params lawyerID:(NSString *)aLawyerID completion:(void (^)(NSError *error))completion
{
    NSString *url = [NSString stringWithFormat:LOD_ReviewLawyer, aLawyerID];
    [_client POST:url parameters:params resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        completion(error);
    }];
}

- (void)getReviewsForLawyer:(NSString *)aLawyerID completion:(void (^)(NSError *error, NSArray *reviews))completion
{
    NSString *url = [NSString stringWithFormat:LOD_ReviewLawyer, aLawyerID];
    [_client GET:url parameters:nil resultClass:[LawyerReview class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        completion(error, responseObject);
    }];
}

#pragma mark Questions
- (void)sendQuestionWithParams:(NSDictionary *)params completion:(void (^)(QuestionHistory *question, NSError *error))completion
{
    [_client POST:LOD_Questions parameters:params resultClass:[QuestionHistory class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject ,nil);
        }
        else
        {
            
            completion(responseObject, error);
        }
    }];
}

- (void)getQuestionWithID:(NSString *)aQuestionID completion:(void (^)(QuestionHistory *question))completion
{
    NSString *url = [NSString stringWithFormat:LOD_GetQuestion, aQuestionID];
    [_client GET:url parameters:nil resultClass:[QuestionHistory class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject);
        }
        else{
            completion(nil);
        }
    }];
}

- (void)getRepliesToQuestionID:(NSString *)aQuestionID completion:(void (^)(NSArray *replies))completion
{
    NSString *url = [NSString stringWithFormat:LOD_RepliesToQuestion, aQuestionID];
    [_client GET:url parameters:nil resultClass:[QuestionReply class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject);
        }
        else{
            completion(nil);
        }
    }];
}

- (void)postReplyToQuestionID:(NSString *)aQuestionID params:(NSDictionary *)params completion:(void (^)(NSArray *replies))completion
{
    NSString *url = [NSString stringWithFormat:LOD_RepliesToQuestion, aQuestionID];
    [_client POST:url parameters:params resultClass:[QuestionReply class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject);
        }
        else{
            completion(nil);
        }
    }];
}

- (void)deleteQuestionByID:(NSString *)aQuestionID completion:(void (^)(bool deletedSuccesfuly))completion
{
    NSString *url = [NSString stringWithFormat:LOD_DeleteQuestion, aQuestionID];
    [_client DELETE:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSDictionary *response = (NSDictionary*)responseObject;
        if ([[response objectForKey:@"status"] isEqualToString:@"ok"]) {
            completion(true);
        }
        else
        {
            completion(false);
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        completion(false);
    }];
}

#pragma mark Send Contact Info
- (void)sendAttorneyContactInfo:(NSDictionary *)params completion:(void (^)(NSError *error))completion
{
    [_client POST:LOD_AttorneyContactInfoPath parameters:params resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(nil);
        }
        else
        {
            completion(error);
        }
    }];
}

#pragma mark Get Activity History
- (void)getActivityHistoryWithCompletion:(void (^)(NSArray *response, NSError *error))completion
{
    [_client GET:LOD_GetCallHistory parameters:nil resultClass:[CallHistory class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id callHistoryResponse, NSError *error) {
        if (!error) {
            [self getQuestionHistoryWithCompletion:^(NSArray *questionHistoryResponse, NSError *error) {
                if (!error)
                {
                    NSArray *result = [callHistoryResponse arrayByAddingObjectsFromArray:questionHistoryResponse];
                    
                    NSArray *sortedArray = [ActivityHistoryUtils sortByDate:result];
                    
                    completion(sortedArray, error);
                }
                else
                {
                    completion(callHistoryResponse, error);
                }
            }];
        }
        else
        {
            [self checkIfReAuthIsNeededForError:error];
            completion(nil, error);
        }
    }];
}

- (void)getQuestionHistoryWithCompletion:(void (^)(NSArray *response, NSError *error))completion
{
    [_client GET:LOD_GetQuestionHistory parameters:nil resultClass:[QuestionHistory class] resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject,error);
        }
        else
        {
            completion(nil, error);
        }
    }];
}

- (void)getLocationSuggestionsCompletion:(void (^)(NSArray *response, NSError *error))completion location:(NSString*)address
{
    
    [_client GET:@"http://maps.googleapis.com/maps/api/geocode/json?address=Califo" parameters:nil resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error) {
        if (!error) {
            completion(responseObject,error);
            
        }
        else
        {
            completion(nil, error);
            
        }
    }];
}

- (void)getCallPriceCompletion:(void (^)(NSDictionary *response, NSError *error))completion
{
    [_client GET:LOD_CallPrice parameters:nil resultClass:nil resultKeyPath:nil completion:^(AFHTTPRequestOperation *operation, id responseObject, NSError *error){
        if (!error) {
            completion(responseObject,error);
        }
        else
        {
            completion(nil, error);
        }
    }];
}
#pragma mark Image Uploader
- (NSMutableURLRequest *)uploadImageRequestForImage:(UIImage *)aImage
{
    if (aImage) {
        NSMutableURLRequest *request = [_client.requestSerializer multipartFormRequestWithMethod:@"PUT" URLString:[NSString stringWithFormat:@"%@%@", kBaseURL, LOD_CreateAccountPath] parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            [formData appendPartWithFileData:UIImageJPEGRepresentation(aImage, 1)
                                        name:[NSString stringWithFormat:@"%@[%@]", @"api_account", @"profile_image"]
                                    fileName:[NSString stringWithFormat:@"image%f.jpg", [[NSDate date] timeIntervalSince1970]]
                                    mimeType:@"image/jpeg"];
            
        } error:nil];
        return request;
    }
    return nil;
}

//TODO: Need to add this to other requests
- (void)checkIfReAuthIsNeededForError:(NSError *)error
{
    if ([error.localizedDescription rangeOfString:@"401"].length) { //unauthorized request
        [[NSNotificationCenter defaultCenter]postNotificationName:kLogUserOut object:nil];
    }
}

@end
