//
//  BaseViewController.swift
//  Fly2Cart
//
//  Created by Bigscal on 10/19/15.
//  Copyright © 2015 bigscal. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController , UIGestureRecognizerDelegate, RightMenuDelegte, UISearchBarDelegate{

    var activityIndicator:UIActivityIndicatorView = UIActivityIndicatorView()
    var internetReachability = NetworkReachability()
    var objRightmenu : RightMenuView = RightMenuView()
    var checkConn : NetworkUnRechableViewController!
    var btnUserRight:UIButton! = UIButton()
    var btnCartRight:UIButton! = UIButton()
    var btnSearch:UIButton! = UIButton()
    var badgeButton:UIButton! = UIButton()
    var userdefaults : NSUserDefaults = NSUserDefaults.standardUserDefaults()
    var badgeCounter : Int = 0
    var isCall : NSString = ""
    var isSearch : Bool = false
    var searchBar:UISearchBar!
    let appdelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let alertView = UIAlertView()
    var serchView:UIView!
    var searchFlag:Bool=false
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        UIApplication.sharedApplication().statusBarHidden = false
        UIApplication.sharedApplication().statusBarStyle = UIStatusBarStyle.LightContent
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self
        self.navigationController?.interactivePopGestureRecognizer?.enabled = false
        self.navigationController?.navigationBar.titleTextAttributes = [ NSFontAttributeName: UIFont(name: FONT, size: 20)!]

        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("reachabilityChanged:"), name: kReachabilityChangedNotification, object: nil)
        self.internetReachability = NetworkReachability.reachabilityForInternetConnection()
        self.internetReachability.startNotifier()
        self.updateInterfaceWithReachability(self.internetReachability)
        // Do any additional setup after loading the view.
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "receiveNotificationFortag:", name: "fortagingValue", object: nil)
        self.userdefaults.setObject(1, forKey: "NetworkCheckFlag")
        self.userdefaults.synchronize()
        // check device is Ipad or not
        if(AppUtilities.isiPad())
        {
            searchBar = UISearchBar(frame: SEARCHBAR_IPAD_FRAME)
            self.serchView=UIView(frame: SEARCHBAR_IPAD_FRAME)
        }
        else
        {
            if (AppUtilities.getScreenWidth() == IPHONE_4S_WIDTH) {
                searchBar = UISearchBar(frame: SEARCHBAR_IPHONE4S_FRAME)
                self.serchView=UIView(frame: SEARCHBAR_IPHONE4S_FRAME)
            }
            else if(AppUtilities.getScreenWidth() == IPHONE_6_PLUS_WIDTH)
            {
                searchBar = UISearchBar(frame: SEARCHBAR_IPHONE6_PLUS_FRAME)
                self.serchView=UIView(frame: SEARCHBAR_IPHONE6_PLUS_FRAME)
            }
            else {
                searchBar = UISearchBar(frame: SEARCHBAR_IPHONE_FRAME)
                self.serchView=UIView(frame: SEARCHBAR_IPHONE_FRAME)
            }
        }

    }

    deinit
    {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*----------------------------------------------------
    * Function Name : updateInterfaceWithReachability
    * Function Param : Reachability
    * Function Return Type: -
    * Function Purpose: check network connection.
    ------------------------------------------------------*/
    
    func updateInterfaceWithReachability(reachability : NetworkReachability)
    {
        let netStatus : NetworkStatus = reachability.currentReachabilityStatus()
        var connRequired : Bool = reachability.connectionRequired()
        switch (netStatus.rawValue)
        {
        case NotReachable.rawValue:
            self.checkConn = self.storyboard?.instantiateViewControllerWithIdentifier(NetworkUnRechableViewControllerVCIdentifier) as! NetworkUnRechableViewController
            self.view.addSubview(self.checkConn.view)
            self.addChildViewController(self.checkConn)
            view.endEditing(true)
            
            self.view.alpha = 1
            self.navigationController?.navigationBar.userInteractionEnabled = false
            if let recognizers = view.gestureRecognizers {
                for recognizer in recognizers {
                    (recognizer).enabled = false
                }
            }
            connRequired = false
            
        case ReachableViaWWAN.rawValue:
            
            self.navigationController?.navigationBar.userInteractionEnabled = true
            self.view.userInteractionEnabled = true
            if let recognizers = view.gestureRecognizers {
                for recognizer in recognizers {
                    (recognizer).enabled = true
                }
            }
            
        case ReachableViaWiFi.rawValue:
            
            self.navigationController?.navigationBar.userInteractionEnabled = true
            self.view.userInteractionEnabled = true
            if let recognizers = view.gestureRecognizers {
                for recognizer in recognizers {
                    (recognizer).enabled = true
                }
            }
            
        default :
            
            self.navigationController?.navigationBar.userInteractionEnabled = true
            self.view.userInteractionEnabled = true
            if let recognizers = view.gestureRecognizers {
                for recognizer in recognizers {
                    (recognizer).enabled = true
                }
            }
        }
    }
    
    func reachabilityChanged(sender : NSNotification!)
    {
        let curReach : NetworkReachability = sender.object as! NetworkReachability
        self.updateInterfaceWithReachability(curReach)
        
    }
    
    /*========================================================
    * Function Name:startIndicator
    * Function Parameter:uiView:UIView
    * Function Return Type:
    *Function Purpose:To display process are running indicator
    =========================================================*/
    func startIndicator(uiView:UIView, color : UIColor = UIColor(red: 237/255, green: 191/255, blue: 47/255, alpha: 1.0))
    {
        if(!UIApplication.sharedApplication().isIgnoringInteractionEvents()) {
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        }
        
        self.navigationController?.navigationBar.userInteractionEnabled = false
        //creating view to background while displaying indicator
//        let container: UIView = UIView()
//        container.frame = uiView.frame
//        //container.center = uiView.center
//        container.backgroundColor = UIColor.clearColor()
        
        //creating view to display lable and indicator
        let loadingView: UIView = UIView()
        loadingView.frame = CGRectMake(uiView.frame.size.width / 2 - 30, uiView.frame.size.height / 2 - 90, 60, 60)
        //loadingView.center = uiView.center
        loadingView.backgroundColor =  UIColor.clearColor()
        loadingView.clipsToBounds = true
        loadingView.layer.cornerRadius = 10
        
        //Preparing activity indicator to load
        self.activityIndicator = UIActivityIndicatorView()
        self.activityIndicator.frame = ACTIVITY_INDICATOR_FRAME
        self.activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.Gray
        self.activityIndicator.color = color
        self.activityIndicator.bounds = CGRectMake(-10, -10, loadingView.frame.size.width / 2, loadingView.frame.size.height / 2)
        loadingView.addSubview(activityIndicator)
        
        //container.addSubview(loadingView)
        uiView.addSubview(loadingView)
        self.activityIndicator.startAnimating()
    }
    
    /*========================================================
    * Function Name:stopIndicator
    * Function Parameter: stopIndicator
    * Function Return Type: nil
    *Function Purpose:To remove display process are running indicator
    =========================================================*/
    func stopIndicator()
    {
        self.navigationController?.navigationBar.userInteractionEnabled = true
     //   if let _ = self.activityIndicator.isAnimating()
       // {
            self.activityIndicator.stopAnimating()
            if let _ = self.activityIndicator as UIActivityIndicatorView?
            {
              self.activityIndicator.superview?.removeFromSuperview()
              // ((self.activityIndicator.superview as UIView!).superview as UIView!).removeFromSuperview()
            }
       // }
         if(UIApplication.sharedApplication().isIgnoringInteractionEvents()) {
            UIApplication.sharedApplication().endIgnoringInteractionEvents()
        }
    }
    
    func startIndicatorforWishList(uiView:UIView)
    {
        if(!UIApplication.sharedApplication().isIgnoringInteractionEvents()) {
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        }
        
        self.navigationController?.navigationBar.userInteractionEnabled = false
        //creating view to background while displaying indicator
//        let container: UIView = UIView()
//        container.frame = uiView.frame
//        //container.center = uiView.center
//        container.backgroundColor = UIColor.clearColor()
        
        //creating view to display lable and indicator
        let loadingView: UIView = UIView()
        loadingView.frame = CGRectMake(uiView.frame.size.width / 2 - 30, uiView.frame.size.height / 2 - 10, 60, 60)
        //loadingView.center = uiView.center
        loadingView.backgroundColor =  UIColor.clearColor()
        loadingView.clipsToBounds = true
        loadingView.layer.cornerRadius = 10
        
        //Preparing activity indicator to load
        self.activityIndicator = UIActivityIndicatorView()
        self.activityIndicator.frame = ACTIVITY_INDICATOR_FRAME
        self.activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.Gray
        self.activityIndicator.bounds = CGRectMake(-10, -10, loadingView.frame.size.width / 2, loadingView.frame.size.height / 2)
        loadingView.addSubview(activityIndicator)
        
        //container.addSubview(loadingView)
        uiView.addSubview(loadingView)
        self.activityIndicator.startAnimating()
    }

    
    /*===================================================
    * function Name : startIndicator
    * function Params: nil
    * fuction  Return type: nil
    * function Purpose: to start indicator
    ===================================================*/
    /*func startIndicator()
    {
        if(!UIApplication.sharedApplication().isIgnoringInteractionEvents()) {
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        }
        self.activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.WhiteLarge)
        self.view.addSubview(self.activityIndicator!)
        self.activityIndicator?.center = CGPointMake(self.view.frame.size.width / 2, self.view.frame.size.height / 2)
        self.activityIndicator?.color = UIColor(red: 249/255, green: 202/255, blue: 71/255, alpha: 1)
        self.activityIndicator?.startAnimating()
    }
    
    /*===================================================
    * function Name : stopIndicator
    * function Params: nil
    * fuction  Return type: nil
    * function Purpose: to stop indicator
    ===================================================*/
    func stopIndicator()
    {
        self.activityIndicator?.stopAnimating()
        self.activityIndicator?.removeFromSuperview()
        if(UIApplication.sharedApplication().isIgnoringInteractionEvents()) {
            UIApplication.sharedApplication().endIgnoringInteractionEvents()
        }
        
    }*/
    
    
    func showAlertView(message:NSString)
    {
        let alert = UIAlertView()
        alert.title = "Fly2Kart"
        alert.message = message as String
        alert.addButtonWithTitle("Ok")
        alert.show()
    }
  
    func showErrorAlertView()
    {
      self.alertView.title = "Fly2Kart"
      self.alertView.message = "Oops! something went wrong please wait a moment and try again."
      self.alertView.addButtonWithTitle("Ok")
      self.alertView.show()
        //self.alertView.showError("Fly2Kart", subTitle: "oops! something went wrong please wait a moment and try again.")
    }
    
    /*========================================================
    * function Name: setNavigationBarWithBackOption
    * function Purpose: to set navigation bar for view
    * function Parameters: title: NSString
    * function ReturnType: nil
    *=======================================================*/
    
    func setNavigationBarWithBackOption(title: NSString)
    {
        // Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 18, 25)
        btnLeft.exclusiveTouch = true
        let addImage:UIImage = UIImage(named: "BackArrow1")!
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft!.addTarget(self, action: "handleBackOption:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = true
        self.receiveBadgeForCart()
    }
    
    /*========================================================
    * function Name: setNavigationBarWithOnlyleftmenubutton
    * function Purpose: to set navigation bar for view
    * function Parameters: title: NSString
    * function ReturnType: nil
    *=======================================================*/
    
    func setNavigationBarWithOnlyleftmenubutton(title: NSString)
    {
        //Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 25, 25)//NavBarLeftButtonFrame
        btnLeft.exclusiveTouch = true
        let addImage:UIImage = UIImage(named: "menu-alt-512")!
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft!.addTarget(self, action: "didTapOpenMenu:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
        //self.navigationController?.showSGProgressWithDuration(1.75)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = true
        
    }

    /*========================================================
    * function Name: setNavigationBarWithOnlyleftmbackbutton
    * function Purpose: to set navigation bar for view
    * function Parameters: title: NSString
    * function ReturnType: nil
    *=======================================================*/
    
    func setNavigationBarWithOnlyleftmbackbutton(title: NSString)
    {
        // Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 18, 25)
        let addImage:UIImage = UIImage(named: "BackArrow1")!
        btnLeft.exclusiveTouch = true
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft!.addTarget(self, action: "handleBackOption:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
         // self.navigationController?.showSGProgressWithDuration(1.75)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = true
        
    }
    
    func setNavigationBarWithonlyWishListOption(title: NSString)
    {
        // Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 18, 25)
        btnLeft.exclusiveTouch = true
        let addImage:UIImage = UIImage(named: "BackArrow1")!
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft!.addTarget(self, action: "handleBackOption:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
         // self.navigationController?.showSGProgressWithDuration(1.75)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = true
        
        let btnLike:UIButton! = UIButton()
        btnLike!.frame = NAVIGATION_BUTTON_RIGHT_BUTTON_FRAME
        btnLike.exclusiveTouch = true
        btnLike!.setBackgroundImage(UIImage(named: "WishListIcon"), forState: UIControlState.Normal)
        btnLike!.addTarget(self, action: "didtapWishListmenu:",forControlEvents: UIControlEvents.TouchUpInside)
        btnLike!.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Right
        let rightItem:UIBarButtonItem = UIBarButtonItem(customView: btnLike!)
        self.navigationItem.rightBarButtonItem = rightItem
        
    }
    
    func setNavigationBarWithonlyCartOption(title: NSString)
    {
        // Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 18, 25)
        let addImage:UIImage = UIImage(named: "BackArrow1")!
        btnLeft.exclusiveTouch = true
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft!.addTarget(self, action: "handleBackOption:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = true
        
        if let badgeCounterVal = NSUserDefaults.standardUserDefaults().valueForKey("cartBadgeCounter")
        {
            badgeCounter = badgeCounterVal as! Int
        }
        
        let rightView = UIView(frame:  CGRectMake(0, 0, 30, 30))        
        btnCartRight = UIButton(frame:  CGRectMake(0, 0, 30, 30))
        btnCartRight.exclusiveTouch = true
        btnCartRight!.setBackgroundImage(UIImage(named: "cart"), forState: UIControlState.Normal)
        btnCartRight.tag=200
        btnCartRight.addTarget(self, action: "didtapRightCartmenu:", forControlEvents: UIControlEvents.TouchUpInside)
        btnCartRight.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Right
       
        rightView.addSubview(btnCartRight)
        
        if(badgeCounter > 0)
        {
            badgeButton = UIButton(frame:  CGRectMake(12, 0, 18, 18))
            badgeButton.setTitle(NSString(format: "%d", badgeCounter) as String, forState: UIControlState.Normal)
            badgeButton.titleLabel?.font = UIFont.systemFontOfSize(9)
            badgeButton.titleLabel?.textColor = UIColor.whiteColor()
            badgeButton.layer.cornerRadius = 8
            badgeButton.backgroundColor = UIColor(red: 20/255, green: 88/255, blue: 135/255, alpha: 1.0)
            badgeButton.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Center
            badgeButton.addTarget(self, action: "didtapRightCartmenu:", forControlEvents: UIControlEvents.TouchUpInside)
            rightView.addSubview(badgeButton)
        }
        let rightItem:UIBarButtonItem = UIBarButtonItem(customView: rightView)
         // self.navigationController?.showSGProgressWithDuration(1.75)
        self.navigationItem.rightBarButtonItem = rightItem
        
    }
    
    func didtapWishListmenu(sender: UIButton)
    {
        // Move on WishList
        let wishListVC = self.storyboard?.instantiateViewControllerWithIdentifier(WishListVCIdentifier) as! WishListViewController
        for vc in (self.navigationController?.viewControllers)! {
            if (vc.isKindOfClass(ProductViewController.self)){
                wishListVC.wishListDelegate = (vc as! ProductViewController).self
                break
            }
        }
        self.navigationController?.pushViewController(wishListVC, animated: true)
    }
    
    /*========================================================
    * function Name: handleBack
    * function Purpose: Go back to the previous view
    * function Parameters: sender: AnyObject
    * function ReturnType: nil
    *=======================================================*/
    
    @IBAction func handleBackOption(sender: AnyObject)
    {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func setNavigationBarForCart(title: NSString)
    {
        //Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 25, 25)//NavBarLeftButtonFrame
        let addImage:UIImage = UIImage(named: "menu-alt-512")!
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft.exclusiveTouch = true
        btnLeft!.addTarget(self, action: "didTapOpenMenu:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = true
        
        let btnRight:UIButton! = UIButton()
        btnRight.tag = 100
        btnRight!.frame = NAVIGATION_BUTTON_RIGHT_BUTTON_FRAME
        btnRight.exclusiveTouch = true
        btnRight!.setBackgroundImage(UIImage(named: "WishListIcon"), forState: UIControlState.Normal)
        btnRight!.addTarget(self, action: "didtapWishListmenu:",forControlEvents: UIControlEvents.TouchUpInside)
        btnRight!.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Right
        let rightItem:UIBarButtonItem = UIBarButtonItem(customView: btnRight!)
       //   self.navigationController?.showSGProgressWithDuration(1.75)
        self.navigationItem.rightBarButtonItem = rightItem
        
    }
    
    /*========================================================
    * function Name: setNavigationBarWithBackOption
    * function Purpose: to set navigation bar for view
    * function Parameters: title: NSString
    * function ReturnType: nil
    *=======================================================*/
    
    func setNavigationBarWithMenuOption(title: NSString)
    {
        //Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 25, 25)//NavBarLeftButtonFrame
        let addImage:UIImage = UIImage(named: "menu-alt-512")!
        btnLeft.exclusiveTouch = true
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft!.addTarget(self, action: "didTapOpenMenu:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = true
        //  self.navigationController?.showSGProgressWithDuration(1.75)
        self.receiveBadgeForCart()
        
        /*btnRight.tag = 100
        btnRight!.frame = NAVIGATION_BUTTON_RIGHT_BUTTON_FRAME
        btnRight!.setBackgroundImage(UIImage(named: "user"), forState: UIControlState.Normal)
        btnRight!.addTarget(self, action: "didtapRightmenu:",forControlEvents: UIControlEvents.TouchUpInside)
        btnRight!.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Right
        let rightItem:UIBarButtonItem = UIBarButtonItem(customView: btnRight!)
        self.navigationItem.rightBarButtonItem = rightItem*/
        
    }
    
    func didtapRightSearchmenu(sender: UIButton)
    {
        if let _: UIView = self.objRightmenu
        {
            self.objRightmenu.removeFromSuperview()
        }
       if(sender.tag == 300)
       {
//            self.navigationItem.titleView?.hidden=true
//            self.searchBar.becomeFirstResponder()
//            self.serchView.addSubview(self.searchBar)
//            self.serchView.backgroundColor = UIColor.whiteColor()
//            self.serchView.layer.cornerRadius=5
//            self.serchView.layer.masksToBounds=true
//            self.navigationItem.titleView?.hidden=true
//            let rightNavBarButton = UIBarButtonItem(customView:self.serchView)
//            self.navigationItem.rightBarButtonItem = rightNavBarButton
            for vc in (self.navigationController?.viewControllers)! {
                if (vc.isKindOfClass(SearchViewController.self)){
                    self.navigationController?.popToViewController(vc, animated: true)
                    return
                }
            }
            let searchVC = self.storyboard?.instantiateViewControllerWithIdentifier(SearchVCIdentifier) as! SearchViewController
            self.navigationController?.pushViewController(searchVC, animated: true)
        }
    }
    
    // Searchbar delegate methods
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar)
    {
        searchBar.text = ""
        self.navigationItem.titleView?.hidden = false
        let rightNavBarButton = UIBarButtonItem(customView:self.btnSearch)
        self.navigationItem.rightBarButtonItem = rightNavBarButton
        self.searchFlag=false
        self.receiveBadgeForCart()
        self.searchBar.resignFirstResponder()
    }

    
    func didtapRightCartmenu(sender: UIButton)
    {
        self.btnUserRight.tag = 100
        self.objRightmenu.removeFromSuperview()
        let cnt: Int = (self.navigationController?.viewControllers.count)!
        let vc = self.navigationController?.viewControllers[cnt-1] as UIViewController!
        if (!vc.isKindOfClass(ShoppingCartViewController)) {
            let myCartVC = self.storyboard?.instantiateViewControllerWithIdentifier(MyCartVCIdentifier) as! MyCartViewController
            self.navigationController?.pushViewController(myCartVC, animated: true)
        }
    }
    func didtapRightmenu(sender: UIButton)
    {
        if let _: UIView = self.objRightmenu
        {
            self.objRightmenu.removeFromSuperview()
        }

        if(sender.tag == 100)
        {
            self.objRightmenu = (UINib(nibName: "RightMenuView", bundle: nil).instantiateWithOwner(nil, options: nil)[0] as? RightMenuView)!
            self.objRightmenu.layer.shadowColor = UIColor.blackColor().CGColor
            self.objRightmenu.layer.shadowOpacity = 1.0
            self.objRightmenu.layer.shadowRadius = 10.0
            self.objRightmenu.delegate = self
            
            if let providerEmail = self.userdefaults.valueForKey("AlreadyLogin") as? NSString
            {
                if providerEmail.length > 0
                {
                    self.objRightmenu.frame = CGRectMake(self.view.frame.size.width  - objRightmenu.frame.size.width, 0, objRightmenu.frame.size.width, 315)
                    self.objRightmenu.tblMenu.frame.size.height = 315
                }
            }
            else
            {
                self.objRightmenu.frame = CGRectMake(self.view.frame.size.width  - objRightmenu.frame.size.width, 0, objRightmenu.frame.size.width, 225)
                self.objRightmenu.tblMenu.frame.size.height = 225
            }
            
            self.view.addSubview(self.objRightmenu)
            sender.tag = 200
        }
        else
        {
            self.objRightmenu.removeFromSuperview()
            sender.tag = 100
        }
    }
    
    /*========================================================
    * function Name: setNavigationBarWithOnlyleftmbackbutton
    * function Purpose: to set navigation bar for Address View
    * function Parameters: title: NSString
    * function ReturnType: nil
    *=======================================================*/
    
    func setNavigationBarWithOnlyleftBackbutton(title: NSString)
    {
        // Left Navigation Item
        let btnLeft:UIButton! = UIButton()
        btnLeft!.frame = CGRectMake(0, 0, 18, 25)
        btnLeft.exclusiveTouch = true
        let addImage:UIImage = UIImage(named: "BackArrow1")!
        btnLeft.exclusiveTouch = true
        btnLeft!.setBackgroundImage(addImage, forState: UIControlState.Normal)
        btnLeft!.addTarget(self, action: "handleBackOption:",forControlEvents: UIControlEvents.TouchUpInside)
        let leftItem:UIBarButtonItem = UIBarButtonItem(customView: btnLeft!)
        self.navigationItem.leftBarButtonItem = leftItem
        
        // Title of Navigation Item
        let navigationTitleLbl:UILabel = UILabel(frame:CGRectMake(0, 0, 320, 40.0))
        navigationTitleLbl.text = title as String
        navigationTitleLbl.font =  UIFont.boldSystemFontOfSize(18)
        navigationTitleLbl.font =  UIFont(name: "helvetica", size: 18)
        navigationTitleLbl.textColor=UIColor.whiteColor()
        navigationTitleLbl.textAlignment = NSTextAlignment.Center
        navigationTitleLbl.frame = CGRectMake(100, 0.0, 100, 100)
        self.navigationItem.titleView = navigationTitleLbl
         // self.navigationController?.showSGProgressWithDuration(1.75)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "Navbar"), forBarMetrics: UIBarMetrics.Default)
        self.navigationController?.navigationBar.translucent = false
        
    }
    
    /*===================================================
    * function Name : didTapOpenMenu
    * function Params: sender
    * fuction  Return type : nil
    * function Purpose: In side menu tap method
    ===================================================*/
    func didTapOpenMenu(sender: UIBarButtonItem)
    {
        self.btnUserRight.tag = 100
        objRightmenu.removeFromSuperview()
  
        if let sideMenuController = self.sideMenuController() {
            sideMenuController.openMenu()
        }
    }
    
    func receiveNotificationFortag(notification  :NSNotification)
    {
        self.btnUserRight.tag = 100
        self.objRightmenu.removeFromSuperview()
    }
    
    func receiveBadgeForCart()
    {
        if let badgeCounterVal = NSUserDefaults.standardUserDefaults().valueForKey("cartBadgeCounter")
        {
            badgeCounter = badgeCounterVal as! Int
        }
        
        let rightView = UIView(frame:  CGRectMake(0, 0, 30, 30))
        //rightView.backgroundColor = UIColor.redColor()

        btnCartRight = UIButton(frame:  CGRectMake(0, 0, 30, 30))
        btnCartRight.exclusiveTouch = true
        btnCartRight!.setBackgroundImage(UIImage(named: "cart"), forState: UIControlState.Normal)
        btnCartRight.tag=200
        btnCartRight.addTarget(self, action: "didtapRightCartmenu:", forControlEvents: UIControlEvents.TouchUpInside)
        btnCartRight.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Right
        rightView.addSubview(btnCartRight)
        
        self.searchBar.placeholder = "Search"
        self.searchBar.delegate = self
        self.searchBar.showsCancelButton = true
        self.searchBar.tintColor=UIColor.whiteColor()
        let view: UIView = self.searchBar.subviews[0] 
        let subViewsArray = view.subviews
        
        for subView in subViewsArray  {
            if subView.isKindOfClass(UITextField){
                subView.tintColor = UIColor(red: 20/255, green: 88/255, blue: 135/255, alpha: 1.0)
            }
        }
        self.btnSearch = UIButton(frame:  CGRectMake(0, 0, 25, 25))
        self.btnSearch.exclusiveTouch = true
        self.btnSearch.setBackgroundImage(UIImage(named: "Search_icon"), forState: UIControlState.Normal)
        self.btnSearch.tag=300
        self.btnSearch.addTarget(self, action: "didtapRightSearchmenu:", forControlEvents: UIControlEvents.TouchUpInside)
        self.btnSearch.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Right
        UISearchBar.appearance().setBackgroundImage(UIImage(named: "Navbar"), forBarPosition: UIBarPosition.Any, barMetrics: UIBarMetrics.Default)
        
        
        btnUserRight = UIButton(frame:  CGRectMake(0, 0, 15, 33))
       // btnUserRight = UIButton(frame:  CGRectMake(0, 0, 30, 30))
        btnUserRight.exclusiveTouch = true
        btnUserRight!.setBackgroundImage(UIImage(named: "user"), forState: UIControlState.Normal)
        btnUserRight.tag=100
        btnUserRight.addTarget(self, action: "didtapRightmenu:", forControlEvents: UIControlEvents.TouchUpInside)
        btnUserRight.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Right
        
        if(badgeCounter > 0)
        {
            badgeButton = UIButton(frame:  CGRectMake(12, 0, 18, 18))
            badgeButton.setTitle(NSString(format: "%d", badgeCounter) as String, forState: UIControlState.Normal)
            badgeButton.titleLabel?.font = UIFont.systemFontOfSize(9)
            badgeButton.titleLabel?.textColor = UIColor.whiteColor()
            badgeButton.layer.cornerRadius = 8
            badgeButton.backgroundColor = UIColor(red: 20/255, green: 88/255, blue: 135/255, alpha: 1.0)
            badgeButton.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Center
            badgeButton.addTarget(self, action: "didtapRightCartmenu:", forControlEvents: UIControlEvents.TouchUpInside)
            rightView.addSubview(badgeButton)
        }
        
        let rightItem:UIBarButtonItem = UIBarButtonItem(customView: rightView)
        let rightSearchItem:UIBarButtonItem = UIBarButtonItem(customView: self.btnSearch)
        let btnItem = UIBarButtonItem(customView: btnUserRight)
           self.navigationItem.rightBarButtonItems = [btnItem,rightItem, rightSearchItem]
       // self.navigationItem.rightBarButtonItems = [btnItem, rightSearchItem, rightItem]
    }
    
    func selectedIndex(index: Int, counter : Int)
    {
        if(counter == 4)
        {
            if (index == 0)
            {
                let loginVC = self.storyboard?.instantiateViewControllerWithIdentifier(SelectLoginVCIdentifier) as! SelectLoginViewController
                self.navigationController?.pushViewController(loginVC, animated: true)
            }
            else if (index == 1) {
                let trackOrderVC = self.storyboard?.instantiateViewControllerWithIdentifier(TrackOrderVCIdentifier) as! TrackOrderViewController
                self.navigationController?.pushViewController(trackOrderVC, animated: true)
            }
            else if (index == 2)
            {
                let wishListVC = self.storyboard?.instantiateViewControllerWithIdentifier(WishListVCIdentifier) as! WishListViewController
                for vc in (self.navigationController?.viewControllers)! {
                    if (vc.isKindOfClass(ProductViewController.self)){
                        wishListVC.wishListDelegate = (vc as! ProductViewController).self
                        break
                    }
                }
                self.navigationController?.pushViewController(wishListVC, animated: true)
            }
            else if (index == 3)
            {
                // FAQ section
                let FAQVC = self.storyboard?.instantiateViewControllerWithIdentifier(KFAQViewControllerIdentifier) as! FAQViewController
                self.navigationController?.pushViewController(FAQVC, animated: true)
            }
//            else if (index == 4)
//            {
//                // Contact us section
//                let contactUsVC = self.storyboard?.instantiateViewControllerWithIdentifier(ContactUsVCIdentifier) as! ContactUsViewController
//                self.navigationController?.pushViewController(contactUsVC, animated: true)
//            }
        }
        else
        {
            if(index == 0)
            {
                //My Profile
                let editProfileVC = self.storyboard?.instantiateViewControllerWithIdentifier(EditProfileViewControllerIdentifier) as! EditProfileViewController
                self.navigationController?.pushViewController(editProfileVC, animated: true)
            }
            if (index == 1)
            {
                // my orders
                let OrderHisotryVC = self.storyboard?.instantiateViewControllerWithIdentifier(OrderhistoryVCIdentifier) as! OrderHistoryViewController
                self.navigationController?.pushViewController(OrderHisotryVC, animated: true)

            }
            else if (index == 2)
            {
                // Wishlist
                let wishListVC = self.storyboard?.instantiateViewControllerWithIdentifier(WishListVCIdentifier) as! WishListViewController
                for vc in (self.navigationController?.viewControllers)! {
                    if (vc.isKindOfClass(ProductViewController.self)){
                        wishListVC.wishListDelegate = (vc as! ProductViewController).self
                        break
                    }
                }
                self.navigationController?.pushViewController(wishListVC, animated: true)
            }
            else if (index == 3)
            {
                // Addresses
                let ListAddressVC = self.storyboard?.instantiateViewControllerWithIdentifier(ListAddressVDIdentifier) as! ListAddressViewController
                self.navigationController?.pushViewController(ListAddressVC, animated: true)
            }
            else if (index == 4)
            {
                // FAQ
                let FAQVC = self.storyboard?.instantiateViewControllerWithIdentifier(KFAQViewControllerIdentifier) as! FAQViewController
                self.navigationController?.pushViewController(FAQVC, animated: true)
            }
//            else if (index == 5)
//            {
//               //Contact us
//                let contactUsVC = self.storyboard?.instantiateViewControllerWithIdentifier(ContactUsVCIdentifier) as! ContactUsViewController
//                self.navigationController?.pushViewController(contactUsVC, animated: true)
//            }
            else if (index == 5)
            {
                NSUserDefaults.standardUserDefaults().setObject(0, forKey: "cartBadgeCounter")
                NSUserDefaults.standardUserDefaults().synchronize()
                self.userdefaults.removeObjectForKey("productDicArray")
                self.userdefaults.removeObjectForKey("User")
                // Google Logout
                 GIDSignIn.sharedInstance().signOut()
                NSNotificationCenter.defaultCenter().postNotificationName("NameUpdation", object: nil)
                // Facebook Logout
                let loginManager = FBSDKLoginManager()
                loginManager.logOut()
                
                userdefaults.removeObjectForKey("AlreadyLogin")
                let homeVC = self.storyboard?.instantiateViewControllerWithIdentifier(HomeVCIdentifier) as! HomeViewController
                let _ = UINavigationController(rootViewController: homeVC)
                self.navigationController?.viewControllers[0] = homeVC
                self.navigationController?.popToRootViewControllerAnimated(false)
            }
            
        }
    }
}
