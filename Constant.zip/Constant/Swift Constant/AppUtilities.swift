//
//  AppUtilities.swift
//  NationalGPRApp
//
//  Created by Bigscal on 13/09/14.
//  Copyright (c) 2014 Bigscal. All rights reserved.
//

import Foundation
import UIKit
import SystemConfiguration

class AppUtilities : NSObject{
    
    /*========================================================
    * function Name: setButtonCorner
    * function Purpose: to set button corner
    * function Parameters: btn: UIButton
    * function ReturnType: nil
    *=======================================================*/
    class func setButtonCorner(btn: UIButton) {

        btn.layer.cornerRadius = 5.0
    }
    
    /*========================================================
    * function Name: setCircleImage
    * function Purpose: to set button corner
    * function Parameters: btn: UIButton
    * function ReturnType: nil
    *=======================================================*/
    class func setCircleImage(btn: AnyObject) {
        if #available(iOS 8.0, *) {
            btn.layer.cornerRadius = btn.frame.size.height / 2
            btn.layer.masksToBounds = true
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    class func converHexToUIColor(hex: NSString) -> UIColor {
        
        var cString:String = hex.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet()).uppercaseString
        
        if (cString.hasPrefix("#")) {
            cString = (cString as NSString).substringFromIndex(1)
        }
        
        if (cString.characters.count != 6) {
            return UIColor.grayColor()
        }
        
        let rString = (cString as NSString).substringToIndex(2)
        let gString = ((cString as NSString).substringFromIndex(2) as NSString).substringToIndex(2)
        let bString = ((cString as NSString).substringFromIndex(4) as NSString).substringToIndex(2)
        
        var r:CUnsignedInt = 0, g:CUnsignedInt = 0, b:CUnsignedInt = 0;
        NSScanner(string: rString).scanHexInt(&r)
        NSScanner(string: gString).scanHexInt(&g)
        NSScanner(string: bString).scanHexInt(&b)
        
        
        return UIColor(red: CGFloat(r) / 255.0, green: CGFloat(g) / 255.0, blue: CGFloat(b) / 255.0, alpha: CGFloat(1))
    }
    
    /*========================================================
    * function Name: setButtonTextAlignment
    * function Purpose: to set button text alignment
    * function Parameters: btn: UIButton
    * function ReturnType: nil
    *=======================================================*/
    class func setButtonTextAlignment(btn: UIButton,alignment: UIControlContentHorizontalAlignment) {
        btn.contentHorizontalAlignment = alignment
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -2)
    }
    
    /*========================================================
    * function Name: addRightLayer
    * function Purpose: to set right side border
    * function Parameters: btn: UIButton
    * function ReturnType: nil
    *=======================================================*/
    class func addRightLayer(imgView : UIImageView,color:UIColor,width:CGFloat) {
       
        let subLayer=CALayer()
        subLayer.backgroundColor=color.CGColor
        subLayer.frame=CGRectMake(imgView.bounds.size.width-1, 0, width, imgView.frame.size.height)
        imgView.layer.addSublayer(subLayer)

    }

    /*========================================================
    * function Name: setLabelBGColorNTextColor
    * function Purpose: to set BGColor and Text Color of UILabel
    * function Parameters: bgColor: UIColor,textColor: UIColor,multiLbl : UILabel...
    * function ReturnType: nil
    *=======================================================*/
    class func setLabelBGColorNTextColor(bgColor: UIColor,textColor: UIColor,multiLbl : UILabel...) {
        for lbl:UILabel in multiLbl {
            lbl.backgroundColor = bgColor
            lbl.textColor = textColor
        }
    }
    
    /*========================================================
    * function Name: setImageInBuuton
    * function Purpose: to set image in the button
    * function Parameters: btn: AnyObject,frame: CGRect,imgName: NSString
    * function ReturnType: nil
    *=======================================================*/
    class func setImageInBuuton(btn: AnyObject,frame: CGRect,imgName: NSString) {
        let imgView: UIImageView = UIImageView(frame: frame)
        imgView.image = UIImage(named: imgName as String)
        btn.addSubview(imgView)
    }
    /*========================================================
    * function Name: setViewCorner
    * function Purpose: to set the corner radius of uiview
    * function Parameters: view: UIView,radius: CGFloat,width: CGFloat,color: UIColor
    * function ReturnType: nil
    *=======================================================*/
    class func setViewCorner(view: UIView,radius: CGFloat,width: CGFloat,color: UIColor) {
        
        view.layer.cornerRadius = radius
        view.layer.borderWidth = width
        view.layer.borderColor = color.CGColor
    }
    
    /*========================================================
    * function Name: setScrollViewContentSize
    * function Purpose: to set content size of scrollview
    * function Parameters: scrollView: UIScrollView,width: CGFloat,height: CGFloat
    * function ReturnType: nil
    *=======================================================*/
    class func setScrollViewContentSize(scrollView: UIScrollView,width: CGFloat,height: CGFloat) {
        scrollView.contentSize = CGSize(width: width, height: height)
    }
    
    /*========================================================
    * function Name: sizeToFitLabel
    * function Purpose: to set the text in the label
    * function Parameters: lbl: UILabel
    * function ReturnType: nil
    *=======================================================*/
    class func sizeToFitLabel(lbl: UILabel) {
        lbl.numberOfLines = 0
        lbl.sizeToFit()
    }
    
    /*========================================================
    * function Name: resignTextField
    * function Purpose: to resign textfield
    * function Parameters: textField: UITextField
    * function ReturnType: nil
    *=======================================================*/
    class func resignTextField(textField: UITextField) {
        if(textField.isFirstResponder()) {
            textField.resignFirstResponder()
        }
    }
    
    /*========================================================
    * function Name: checkForFirstResponder
    * function Purpose: to error remove border from image
    * function Parameters: textField: UITextField
    * function ReturnType: nil
    *=======================================================*/
    class func checkForFirstResponder(textField: UITextField,imgView: UIImageView) {
        if(textField.isFirstResponder()) {
            removeErrorBorder(imgView)
        }
    }
    
    /*========================================================
    * function Name: drawErrorBorder
    * function Purpose: to show red border on missing information
    * function Parameters: view: UIView,color: UIColor
    * function ReturnType: nil
    *=======================================================*/
    class func drawErrorBorder(view: AnyObject,width: CGFloat,borderColor: UIColor) {
        if #available(iOS 8.0, *) {
            view.layer.borderWidth = width
            view.layer.borderColor = borderColor.CGColor
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    /*========================================================
    * function Name: drawErrorBorder
    * function Purpose: to show red border on missing information
    * function Parameters: view: UIView,color: UIColor
    * function ReturnType: nil
    *=======================================================*/
    class func removeErrorBorder(view: AnyObject) {
        if #available(iOS 8.0, *) {
            view.layer.borderWidth = 0
        } else {
            // Fallback on earlier versions
        }
        //view.layer.borderColor = UIColor.clearColor().CGColor
    }
    
    
    /*========================================================
    * function Name: isValidZipCode
    * function Purpose: check zipcode number is valid is valid
    * function Parameters: testStr: NSString
    * function ReturnType: Bool
    *=====================================================*/
    class func isValidZipCode(testStr: NSString)->Bool
    {
        let testStr1=self.formarNumber(testStr)
        let mobileRegEx = "[0-9]{6}";
        let mobileTest = NSPredicate(format: "SELF MATCHES %@", mobileRegEx)
        return mobileTest.evaluateWithObject(testStr1);
    }

    
    /*========================================================
    * function Name: showErrorLine
    * function Purpose: to show red line on missing information
    * function Parameters: view: UIView,color: UIColor
    * function ReturnType: nil
    *=======================================================*/
    class func changeErrorLineColor(view: UIView,bgColor: UIColor) {
        view.backgroundColor = bgColor
    }
    
    /*========================================================
    * function Name: showErrorMessage
    * function Purpose: to show alertview for error message
    * function Parameters: errorMessage: NSString,delegate: ViewController
    * function ReturnType: nil
    *=======================================================*/
    class func showErrorMessage(errorMessage: NSString) {
        let alert:UIAlertView = UIAlertView(title: APP_TITLE, message: errorMessage as String, delegate: nil, cancelButtonTitle: "OK")
        
        alert.show()
    }
    
    /*========================================================
    * function Name: isTextFieldEmpty
    * function Purpose: to check textfield is empty or not
    * function Parameters: textField: UITextField
    * function ReturnType: Bool
    *=======================================================*/
    class func isTextFieldEmpty(textField: UITextField) -> Bool{
        
        let test = (textField.text)!.stringByReplacingOccurrencesOfString(" ", withString: "") as NSString
        if(test.length > 0) {
            return false
        }
        else {
            return true
        }
    }
    
    /*========================================================
    * function Name: isTextViewEmpty
    * function Purpose: to check textview is empty or not
    * function Parameters: textField: UITextField
    * function ReturnType: Bool
    *=======================================================*/
    class func isTextViewEmpty(textView: UITextView) -> Bool{
        let test = (textView.text as NSString).stringByReplacingOccurrencesOfString(" ", withString: "") as NSString
        if(test.length > 0) {
            return false
        }
        else {
            return true
        }
    }
    
    /*========================================================
    * function Name: checkConfirmPassword
    * function Purpose: compare password and confirm password
    * function Parameters: pass: String,cpass: String
    * function ReturnType: Bool
    *=====================================================*/
    class func checkConfirmPassword(pass: String,cpass: String)->Bool
    {
        if(pass==cpass){
            return true
        }
        return false
    }
    
    /*========================================================
    * function Name: corneradiusToview
    * function Purpose: To make corner radius
    * function Parameters: UIView
    * function ReturnType: nil
    *=====================================================*/
    class  func  corneradiusToview(view:UIView, radius:CGFloat)
    {
        view.layer.cornerRadius=radius
        view.layer.masksToBounds = true
    }
    
    /*========================================================
    * function Name: corneradiusWithBorderToview
    * function Purpose:  corneradiusWithBorderToview
    * function Parameters: var view:UIView, var radius:CGFloat,var borderWidth:CGFloat
    * function ReturnType: nil
    *=====================================================*/
    class func  corneradiusWithBorderToview(view:UIView, radius:CGFloat,borderWidth:CGFloat)
    {
        view.layer.cornerRadius=radius
        view.layer.borderWidth=borderWidth
    }
    
    /*========================================================
    * function Name: isValidEmailAddress
    * function Purpose: check email address is valid
    * function Parameters: testStr: NSString
    * function ReturnType: Bool
    *=====================================================*/
    class func isValidEmailAddress(testStr: NSString)->Bool
    {
        let emailRegEx = "[A-Za-z][A-Z0-9a-z._%+-]+@[A-za-z0-9.-]+\\.[A-Za-z]{2,4}";
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(testStr);
    }
    
    /*========================================================
    * function Name: isValidMobile
    * function Purpose: check mobile number is valid is valid
    * function Parameters: testStr: NSString
    * function ReturnType: Bool
    *=====================================================*/
    class func isValidMobile(testStr: NSString)->Bool
    {
        let testStr1=self.formarNumber(testStr)
        let mobileRegEx = "[0-9]{10}";
        let mobileTest = NSPredicate(format: "SELF MATCHES %@", mobileRegEx)
        return mobileTest.evaluateWithObject(testStr1);
    }
    
    /*========================================================
    * function Name: drawRedBorderToTextfield
    * function Purpose: drawRedBorderToTextfield
    * function Parameters: var txtField:UITextField,var cornerRadius:CGFloat,var borderRadius:CGFloat
    * function ReturnType: nil
    *=====================================================*/
    class func drawRedBorderToTextfield( txtField:UITextField,cornerRadius:CGFloat,borderRadius:CGFloat)
    {
        txtField.layer.borderWidth=borderRadius
        txtField.layer.cornerRadius=cornerRadius
        txtField.layer.borderColor=UIColor.redColor().CGColor
        txtField.text=""
    }
    /*========================================================
    * Function Name: setCornerRadious
    * Function Parameter: UITextField, CGFloat
    * Function Return Type: nil
    *Function Purpose: To set cornerRadious
    =========================================================*/
    class func setCornerRadious(textField:UITextField!,cornerRadius:CGFloat)
    {
        textField.layer.cornerRadius=cornerRadius
        textField.layer.masksToBounds = true
        
    }
    /*========================================================
    * function Name: drawClearBorderToTextfield
    * function Purpose: drawClearBorderToTextfield
    * function Parameters: var txtField:UITextField,var cornerRadius:CGFloat,var borderRadius:CGFloat
    * function ReturnType: nil
    *=====================================================*/
    class func drawClearBorderToTextfield(txtField:UITextField,cornerRadius:CGFloat,borderRadius:CGFloat)
    {
        txtField.layer.borderWidth=borderRadius
        txtField.layer.cornerRadius=cornerRadius
        txtField.layer.borderColor=UIColor.lightGrayColor().CGColor
    }
    
    /*========================================================
    * function Name: drawLightGrayBroderAndRadiusToview
    * function Purpose: drawLightGrayBroderAndRadiusToview
    * function Parameters: var view:UIView?,var cornerRadius:CGFloat,var borderWidth:CGFloat
    * function ReturnType: nil
    *=====================================================*/
    class func drawLightGrayBroderAndRadiusToview(view:UIView?,cornerRadius:CGFloat,borderWidth:CGFloat)
    {
        view?.layer.borderWidth=borderWidth
        view?.layer.cornerRadius=cornerRadius
    }
    
    /*========================================================
    * function Name: trimText
    * function Purpose: To trim space of string
    * function Parameters:txtString:String
    * function ReturnType: NSString
    *=======================================================*/    
    class func trimText( txtString:String)-> NSString
    {
        let whiteSpace : NSCharacterSet = NSCharacterSet.whitespaceCharacterSet()
        let trimPet : NSString = txtString.stringByTrimmingCharactersInSet(whiteSpace)
        return trimPet
    }

    
    /*========================================================
    * function Name: ValidatePassword
    * function Purpose: check reenter password is match with above password
    * function Parameters: var strPassword:NSString,var strConfirmPassword:NSString
    * function ReturnType: nil
    *=====================================================*/
    class func ValidatePassword(strPassword:NSString,strConfirmPassword:NSString) ->Bool
    {
        return  strPassword.isEqualToString(strConfirmPassword as String) as Bool
    }
    
    /*========================================================
    * function Name: isValidateMobileNumber
    * function Purpose: check mobile number is valid or not
    * function Parameters: var MobileNumber:NSString
    * function ReturnType: bool
    *=====================================================*/
    class func isValidateMobileNumber(MobileNumber:NSString) -> Bool
    {
        //var mobileRegEx = "[0-9]{10}"
        //var mobileTest = NSPredicate(format: "SELF MATCHES %@", mobileRegEx)
       // return mobileTest!.evaluateWithObject(MobileNumber)
        return true
    }
    
    
    /*========================================================
    * function Name: paddingTextField
    * function Purpose: To add left padding in the textfield
    * function Parameters: textField:UITextField!,paddingWidth:CGFloat
    * function ReturnType: nil
    *=======================================================*/
    class func setPaddingTextField(textField:UITextField!,paddingWidth:CGFloat)
    {
        let paddingView:UIView = UIView(frame: CGRectMake(0, 0, paddingWidth, textField.frame.size.height))
        textField.leftView = paddingView
        textField.leftViewMode = UITextFieldViewMode.Always
    }

    /*========================================================
    * function Name: formarNumber
    * function Purpose: To format mobile number
    * function Parameters: mobileNo: NSString
    * function ReturnType: NSString
    *=======================================================*/
    class func formarNumber(var mobileNo: NSString) -> NSString {
        
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString("(", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString(")", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString(" ", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString("-", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString("+", withString: "")
        let length = mobileNo.length
        if(length > 10) {
            mobileNo = mobileNo.substringFromIndex(length-10)
        }
        return mobileNo
    }
    
    /*========================================================
    * function Name: getLength
    * function Purpose: To get length of mobile number field
    * function Parameters: mobileNo: NSString
    * function ReturnType: Int
    *=======================================================*/
    class func getLength(var mobileNo: NSString) -> Int{
        
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString("(", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString(")", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString(" ", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString("-", withString: "")
        mobileNo = mobileNo.stringByReplacingOccurrencesOfString("+", withString: "")
        let length = mobileNo.length
        return length
    }
    
    /*========================================================
    * function Name: isiPad
    * function Purpose: check device is ipad or iphone
    * function Parameters: nil
    * function ReturnType: bool
    *=====================================================*/
    class func isiPad()->Bool
    {
        return (UIDevice.currentDevice().userInterfaceIdiom == .Pad)
    }
    
    /*========================================================
    * function Name: getScreenWidth()
    * function Purpose: Get current devices width
    * function Parameters:
    * function ReturnType:
    *=======================================================*/
    class func getScreenWidth() -> CGFloat {
        let screenrect:CGRect = UIScreen.mainScreen().bounds
        return screenrect.width
    }
    
    /*========================================================
    * function Name: getScreenWidth()
    * function Purpose: Get current devices width
    * function Parameters:
    * function ReturnType:
    *=======================================================*/
    class func getScreenHeight() -> CGFloat {
        let screenrect:CGRect = UIScreen.mainScreen().bounds
        return screenrect.height
    }
    
    /*========================================================
    * Function Name:clearCacheImage
    * Function Parameter:
    * Function Return Type:
    *Function Purpose:To clear image cache from ram and disk
    =========================================================*/
//    class func clearCacheImage()
//    {
//        var imageCache=SDImageCache.sharedImageCache()
//        imageCache.clearDisk()
//        imageCache.clearMemory()
//    }
//    
    /*===================================================
    * function Name : extractTime
    * function Params: target : NSString
    * fuction  Return type: NSString
    * function Purpose: to convert time in AM or PM format
    ===================================================*/
    
    class func extractTime(target : NSString) -> NSString
    {
        var target : NSString = target.substringWithRange(NSRange(location: 11, length: 5))
        if(target.substringWithRange(NSRange(location: 0, length: 2)) >= "12")
        {
            let hour : NSString = target.substringWithRange(NSRange(location: 0, length: 2)) as NSString
            let i : Int = hour.integerValue - 12
            target = (String(i) + target.substringWithRange(NSRange(location: 2, length: 3)) as NSString as String) + " PM"
        }
        else
        {
            let hour : NSString = target.substringWithRange(NSRange(location: 0, length: 2)) as NSString
            let i : Int = hour.integerValue
            target = (String(i) + target.substringWithRange(NSRange(location: 2, length: 3)) as NSString as String) + " AM"
        }
        return target
    }
    
    
    /*===================================================
    * function Name : drawShadowToView
    * function Params: nil
    * fuction  Return type: nil
    * function Purpose: to draw shadow to heading view
    ===================================================*/
    class func drawShadowToView( productView: UIView)
    {
        let shadowPath = UIBezierPath(rect: (productView.bounds))
        productView.layer.masksToBounds = false
        productView.layer.shadowColor = UIColor.blackColor().CGColor
        productView.layer.shadowOffset = CGSizeMake(0.0, 5.0)
        productView.layer.shadowOpacity = 0.5
        productView.layer.shadowPath = shadowPath.CGPath
    }
    
    class func convertDateToString( formate:NSString, date:NSDate) -> NSString
    {
        let formatter: NSDateFormatter = NSDateFormatter()
        formatter.timeZone = NSTimeZone.systemTimeZone()
        formatter.dateFormat = formate as String
        let stringDate: NSString = formatter.stringFromDate(date)
        return stringDate
    }
    
    class func convertStringToDate(formate:NSString, string:NSString) -> NSDate
    {
        let formatter: NSDateFormatter = NSDateFormatter()
        formatter.dateFormat = formate as String
        let dateFromString:NSDate = formatter.dateFromString(string as String)!
        return dateFromString
    }

    /*========================================================
    * function Name: viewSlideInFromRightToLeft
    * function Purpose: to make transition of view from right to left
    * function Parameters: view
    * function ReturnType: nil
    *=======================================================*/
    class func viewSlideInFromRightToLeft(view: UIView)
    {
        let transition : CATransition = CATransition()
        transition.duration = 1.0
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromRight
        transition.delegate = self
        view.layer.addAnimation(transition, forKey: nil)
    }
    
    /*========================================================
    * function Name: viewSlideInFromRightToLeft
    * function Purpose: to make transition of view from right to left
    * function Parameters: view
    * function ReturnType: nil
    *=======================================================*/
    class func viewSlideInFromLeftToRight(view: UIView)
    {
        let transition : CATransition = CATransition()
        transition.duration = 1.0
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromLeft
        transition.delegate = self
        view.layer.addAnimation(transition, forKey: nil)
    }
    
    /*========================================================
    * function Name: viewSlideInFromRightToLeft
    * function Purpose: to make transition of view from right to left
    * function Parameters: view
    * function ReturnType: nil
    *=======================================================*/
    class func viewSlideInFromTopToBottom(view: UIView)
    {
        let transition : CATransition = CATransition()
        transition.duration = 1.0
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromBottom
        transition.delegate = self
        view.layer.addAnimation(transition, forKey: nil)
    }
    
    /*========================================================
    * function Name: viewSlideInFromRightToLeft
    * function Purpose: to make transition of view from right to left
    * function Parameters: view
    * function ReturnType: nil
    *=======================================================*/
    class func viewSlideInFromBottomToTop(view: UIView)
    {
        let transition : CATransition = CATransition()
        transition.duration = 1.0
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromTop
        transition.delegate = self
        view.layer.addAnimation(transition, forKey: nil)
    }
    
    class func setGoogleAnalytics(title: String) {
        let tracker = GAI.sharedInstance().defaultTracker
        tracker.set(kGAIScreenName, value: title)
        
        let builder = GAIDictionaryBuilder.createScreenView()
        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    
}