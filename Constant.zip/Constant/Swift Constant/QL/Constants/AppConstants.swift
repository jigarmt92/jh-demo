//
//  Appconstants.swift
//  PetApp
//
//  Created by Bigscal on 05/01/15.
//  Copyright (c) 2015 Bigscal. All rights reserved.
//

import UIKit
import Foundation

//Screen Resolution
let screenSize: CGRect = UIScreen.mainScreen().bounds
let IPHONE_4S_SIZE : CGFloat = 480
let IPHONE_5S_SIZE : CGFloat = 568
let IPHONE_6_SIZE : CGFloat = 667

//ViewController Identifier
let ViewControllerIdentifier =      "ViewController"
let CLEVCIdentifier =               "CLEViewController"
let MainMenuVCIdentifier =          "MainMenuViewController"
let CLEDetailVCIdentifier =         "CLEDetailViewController"
let LoginVCIdentifier =             "LoginViewController"
let TaskVCIdentifier =              "TaskViewController"
let ContactListVCIdentifier =       "ContactsListViewController"
let ContactDetailVCIdentifier =     "ContactDetailViewController"
let DocumentVCIdentifier =          "DocumentListViewController"
let ResourceDetailVCIdentifier =    "ResourceDetailViewController"
let InvestigatorVCIdentifier =      "InvestigatorViewController"
let CreateDocumentVCIdentifier =    "CreateDocumentViewController"
let ResourceCountryVCIdentifier =   "ResourceCountryViewController"
let ResourceStateVCIdentifier =     "ResourceStateViewController"
let ResorcesVCIdentifier =          "ResorcesViewController"
let CreateContactVCidentifier =     "CreateContactViewController"
let CasesVCIdentifier =             "CasesViewController"
let TimeManagementVCIdentifier =    "TimeManagementViewController"
let AccountingVCIdentifier =        "AccountingViewController"
let PeerToPeerVCIdentifier =        "PeerToPeerViewController"
let LawListVCIdentifier =           "LawListViewController"
let PostQuestionVCIdentifier =      "PostQuestionViewController"
let HistoryVCIdentifier =           "HistoryViewController"
let QuickSearchVCIdentifier =       "QuickSearchViewController"
let SearchCaseLawVCIdentifier =     "SearchCaseLawViewController"
let CalendarVCIdentifier =          "CalendarViewController"
let PeerToPeerQuestionVCIdentifier = "PeerToPeerQuestionViewController"
let PhoneDialVCIdentifier =         "PhoneDialViewController"
let QuestionLogVCIdentifier =       "QuestionLogViewController"
let TimeEntriesVCIdentifier =       "TimeEntriesViewController"
let CreateCaseVCIdentifier =        "CreateCaseViewController"
let CreateTaskVCIdentifier =        "CreateTaskViewController"
let CreateEventVCIdentifier =       "CreateEventViewController"
let CheckInternetConnVCIdentifier = "CheckInternetConnViewController"
let CallVCIdentifier =              "CallViewController"
let PhoneReceiveVC =                "PhoneReceiveViewController"
let CallHistoryVCIdentifier =       "CallHistoryViewController"
let TimeEntryVCIdentifier =         "TimeEntryViewController"
let SubUserVCIdentifier =           "SubUserViewController"
let CreateSubUsersVCIdentifier =    "CreateSubUsersViewController"
let AccessManagementVCIdentifier =  "AccessManagementViewController"
let GroupVCIdentifier =             "GroupViewController"
let GroupDescriptionVCIdentifier =  "GroupDescriptionViewController"
let MatterVCIdentifier =            "MatterViewIdentifier"
let CreateMatterVCIdentifier =      "CreateMatterIdentifier"
let MatterDetailVCIdentifier =      "MatterDetailsVC"
let NotesVCIdentifier =             "NotesViewIdentifier"
let CreateNoteVCIdentifier =        "CreateNoteVC"
let ExpenseVCIdentifier =           "ExpenseViewIdentifier"
let CreateExpVCIdentifier =         "CreateExpenseVC"
let ClientDetailVCIdentifier =      "ClientDetailViewController"
let DocumentTreeVCIdentifier =      "DocumentTreeViewController"
let LegalResearchVCIdentifier =     "LegalViewController"
let DetailResearchVCIdentifier =    "DetailResearchViewController"

// Button Tag
let btnChooseStatusTag =            101
let btnChooseBillingMethodTag =     102
let btnChooseClientTag =            103

let btnChooseAssigneeTag =          101
let btnChooseAssignerTag =          102
let btnChooseDueDateTag =           103
let btnChooseTaskCompleteDateTag =  104
let btnChoosePriorityTag =          105
let btnAddOptionTag =          106
let txtMatterTag =                  101

let btnChooseStartTimeTag =         101
let btnChooseEndTimeTag =           102

let btnReferralTag =                101
let btnSpecialityTag =              102

let btnStatusTag =                  101
let btnClientTag =                  102
let btnOptionTag =                  103
let btnPendingTag =                 104
let btnOpenTag =                    105
let btnCloseTag =                   106
let btnSeperationTag =              107
let btnIncidentTag =                108
let btnArrestDateTag =              109
let btnMrgDateTag =                 110
let btnNextCourtDateTag =           111
let btnArraignmentTag =             112
let btnFillingDateTag =             113
let btnPracticeTag =                114
let btnResponsibleTag =             115
let btnOriginTag =                  116
let btnTaskTag =                    117
let btnBillingTag =                 118
let btnHearingTag =                 119
let btnCourtTag =                   120
let btnProsecutorTag =              121
let btnRelatedMatterTag =           122
let btnRefSourceTag =               123
let btnPleaTag =                    124
let btnArrestOfficerTag =           125
let btnCircuitTag =                 126
let btnJudgeTag =                   127
let btnOpposingPartyTag =           128
let btnOpposingCounselTag =         129
let btnCommTag =                    130
let btnSelectCustomRateTag =        131

let btnMatterTag =                  107

//Comman Key Constant
let KDEVICE_TOCKEN =                "device_tocken"
let KAlertViewTitle =                "Quicklegal"

//Notification Keys
let KShowLoginScreen =              "BackToLoginScreen"
let KShowPhoneScreen =              "BackToPhoneScreen"
let KReloadScreen =                 "ReloadScreen"
let KDismisCallScreen =             "DismissCallScreen"
let KConnectWithNewUser =           "connectWithNewUser"

//Cell Height Constant For Question Message
let kBufferAmount =                 55
let kMinimumHeight =                83

//Timer keys
let start = "Start Timer"
let stop = "Stop Timer"
let resume = "Resume Timer"
let pause = "Pause Timer"

//Standard Date formate
let STANDARD_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ"
let APP_DATE_FORMAT = "YYYY-MM-dd"
let APP_DATE_FORMAT2 = "MMM dd,yyyy"

let PlaceholderImageForUser = UIImage(named: "creat a client 2")
