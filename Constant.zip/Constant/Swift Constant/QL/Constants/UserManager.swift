//
//  UserManager.swift
//  Quicklegal
//
//  Created by Bigscal Mini on 11/03/15.
//  Copyright (c) 2015 Bigscal Mini. All rights reserved.
//

import Foundation
import UIKit
let kLODAuthToken = "LOD_AUTH_TOKEN"
let kLODCurrentUser = "CurrentlyAuthenticatedUserKey"
let kLODFacebookInfo = "UsersFacebookInfo"

private let userManagerInstance = UserManager()

class UserManager: NSObject
{    
    var deviceToken:NSString?
    struct Static
    {
        static var instance: UserManager?
    }
    
    class var sharedManager: UserManager
    {
        if (Static.instance == nil)
        {
            Static.instance = UserManager()
        }
        return Static.instance!
    }
    
    func saveUser(var aUser:User)
    {
        self.persistCurrentlyAuthenticatedUser(aUser)
        self.persistAuthToken(aUser.authToken)
    }

    func saveDeviceToken(var aToken:NSString?)
    {
        if let token = aToken
        {
            self.deviceToken = token
        }
    }
    
    func getDeviceToken()-> NSString?
    {
        if let token = self.deviceToken
        {
            return token
        }
        return nil
    }
    
    func userIsAuthenticated() -> Bool
    {
        if let check:NSString = NSUserDefaults.standardUserDefaults().objectForKey(kLODAuthToken) as! NSString?
        {
            if (check.length > 0)
            {
                return true
            }
        }
        return false
    }
    
    func persistCurrentlyAuthenticatedUser(var aUser:User)
    {
        var userData:NSData = NSData()
        userData = NSKeyedArchiver.archivedDataWithRootObject(aUser)
        NSUserDefaults.standardUserDefaults().setObject(userData, forKey:kLODCurrentUser)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    func persistAuthToken(aAuthToken:NSString)
    {
        NSUserDefaults.standardUserDefaults().setObject(aAuthToken, forKey:kLODAuthToken)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    func currentAuthToken() -> NSString
    {
        var token:NSString = NSUserDefaults.standardUserDefaults().objectForKey(kLODAuthToken) as! NSString
        if (token.length > 0) {
        return token
        }
        return "NO TOKEN !"; //incase this is being added to a params dictionary
    }
    
    func logoutUser()
    {
        var storage : NSHTTPCookieStorage = NSHTTPCookieStorage.sharedHTTPCookieStorage()
        for cookie in storage.cookies  as! [NSHTTPCookie]{
            storage.deleteCookie(cookie)
        }
        NSUserDefaults.standardUserDefaults()
        
        NSUserDefaults.standardUserDefaults().removeObjectForKey(kLODAuthToken)
        NSUserDefaults.standardUserDefaults().removeObjectForKey(kLODFacebookInfo)
        NSUserDefaults.standardUserDefaults().removeObjectForKey(kLODCurrentUser)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    func currentUser()-> User
    {
        var user:User = User()
        var userData:NSData? = NSUserDefaults.standardUserDefaults().objectForKey(kLODCurrentUser) as? NSData
        if let userDataInfo = userData
        {
            user = NSKeyedUnarchiver.unarchiveObjectWithData(userDataInfo) as! User
        }
        return user
    }

}
