//
//  WebConstants.swift
//  Quicklegal
//
//  Created by Bigscal Mini on 11/03/15.
//  Copyright (c) 2015 Bigscal Mini. All rights reserved.
//

import Foundation

//URL
let kBaseURL =                                    "https://www.quicklegal.com"
//let kBaseURL =                                   "http://staging.quicklegal.com"//"http://www.quicklegal.com" //"http://52.4.4.110"
//let kBaseURL =                                   "http://192.168.1.15:3000" // Development
let kattorney =                                  "/api/attorneys"
//pragma mark - API Parameter Keys
let kAccountRoot =                               "api_attorney"
let kAttorneyContactRoot =                       "attorney_contact"
let kAttorneyEventRoot =                         "attorney_event"
let kAccountEmail  =                             "email"
let kAccountFirstName =                          "first_name"
let kAccountLastName  =                          "last_name"
let kAccountPhone =                              "phone"
let kAccountPassword =                           "password"
let kAccountState  =                             "state"
let kAccountCity   =                             "city"
let kAccountZipcode  =                           "zip"
let kAccountHeardUs  =                           "heard_us"
let kAccountReferral  =                          "referral_answer"
let kAccountSpeciality  =                        "specialties"
let kAccountStreetName  =                        "street_name"

let kAccountBio =                                "bio"
let kAccountYearLicense =                        "year_license"
let kAccountSchool =                             "school"
let kAccountQualifications =                     "qualifications"
let kAccountPracticeState =                      "practice_state"
let kAccountProfileImage =                       "profileImage"

let kAccountCurrentPassword =                    "current_password"
let kAccountDeviceToken =                        "device_token"
let kAccountDevicePlatform =                     "device_platform"
let kAccountFacebookID =                         "uid"
let kAccountFacebookAccessToken =                "access_token"
let kAccountFacebookInfoRoot =                   "authentications_attributes"
let kAccountProvider =                           "provider"
let kAccountProviderFacebook =                   "facebook"

let LOD_ForgotPasswordAccountPath =              "/api/accounts/password"

//Common Keys
let kEmailKey =                                  "email"
let kFirstNameKey =                              "first_name"
let kLastNameKey =                               "last_name"
let kPhoneNumberKey =                            "phone_number"
let kSpecialtyKey =                              "specialty"
let kSpecialtyID =                               "specialty_id"
let kMessage =                                   "message"
let kGeoLocation =                               "geo_location"
let kAmount =                                    "amount"
let kStripeToken =                               "payment_token"
let kStarRating =                                "stars"
let kReviewLawyerRoot =                          "review"
let kReviewComment =                             "comment"
let kDevicePlatformIOS =                         "ios"
let kAttorneyIDKey =                             "attorney_id"

// Keys For Contact
let KWorkContactKey =                            "work_contact"
let KPersonalContactKey =                        "personal_contact"
let KAddressKey =                                "address"
let KEmailKey =                                  "email"
let KDesignationKey =                            "designation"
let KAdditionalInfosKey =                        "additional_infos"
let KNotesKey =                                  "notes"
let KProfileImageKey =                           "profile_image"
let KBillingPerHoursKey =                        "billing_per_hours"
let KWebsiteKey =                                "website"

// Key for event
let KCalendarTypeKey =                           "calendar_type"
let KEventNameKey =                              "event_name"
let KStartDatetimeKey =                          "start_datetime"
let KEndDatetimeKey =                            "end_datetime"
let KRepeatsTypeKey  =                           "repeats_type"
let KMatterKey =                                 "matter_id"
let KDateKey =                                   "date"
let KDurationKey =                               "duration"
let KLocationKey  =                              "location"
let KDescriptionKey =                            "description"
let KEventDescriptionKey =                       "event_description"
let KInviteesKey  =                              "invitees"
let KRecurrenceTypeKey =                         "recurrence_type"
let KRepeatEveryKey =                            "repeat_every"
let KEndTypeKey =                                "end_type"
let KEndValueKey =                               "end_value"
let KRepeatOnTypeKey =                           "repeat_on_type"
let KRepeatValueKey =                            "repeat_value"
let KReminderTimeKey =                           "reminder_time"
let KReminderTimeValueKey =                      "reminder_time_value"
let KActivityDescriptionKey =                    "activity_description"
let KRateKey =                                   "rate"
let KStartTimeKey =                              "status"
let KCalendarId =                                "calendar_id"

//Key for question
let KQuestionKey =                               "question"
let KQuestionIdKey =                             "question_id"
let KSubjectKey =                                "subject"
let KQuestionDescriptionKey =                    "description"
let KStatusKey =                                 "status"
let KLastReplierIdKey =                          "last_replier_id"
let KUsStateKey =                                "us_state"
let KAdversePartiesKey =                         "adverse_parties"
let KSpecialtyNameKey =                          "specialty_name"
let KCreatedAtKey =                              "created_at"
let KUserKey =                                   "user"
let KUserIdKey =                                 "id"

//Key for call
let KMessage =                                   "message"
let KDialNumber =                                "dial_number"
let KEmailId =                                   "email_id"
let KCallIdKey =                                 "call_id"
let KCallTypeKey =                               "call_type"
let KCallStatusKey =                             "status"
let KCallDurationKey =                           "duration"
let KStatusSuccess =                             "success"
let KStatusFail =                                "fail"
let KStatusPendding =                            "pending"
let KStatusRejected =                            "rejected"

//Key for question reply
let KReplyKey =                                  "reply"
let KReplyIdKey =                                "id"
let KMessageKey =                                "message"
let KMessageImageUrlKey =                        "message_image_url"
let KReplierKey =                                "replier"
let KReplierIdKey =                              "id"
let KProfileImageUrlKey =                        "profile_image_url"
let KTypeKey =                                   "type"

//Key for group
let KGroupRootKey =                              "group"
let KGroupNameKey =                              "group_name"
let KGroupMembersKey =                           "group_members"

//Key for sub user
let KSubUser =                                   "sub_user"
let KSubUserType =                               "sub_user_type"
let KSubUserMessage =                            "message"
let KSubUserEmail =                              "email"
let KGroupId =                                   "group_id"
let KSubuserPhone =                              "phone"
let KSubUserPermission =                         "permission"
let KSubUserFirstName =                          "first_name"
let KSubUserLastName =                           "last_name"

// Key for Task
    // Key for reminder
let Kreminder_time =                             "reminder_time"
let Kreminder_time_value =                       "reminder_time_value"
    // Key for task activity 
let Kactivity_description =                      "activity_description"
let Krate =                                      "rate"
let Kstatus =                                    "status"
let Kdate =                                      "date"
let Ktimer_start_date =                          "timer_start_date"
let Kduration =                                  "duration"
let KAssignee =                                  "assignee"

//Key for Time Entry
let Kactivity_description_id =                   "activity_description_id"
let KTimeEntry_RootKey =                         "time_entry"

//Key for matter
let KbillUser =                                  "User"
let KbillUserId =                                "billing_receiptant_id"
let KbillRate =                                  "billing_rate"

//Calendar
let KCalendarRoot =                              "calendar"
let KTitle =                                     "title"

//Document
let KCategoryName =                              "name"
let KCategoryRootKey =                           "document_category"
let KdocementRootKey =                           "document"
let KDocName =                                   "name"
let KDocReceivedDate =                           "received_date"
let KDocCatId =                                  "document_category_id"
let KFileSize =                                  "file_size"
let KDocType =                                   "document_type"
let KDocUploadUrl =                              "upload_url"

let KFolderName =                                "name"
let KParentId =                                  "parent_id"
let KFullPathUrl =                               "full_storage_path"
let KMoveFrom =                                  "move_from"
let KMoveTo =                                    "move_to"


//API End Points
let LOD_LoginAccountPath =                       "/api/attorneys/login"
let LOD_CreateAccountPath =                      "/api/attorneys"
let LOD_ReferralList =                           "/api/referral_answers"
let LOD_LogoutAttorney =                         "/api/attorneys/logout"
let LOD_SpecialtiesList =                        "/api/specialties"
//Api end point for contact
let LOD_CreateContact =                          "/api/attorney_ql/attorney_contacts"
let LOD_Contacts =                               "/api/attorney_ql/attorney_contacts"
let LOD_GetContactInfo =                         "/api/attorney_ql/attorney_contacts/%d"
let LOD_DeleteContact =                          "/api/attorney_ql/attorney_contacts/%d"
let LOD_EditContact =                            "/api/attorney_ql/attorney_contacts/%d"
let LOD_ContactInvite =                          "/api/attorney_ql/attorney_contacts/invite"

//Api end point for event
let LOD_CreateEvent =                            "/api/attorney_ql/events"
let LOD_GetAllEvents =                           "/api/attorney_ql/events"
let LOD_DeleteEvent =                            "/api/attorney_ql/events/%@"
let LOD_GetEventById =                           "/api/attorney_ql/events/%@"
let LOD_EditEvent =                              "/api/attorney_ql/events/%@"
//APi end Point for phone
let LOD_CreateCall =                             "/api/attorney_ql/calls"
let LOD_attorney_availble =                      "/api/attorney_ql/attorneys/go_availble"
let LOD_attorney_unavailble =                    "/api/attorney_ql/attorneys/go_unavailble"
let LOD_getToken =                               "/api/attorney_ql/calls/%@"
let LOD_StopCall =                               "/api/attorney_ql/calls/%d/stop"
let LOD_CallHistory =                            "/api/attorney_ql/attorney_contacts/%@/call_history"
let LOD_All_CallHistory =                        "/api/attorney_ql/calls/call_histories"

//Api end point for question
let LOD_ViewAllQuestion =                        "/api/attorney_ql/questions/available_question?us_state=%@"
let LOD_ViewPickedQuestion =                     "/api/attorney_ql/questions/picked_question"
let LOD_PickUpQuestion =                         "/api/attorney_ql/questions/%d/pick_up_question"
let LOD_ReplyOfQuestion =                        "/api/attorney_ql/questions/%d/replies"
let LOD_ReferQuestion =                          "/api/attorney_ql/questions/%d/refer_question"
let LOD_ChangeStatusOfQuestion =                 "/api/attorney_ql/questions/change_status"
let Lod_AddContact =                             "/api/attorney_ql/attorney_contacts/%d/add_contact"
let LOD_ViewQuestion =                           "/api/attorney_ql/questions/%d"
let LOD_ReturnToQueue  =                         "/api/attorney_ql/questions/%d/return_to_queue"

// API end point for questions
let LOD_GetQuestionHistory =                     "/api/questions"

// API end point for group
let LOD_Groups =                                 "/api/attorney_ql/groups"
let LOD_Group_Update =                           "/api/attorney_ql/groups/%d"

//API end point for SubUser
let LOD_createSubUser =                          "/api/attorney_sub_users"
let LOD_updateSubuser =                          "/api/attorney_ql/sub_users/%d"
let LOD_deleteSubUser =                          "/api/attorney_ql/sub_users/%d"
let LOD_getAllSubUser =                          "/api/attorney_ql/sub_users/sub_user_list"
let LOD_getSubUserForTask =                      "/api/attorney_ql/sub_users"

//API end point for task
let LOD_Task =                                   "/api/attorney_ql/tasks"
let LOD_Task_Update =                            "/api/attorney_ql/tasks/%d"
let LOD_Activities_List =                        "/api/attorney_ql/activity_descriptions"
let LOD_Chnage_Status =                           "/api/attorney_ql/tasks/%d/task_status"

//API end points for Time Entry
let LOD_Time_Entry =                             "/api/attorney_ql/time_entries"
let LOD_Time_Entry_Update =                      "/api/attorney_ql/time_entries/%d"
let LOD_Start_Stop_Timer =                       "/api/attorney_ql/time_entries/%d/start_stop_timer"

//API end point for matter
let LOD_createMatter =                           "/api/attorney_ql/matters"
let LOD_updateMatter =                           "/api/attorney_ql/matters/%d"
let LOD_deleteMatter =                           "/api/attorney_ql/matters/%d"
let LOD_Matter_List =                            "/api/attorney_ql/matters"
let LOD_Task_By_Matter =                         "/api/attorney_ql/tasks?matter_id=%d"
let LOD_TimeEntry_By_Matter =                    "/api/attorney_ql/time_entries?matter_id=%d"
let LOD_Event_By_Matter =                        "/api/attorney_ql/events?matter_id=%d"

//API end point for calendar
let LOD_CreateCalendar =                         "/api/attorney_ql/calendars"
let LOD_EditCalendar =                           "/api/attorney_ql/calendars/%d"
let LOD_getCalendarType =                        "/api/attorney_ql/calendars"
let LOD_getAllEventsOfCalendar =                 "/api/attorney_ql/events?calendar_id=%d"

// API end point for Notes
let LOD_createNotes =                            "/api/attorney_ql/matters/%d/notes"
let LOD_getAllNotes =                            "/api/attorney_ql/matters/%d/notes"
let LOD_deleteNotes =                            "/api/attorney_ql/matters/%d/notes/%d"
let LOD_updateNotes =                            "/api/attorney_ql/matters/%d/notes/%d"

// API end point for expense
let LOD_createExpense =                          "/api/attorney_ql/matters/%d/expense_entries"
let LOD_getAllExpenses =                         "/api/attorney_ql/matters/%d/expense_entries"
let LOD_updateExpense =                          "/api/attorney_ql/matters/%d/expense_entries/%d"
let LOD_deleteExpense =                          "/api/attorney_ql/matters/%d/expense_entries/%d"

//API end point for Activity Description
let LOD_createDescription =                      "/api/attorney_ql/activity_descriptions"

//API end point for document categery
let LOD_document_category =                      "/api/attorney_ql/document_categories"
let LOD_document_category_update =               "/api/attorney_ql/document_categories/%d"

//API end point for judicial forms
let LOD_JudicialForms =                          "/api/attorney_ql/judicial_forms"
let LOD_JudicialForm_Search =                    "/api/attorney_ql/judicial_forms/%d"
let LOD_JudicialForm_Category =                  "/api/attorney_ql/judicial_forms/judicial_categories"

//API end point for document template
let LOD_Document_Template =                      "/api/attorney_ql/document_templates"
let LOD_Document_Template_Update =               "/api/attorney_ql/document_templates/%d"

//API end point for document
let LOD_document =                               "/api/attorney_ql/documents"
let LOD_document_update =                        "/api/attorney_ql/documents/%d"
let LOD_documet_by_folder =                      "/api/attorney_ql/documents/%d/open_document"
let LOD_document_movetotrash =                   "/api/attorney_ql/documents/%d/move_to_trash"
let LOD_document_restore =                       "/api/attorney_ql/documents/%d/restore_document"
let LOD_getAll_trashedDocument =                 "/api/attorney_ql/documents/trash_document"
let LOD_MoveFolderDocument =                     "/api/attorney_ql/documents/move_document"
let LOD_document_alllist =                       "/api/attorney_ql/documents/open_move_document"

//API Endpoint for Case Timeline
let LOD_Timeline =                               "/api/attorney_ql/matters/%d/case_timelines"

//Legal research document end point
let LOD_Legal_Research_Url  =                    "https://www.ravellaw.com/search/m?query="
let CourtListenerBase_Url =                      "https://%@:%@@www.courtlistener.com%@%@"
let LOD_Search_Document =                        "/api/rest/v2/search/"//"https://%@:%@@www.courtlistener.com/?q=Jurisdictions&stat_Precedential=on&order_by=score+desc&page=7"

let LOD_TermsOfUse  =                            "http://www.quicklegal.com/pages/terms_of_use"
let LOD_PrivacyPolicy =                          "http://www.quicklegal.com/pages/privacy_policy"
let LOD_About =                                  "/api/abouts/mobile"
let QL_Video_About =                             "https://s3.amazonaws.com/my-attorney-on-demand-prod/videos/about_us.mp4"





