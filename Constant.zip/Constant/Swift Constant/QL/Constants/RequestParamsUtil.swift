//
//  RequestParamsUtil.swift
//  Quicklegal
//
//  Created by Bigscal Mini on 11/03/15.
//  Copyright (c) 2015 Bigscal Mini. All rights reserved.
//

import Foundation

class RequestParamsUtil: NSObject
{

class func createAccountParamsWithFirstName(aFirstName:NSString, aLastName:NSString,aEmail:NSString , aPassword:NSString, aState:NSString, aCity:NSString, aStreetName:NSString, aPhone:NSString, aZipdoce:NSString, aReferral:NSString, aSpeciality:NSArray ) -> NSDictionary
{
    var deviceToken:NSString? = UserManager.sharedManager.getDeviceToken();
    var accountInfo:NSDictionary = NSDictionary()
    if let deviceTokenID = deviceToken {
        accountInfo = [kAccountFirstName:aFirstName ,
            kAccountLastName:aLastName,
            kAccountEmail:aEmail,
            kAccountPassword:aPassword,
            kAccountState: aState,
            kAccountCity: aCity,
            kAccountStreetName: aStreetName,
            kAccountHeardUs: aReferral,
            kAccountPhone: aPhone,
            kAccountZipcode: aZipdoce,
            kAccountSpeciality : aSpeciality,
            kAccountDevicePlatform:kDevicePlatformIOS,
            kAccountDeviceToken:deviceTokenID
        ]
    }
    else
    {
        accountInfo = [kAccountFirstName:aFirstName ,
            kAccountLastName:aLastName,
            kAccountEmail:aEmail,
            kAccountPassword:aPassword,
            kAccountState: aState,
            kAccountCity: aCity,
            kAccountStreetName: aStreetName,
            kAccountHeardUs: aReferral,
            kAccountPhone: aPhone,
            kAccountZipcode: aZipdoce,
            kAccountSpeciality : aSpeciality,
        ]
    }
    return [kAccountRoot : accountInfo];
}
    
class func loginParamsWithEmail(aEmail:NSString?, aPassword:NSString?) -> NSDictionary
{
    var deviceToken:NSString? = UserManager.sharedManager.getDeviceToken();
    var accountInfo:NSDictionary = NSDictionary()
    if let deviceTokenID = deviceToken
    {
        accountInfo =  [ kAccountEmail:aEmail!, kAccountPassword:aPassword!, kAccountDevicePlatform:kDevicePlatformIOS, kAccountDeviceToken:deviceTokenID ]
    }
    else
    {
        accountInfo = [kAccountEmail:aEmail!, kAccountPassword:aPassword!]
    }
    
    return [kAccountRoot:accountInfo]
}
    
class func createContactParams(first_name:NSString, last_name:NSString, work_contact:NSString, personal_contact:NSString, address:NSString, email:NSString, designation:NSString, additional_info:NSString, notesOfContact:NSString, notesOfBillingPerHr:NSString, notesOfWebsite:NSString) -> NSDictionary
{
    var contactInfo:NSDictionary = NSDictionary()
    contactInfo =  [ kAccountFirstName:first_name,
                    kAccountLastName:last_name,
                    KWorkContactKey:work_contact,
                    KPersonalContactKey:personal_contact,
                    KAddressKey:address,
                    KEmailKey:email,
                    KDesignationKey:designation,
                    KAdditionalInfosKey:additional_info,
                    KNotesKey:notesOfContact,
                    KBillingPerHoursKey:notesOfBillingPerHr,
                    KWebsiteKey:notesOfWebsite,
    ]
    
    return [kAttorneyContactRoot : contactInfo]
}
    
// For call parameter
class func createCallParamsWithContact(var message:NSString, var email_id:NSString, var call_type:NSString) -> NSDictionary
{
    var callInfo:NSDictionary = NSDictionary()
    
    if(email_id != "")
    {
        callInfo = [KEmailId : email_id]
    }
    
    if(message != "" && email_id != "" && call_type != ""){
        callInfo = [KMessage : message,
            KEmailId : email_id, KCallTypeKey : call_type,
        ]
    }
    
    return callInfo
}
    
class func stopCallParamsWithContact(var status:NSString, var duration:NSString) -> NSDictionary
{
    var callInfo:NSDictionary = NSDictionary()
    callInfo = [KCallStatusKey : status, KCallDurationKey:duration];
    return callInfo
}

class func createProfileParams(first_name:NSString, last_name:NSString, city:NSString, state:NSString, streetname:NSString, zipcode:NSString, phone:NSString, school:NSString, licenseyear:NSString, qualificaitons:NSString, practicestate:NSMutableArray,  bio:NSString) -> NSDictionary
    {
        var profileInfo:NSDictionary = NSDictionary()
        profileInfo =  [ kAccountFirstName:first_name,
            kAccountLastName:last_name,
            kAccountCity:city,
            kAccountState:state,
            kAccountStreetName:streetname,
            kAccountZipcode:zipcode,
            kAccountPhone:phone,
            kAccountSchool:school,
            kAccountYearLicense:licenseyear,
            kAccountQualifications:qualificaitons,
            kAccountSpeciality:practicestate,
            kAccountBio:bio,
        ]
        return [kAccountRoot : profileInfo]
    }


class func createEventParams(var calendarType:NSString, var eventName:NSString, var startDateTime:NSDate, var endDateTime:NSDate, var repeatesType:NSString, var matter:NSString, var location:NSString, var description:NSString, var invitees:NSArray,
    // enent parameter
    var recurrenceType:NSString, var repeatEvery:NSString, var endType:NSString, var endValue:NSString,
    var repeatOnType:NSString , var repeatValue:NSString,
    // Reminder parameter
    var reminderTime:NSString, var reminderTimeValue:NSInteger, var email:NSString,
    // TimeEntry Parameter
    var activityDescription:NSString, var rate:Float, var startTime:Bool, var notes:NSString
) -> NSDictionary
{
    var eventInfo:NSDictionary = NSDictionary()
    eventInfo = [ KCalendarTypeKey:calendarType,
        KEventNameKey:eventName,
        KStartDatetimeKey : startDateTime,
        KEndDatetimeKey : endDateTime,
        KRepeatsTypeKey : repeatesType,
        KMatterKey : matter,
        KLocationKey : location,
        KDescriptionKey : description,
        KInviteesKey : invitees,
        
        KRecurrenceTypeKey:recurrenceType,
        KRepeatEveryKey:repeatEvery,
        KEndTypeKey : endType,
        KEndValueKey : endValue,
        KReminderTimeKey : reminderTime,
        KReminderTimeValueKey : reminderTimeValue,
        KEmailKey : email,
        
        KActivityDescriptionKey : activityDescription,
        KRateKey : rate,
        KStartTimeKey : startTime,
        KNotesKey : notes
    ]
    return [kAttorneyEventRoot : eventInfo]
}

class func replyMessagePram(message:NSString) -> NSDictionary {
    var replyInfo:NSDictionary = NSDictionary()
    replyInfo =  [KMessageKey:message]
    return [KReplyKey : replyInfo]
}
    
class func changeStatusOfQuestionParams(questionId:NSString, status: NSString) -> NSDictionary {
    var statusInfo:NSDictionary = NSDictionary()
    statusInfo = [KQuestionIdKey:questionId,KStatusKey:status]
    return statusInfo
}
    
// Parameter method for Call module
class func gettokenforCallPram(callId:NSString) -> NSDictionary {
    var tokenInfo:NSDictionary = NSDictionary()
    tokenInfo =  [KCallIdKey:callId]
    return tokenInfo;
}
    
class func createGroupPram(groupName:NSString, groupMembers:NSMutableArray) -> NSDictionary
{
    var groupInfo:NSDictionary = NSDictionary()
    groupInfo = [ KGroupNameKey:groupName ]
    var dic = [KGroupRootKey : groupInfo, KGroupMembersKey:groupMembers]
    return dic
}
    
class func updateGroupPram(groupName:NSString, groupMemberArray:NSMutableArray) -> NSDictionary
{
    var groupInfo:NSDictionary = NSDictionary()
    groupInfo = [ KGroupNameKey:groupName ]
    var dic = [KGroupRootKey : groupInfo, KGroupMembersKey:groupMemberArray]
    return dic
}

class func reminderForTaskParam(var reminder_time:NSString , var reminder_time_value:NSString, var email:NSString) -> NSDictionary
{
    var reminderDic = NSDictionary()
    reminderDic = [Kreminder_time : reminder_time, Kreminder_time_value:reminder_time_value, KSubUserEmail:email]
    return reminderDic
}

class func timeEntryTaskForTaskParam(var activity_description: NSString, var rate:NSString,var status:Bool,var date:NSString,var duration:NSString)->NSDictionary
{
    var timeEntryDic = NSDictionary()
    timeEntryDic = [Kactivity_description:activity_description, Krate:rate, Kstatus:status, Kdate:date, Kduration:duration]
    return timeEntryDic
}
    
class func createTimeEntryParam(var activity_description: NSString, var rate:NSString,var status:Bool,var date:NSString,var duration:NSString, var assignee:NSInteger, var notes:NSString )->NSDictionary
{
    var timeEntryDic = NSDictionary()
    timeEntryDic = [Kactivity_description_id :activity_description, Krate:rate, Kstatus:status, Kdate:date, Kduration:duration, KAssignee : assignee, KNotesKey:notes]
    return timeEntryDic
    }

    class func updateTimeEntryParam(var activity_description: NSString, var rate:NSString,var date:NSString,var duration:NSString, var assignee:NSInteger, var notes:NSString)->NSDictionary
    {
        var timeEntryDic = NSDictionary()
        timeEntryDic = [Kactivity_description_id :activity_description, Krate:rate, Kdate:date, Kduration:duration, KAssignee : assignee, KNotesKey:notes]
        return timeEntryDic
    }
    

class func timeEntryTaskForTaskParamWithoutDescription( var rate:NSString,var status:Bool,var date:NSString,var duration:NSString)->NSDictionary
{
    var timeEntryDic = NSDictionary()
    timeEntryDic = [Krate:rate, Kstatus:status, Kdate:date, Kduration:duration]
    return timeEntryDic
}
    
class func calendarParam(var calendarName:NSString)->NSDictionary
{
    var calendarDic = NSDictionary()
    calendarDic = [KTitle:calendarName]
    return [KCalendarRoot:calendarDic]
}
    
class func createDocumentCategoryParam(var categoryName:NSString)->NSDictionary
{
    var categoryDic = NSDictionary()
    categoryDic = [KCategoryName:categoryName]
    return [KCategoryRootKey:categoryDic]
}
    class func MoveDocumentParam(var moveTo:NSInteger, var moveFrom:NSInteger)->NSDictionary
    {
        var moveToDic = NSDictionary()
        moveToDic = [KMoveFrom:moveFrom, KMoveTo:moveTo]
        return moveToDic
    }
}
