//
//  APIManager.swift
//  Quicklegal
//
//  Created by Bigscal Mini on 11/03/15.
//  Copyright (c) 2015 Bigscal Mini. All rights reserved.
//

import Foundation

class APIManager: NSObject {
    
    private var client:OVCClient = OVCClient()
    
    struct Static
    {
        static var instance: APIManager?
    }
    
    class var sharedManager: APIManager
    {
        if (Static.instance == nil)
        {
            Static.instance = APIManager()
        }
        return Static.instance!
    }
    
    override init()
    {
        super.init()
        self.client = OVCClient(baseURL: NSURL(string: kBaseURL))
        if(UserManager.sharedManager.userIsAuthenticated() == true)
        {
            self.setupCurrentProfileHeader(UserManager.sharedManager.currentAuthToken())
        }
        self.client.securityPolicy.allowInvalidCertificates = true;
    }
    
    func setupCurrentProfileHeader(token:NSString)
    {
        var request:AFHTTPRequestSerializer = AFHTTPRequestSerializer()
        request.setValue(NSString(format: "Token token=\"%@\"", token) as String, forHTTPHeaderField: "Authorization")
        self.client.requestSerializer = request
    }
    
    // API for login and logged out
    func loginWithParam(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_LoginAccountPath, parameters: params as [NSObject : AnyObject], resultClass: User.classForCoder(), resultKeyPath: nil, completion: {(var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                var user:User = responseObject as! User;
                var dataSave : NSData = NSKeyedArchiver.archivedDataWithRootObject(user)
                var userdefaults : NSUserDefaults = NSUserDefaults.standardUserDefaults()
                userdefaults.setObject(dataSave, forKey: "userObject")
                userdefaults.synchronize()
                if let activeOrNot = user.account_enabled as NSString?
                {
                    if(activeOrNot.isEqualToString("disabled"))
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: "Your account not approved by admin...", delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                        var error:NSError = NSError()
                        completion(error);
                    }
                    else
                    {
                        self.setupCurrentProfileHeader(user.authToken)
                        UserManager.sharedManager.saveUser(user)
                        var user:User = UserManager.sharedManager.currentUser()
                        completion(nil)
                    }
                }
                else
                {
                    self.setupCurrentProfileHeader(user.authToken)
                    UserManager.sharedManager.saveUser(user)
                    var user:User = UserManager.sharedManager.currentUser()
                    completion(nil)
                }
            }
            else
            {
                if let response = operation?.response
                {
                    if(operation?.response.statusCode == 401)
                    {
                        if let response = operation!.responseString
                        {
                            let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                            if let d = data
                            {
                                var jsonError: NSError?
                                if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                                {
                                    var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                                    alertView.show()
                                }
                                
                            }
                        }
                    }
                }
                completion(error)
                }
            }
        )
    }
    
    // API for logout
    func logoutAttorney(completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.DELETE(LOD_LogoutAttorney, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }
    
    // Api for account
    func createAccountWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_CreateAccountPath, parameters: params as [NSObject : AnyObject], resultClass: User.classForCoder(), resultKeyPath: nil, completion: {(var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(nil)
            }
            else
            {
                completion(error)
                if let response = operation!.responseString
                {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: nil, error: &jsonError) as? [String: AnyObject]
                    {
                        if let errorDic = (json as NSDictionary).valueForKey("errors") as? NSDictionary
                        {
                            if let email = (errorDic as NSDictionary).valueForKey("email") as? NSArray
                            {
                                var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: NSString(format: "Email %@", (email.objectAtIndex(0) as! NSString) as NSString) as String, delegate: nil, cancelButtonTitle: "OK")
                                alertView.show()
                                var error:NSError = NSError(domain:KAlertViewTitle ,code:100, userInfo:nil)
                                completion(error)
                            }
                        }
                    }
                }
                }
                }
            }
        )
    }
    
    
    func listOfReferrals(completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(LOD_ReferralList, parameters: nil, resultClass: Referral.classForCoder(), resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(error,responseObject as! NSArray)
            }
            else
            {
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }

                    }
                }
            }
        }
    }
    
    func listOfSpecialities(completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(LOD_SpecialtiesList, parameters: nil, resultClass: Specialty.classForCoder(), resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(error,responseObject! as! NSArray)
            }
            else
            {
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }

            }
        }
    }
    
    // For Contact module
    func createContactWithParams(params:NSDictionary,  completionBlock completion: ((NSError!, Contact!) -> Void)!)
    {
        self.client.POST(LOD_CreateContact, parameters: params as [NSObject : AnyObject], resultClass: Contact.classForCoder(), resultKeyPath: nil, completion: {(var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                
                completion(nil, responseObject as! Contact)
            }
            else
            {
                completion(error, nil)
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }

                }
            }
            }
        )
    }
    
    func listOfContacts(url:NSString,completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, resultClass: Contact.classForCoder(), resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(error,responseObject as! NSArray)
            }
            else
            {
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
            }
        }
    }
    
    func deleteContact(contactId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteContactLink = NSString(format: LOD_DeleteContact, contactId)
        self.client.DELETE(deleteContactLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }
    
    func updateContact(params:NSDictionary, contactId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editContactLink = NSString(format: LOD_EditContact, contactId)
        self.client.PUT(editContactLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }
    
    func uploadImageRequestForImage(var image:UIImage?, var contact_id:NSInteger) ->NSMutableURLRequest?
    {
        if let aImage = image
        {
            var editContact = NSString(format: LOD_EditContact,contact_id)
            var request:NSMutableURLRequest = self.client.requestSerializer.multipartFormRequestWithMethod("PUT", URLString: NSString(format:"%@%@", kBaseURL, editContact) as String, parameters: nil, constructingBodyWithBlock: { (formData : AFMultipartFormData!) -> Void in
                formData.appendPartWithFileData(UIImageJPEGRepresentation(aImage, 1), name: NSString(format:"%@[%@]",kAttorneyContactRoot, "profile_image") as String, fileName: NSString(format:"image%f.jpg", NSDate().timeIntervalSince1970) as String, mimeType: "image/jpeg")
                }, error: nil)
            return request
        }
        return nil
    }
    
    
    func uploadImageRequestForProfileImage(var image:UIImage?, var userID:NSInteger) ->NSMutableURLRequest?
    {
        if let aImage = image
        {
            //var editContact = NSString(format: LOD_EditContact,userID)
            var request:NSMutableURLRequest = self.client.requestSerializer.multipartFormRequestWithMethod("PUT", URLString: NSString(format:"%@%@", kBaseURL,LOD_CreateAccountPath) as String, parameters: nil, constructingBodyWithBlock: { (formData : AFMultipartFormData!) -> Void in
                formData.appendPartWithFileData(UIImageJPEGRepresentation(aImage, 1), name: NSString(format:"%@[%@]",kAccountRoot, "profile_image") as String, fileName: NSString(format:"image%f.jpg", NSDate().timeIntervalSince1970) as String, mimeType: "image/jpeg")
                }, error: nil)
            return request
        }
        return nil
    }

    // Api for account
    func updateAccountWithParams(params:NSDictionary,  completionBlock completion: ((NSError!, AnyObject!) -> Void)!)
    {
        self.client.PUT(LOD_CreateAccountPath, parameters: params as [NSObject : AnyObject], resultClass: User.classForCoder(), resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?)  -> Void in
            
            if(error == nil)
            {
                completion(nil, responseObject)
                
            }
            else
            {
                completion(error, nil)
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
            }
        }
    }
    
    func generateContactInvite(param : NSDictionary, completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_ContactInvite, parameters: param as [NSObject : AnyObject], resultClass: nil, resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(nil)
            }
            else
            {
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
            }
        }
    }
    
    // For Event Module
    func createEventWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_CreateEvent, parameters: params as [NSObject : AnyObject], resultClass: nil, resultKeyPath: nil, completion: {(var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(nil)
            }
            else
            {
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
            }
            }
        )
    }
    
    func listOfEvents(var url:NSString ,completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            if let response: AnyObject = responseObject
            {
                completion(nil,responseObject as! NSArray)
            }
            else
            {
            }
            
            }) { (var operation:AFHTTPRequestOperation? , var error : NSError?) -> Void in
                
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    func deleteEvent(eventId:NSString, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteEventLink = NSString(format: LOD_DeleteEvent, eventId)
        self.client.DELETE(deleteEventLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    func updateEvent(params:NSDictionary, eventId:NSString , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editEventLink = NSString(format: LOD_EditEvent, eventId)
        self.client.PUT(editEventLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
        { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    // For call api methods
    func createCallWithParams(params:NSDictionary,  completionBlock completion: ((NSError!, Call!, NSString!) -> Void)!){
        
        self.client.POST(LOD_CreateCall, parameters: params as [NSObject : AnyObject], resultClass: Call.classForCoder() , resultKeyPath: nil, completion: {(var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
        
            if(error == nil)
            {
                completion(nil,responseObject as! Call,nil)
            }
            else
            {
                completion(error, nil, nil)
              
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
            }
            
        })

    }
   
    func stopCall(callId:Int, dic:NSDictionary ,completionBlock completion: ((NSError!, Call!) -> Void)!)
    {
        var url = NSString(format: LOD_StopCall, callId)
        self.client.POST(url as String, parameters: dic as [NSObject : AnyObject], resultClass: Call.classForCoder(), resultKeyPath: nil) {(var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(nil, responseObject as! Call)
            }
            else
            {
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
            }
 
        }
    }
    
    func getAttorneyAvailable(completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.GET(LOD_attorney_availble, parameters: nil, resultClass: User.classForCoder() , resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(nil)
            }
            else
            {
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
            }
        }
    }
    
    // API for login and logged out
    func getUserTokenForCallApi(callId:NSString,  completionBlock completion: ((NSError!, Call!) -> Void)!)
    {
        var url = NSString(format:LOD_getToken,callId)
        self.client.GET(url as String, parameters:nil , resultClass: Call.classForCoder(), resultKeyPath: nil, completion: {(var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                var call:Call = responseObject as! Call;
                completion(nil, call)
            }
            else
            {
                if(operation?.response.statusCode == 401)
                {
                    if let response = operation!.responseString
                    {
                        let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                        if let d = data
                        {
                            var jsonError: NSError?
                            if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                            {
                                var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                                alertView.show()
                            }
                            
                        }
                    }                }
                completion(error, nil)
                }
            }
        )
    }

    
    func getAttorneyUnavailable(completionBlock completion: ((NSError!) -> Void)!)
    {
        
        self.client.GET(LOD_attorney_unavailble, parameters: nil, resultClass: User.classForCoder(), resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(nil)
            }
            else
            {
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
            }
        }
    }

    func getCallHistory(var contactId:NSString , completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
         var url = NSString(format:LOD_CallHistory,contactId)
        self.client.GET(url as String, parameters: nil, resultClass: nil, resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                if let dic = responseObject as? NSDictionary
                {
                    if let message = dic.valueForKey("message") as? NSString
                    {
                        if(message.rangeOfString("there is no call between").location == NSNotFound)
                        {
                            completion(nil, responseObject as! NSArray)
                        }
                        else
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: "No Call History Available" as NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                            var error:NSError = NSError(domain:KAlertViewTitle ,code:100, userInfo:nil)
                            completion(error, nil)
                        }
                    }
                }
                else
                {
                    completion(nil, responseObject as! NSArray)
                }
            }
            else
            {
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
            }
        }
    }
    
    func getAllCallHistory(completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(LOD_All_CallHistory, parameters: nil, resultClass: nil, resultKeyPath: nil) { (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                if let dic = responseObject as? NSDictionary
                {
                    if let message = dic.valueForKey("message") as? NSString
                    {
                        if(message.rangeOfString("there is no call between").location == NSNotFound)
                        {
                            completion(nil, responseObject as! NSArray)
                        }
                        else
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: message as NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                            var error:NSError = NSError(domain:KAlertViewTitle ,code:100, userInfo:nil)
                            completion(error, nil)
                        }
                    }
                }
                else
                {
                    completion(nil, responseObject as! NSArray)
                }
            }
            else
            {
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
            }
        }
    }


    func forgotPasswordWithParams(param : NSDictionary, completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_ForgotPasswordAccountPath, parameters: param as [NSObject : AnyObject], resultClass: nil, resultKeyPath: nil) {
            (var operation:AFHTTPRequestOperation? , var responseObject:AnyObject? , var error:NSError?) -> Void in
            if(error == nil)
            {
                completion(nil)
            }
            else
            {
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
            }
        }
    }
    
    // For question api methods
    func listOfAllQuestion(var url:NSString, completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil,responseObject as! NSArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error,nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func listAllPickedQuestion(completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(LOD_ViewPickedQuestion, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil,responseObject as! NSArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error,nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func pickUpQuestion(questionId:Int, completionBlock completion: ((NSError!) -> Void)!)
    {
        var pickQuestionLinkLink = NSString(format: LOD_PickUpQuestion, questionId)
        self.client.PUT(pickQuestionLinkLink as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void
            in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func getQuestion(questionId:Int, completionBlock completion: ((NSError!, NSDictionary!) -> Void)!)
    {
        var getQuestionLink = NSString(format: LOD_ViewQuestion, questionId)
        self.client.GET(getQuestionLink as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            completion(nil,responseObject as! NSDictionary)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }

    func getAllReplyQuestion(questionId:Int, completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        var replyQuestionLink = NSString(format: LOD_ReplyOfQuestion, questionId)
        self.client.GET(replyQuestionLink as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
              completion(nil,responseObject as! NSArray)
            })
            { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func giveReplyOfQuestion(params:NSDictionary, questionId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var replyQuestionLink = NSString(format: LOD_ReplyOfQuestion, questionId)
        self.client.POST(replyQuestionLink as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }
    
    func referQuestionToSpeciality(params:NSDictionary, questionId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var referQuestionLink = NSString(format: LOD_ReferQuestion, questionId)
        self.client.PUT(referQuestionLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }        }
    }
    func changeStatusOfQuestionWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_ChangeStatusOfQuestion, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func returnToQueue(questionId:Int, completionBlock completion: ((NSError!) -> Void)!)
    {
        var returnToQueueLink = NSString(format: LOD_ReturnToQueue, questionId)
        self.client.PUT(returnToQueueLink as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void
            in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func addUserInConatct(userId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var addContactLink = NSString(format: Lod_AddContact, userId)
        self.client.POST(addContactLink as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func getAboutInfo(completionBlock completion: ((NSError!, NSDictionary!) -> Void)!)
    {
        self.client.GET(LOD_About, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            completion(nil,responseObject as! NSDictionary)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    //Group Api Calls
    func addGroupInList(dic:NSDictionary, completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_Groups as String, parameters: dic, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func getAllGroups(completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(LOD_Groups as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil, responseObject as! NSArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteGroup(groupId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteGroupLink = NSString(format: LOD_Group_Update, groupId)
        self.client.DELETE(deleteGroupLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }

    func updateGroup(params:NSDictionary, groupId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editGroupLink = NSString(format: LOD_Group_Update, groupId)
        self.client.PUT(editGroupLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    // For Sub User module
    func createSubUserWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_createSubUser, parameters: params as [NSObject : AnyObject], success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func getAllSubUser(url : NSString, completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            var array = NSMutableArray(array :responseObject as! NSArray )
            var subUserArray:NSMutableArray = NSMutableArray()
            for(var i : Int = 0; i < array.count; i++)
            {
                var subObj : SubUser = SubUser()
                var subDic = array.objectAtIndex(i) as! NSMutableDictionary
                NSLog("sub dic %@", subDic)
                if let userId = subDic.valueForKey("id") as? NSInteger
                { subObj.subUserId = userId }
                if let emailId = subDic.valueForKey("email") as? NSString
                { subObj.emailId = emailId }
                if let userType = subDic.valueForKey("sub_user_type") as? NSString
                { subObj.userType = userType }
                if let msg = subDic.valueForKey("message") as? NSString
                { subObj.message = msg }
                if let firstName = subDic.valueForKey("first_name") as? NSString
                { subObj.firstName = firstName }
                if let lastName = subDic.valueForKey("last_name") as? NSString
                { subObj.lastName = lastName }
                if let phone = subDic.valueForKey("phone") as? NSString
                { subObj.phone = phone }
                if let groups = subDic.valueForKey("groups") as? NSMutableArray
                {
                    subObj.groupNameArray = NSMutableArray()
                    subObj.groupIdArray = NSMutableArray()
                    for(var j : Int = 0; j < groups.count; j++)
                    {
                        var groupDic = groups.objectAtIndex(j) as! NSMutableDictionary
                        if let groupName = groupDic.valueForKey("group_name") as? NSString
                        {
                            subObj.groupName = groupName
                            subObj.groupNameArray.addObject(groupName)
                        }
                        if let groupId = groupDic.valueForKey("id") as? NSInteger
                        {
                            subObj.groupId = groupId
                            subObj.groupIdArray.addObject(groupId)
                        }
                    }
                }
                if let permission = subDic.valueForKey("account_permission") as? NSDictionary
                {
                    subObj.allPermissionArray = NSMutableArray(array:permission.allKeys as NSArray)
                    subObj.givenPermissionArray = NSMutableArray()
                    NSLog("allPermissionArray %@", subObj.allPermissionArray)
                    
                    for(var i:Int=0; i < subObj.allPermissionArray.count; i++)
                    {
                        if let access_management = permission.valueForKey(subObj.allPermissionArray.objectAtIndex(i) as! String) as? Bool
                        {
                            if(access_management)
                            {
                                subObj.givenPermissionArray.addObject(subObj.allPermissionArray.objectAtIndex(i) as! String)
                            }
                        }
                    }
                    NSLog("givenPermissionArray %@", subObj.givenPermissionArray)

                }
                subUserArray.addObject(subObj)
            }
            completion(nil,subUserArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteSubUser(subUserId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteSubUserLink = NSString(format: LOD_deleteSubUser, subUserId)
        self.client.DELETE(deleteSubUserLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func updateSubUser(params:NSDictionary, subUserId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editSubUserLink = NSString(format: LOD_updateSubuser, subUserId)
        self.client.PUT(editSubUserLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    // For Task Module
    func createTaskWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_Task as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func getAllTask(url:NSString ,completionBlock completion: ((NSError!, NSMutableArray!, NSArray!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            if let responseObject = responseObject as? NSArray
            {
                var taskArray = NSMutableArray()
                for(var i : Int = 0; i < responseObject.count; i++)
                {
                    var taskObj : Task = Task()
                    var taskDic = responseObject.objectAtIndex(i) as! NSMutableDictionary
                    taskObj.taskId = taskDic.valueForKey("id") as! NSInteger
                    if let name =  taskDic.valueForKey("name") as? NSString
                    {
                        taskObj.taskName = name
                    }
                    if let desc = taskDic.valueForKey("description") as? NSString
                    {
                        taskObj.taskDescription = desc
                    }
                    if let dueDate = taskDic.valueForKey("due_date") as? NSString
                    {
                        taskObj.taskDueDate = dueDate
                    }
                    if let dueType = taskDic.valueForKey("due_type") as? NSString
                    {
                        taskObj.taskDueType = dueType
                    }
                    if let priority = taskDic.valueForKey("priority") as? NSString
                    {
                        taskObj.taskPriority = priority
                    }
                    if let status = taskDic.valueForKey("status") as? NSString
                    {
                        taskObj.taskStatus = status
                    }
                    
                    var matterObj = Matter()
                    if let matterDic = taskDic.valueForKey("matter") as? NSDictionary
                    {
                        if let matterId = matterDic.valueForKey("id") as? NSInteger
                        {
                            matterObj.matterId = matterId
                        }
                        if let matterName = matterDic.valueForKey("matter_cid") as? NSString
                        {
                            matterObj.matterName = matterName
                        }
                        taskObj.taskMatter = matterObj
                    }

                    var subAssigneeUser = SubUser()
                    if let taskAssigneeDic = taskDic.valueForKey("task_assignee") as? NSDictionary
                    {
                        if let assigneeDic = taskAssigneeDic.valueForKey("assignee") as? NSDictionary
                        {
                            if let email = assigneeDic.valueForKey("email") as? NSString
                            {
                                subAssigneeUser.emailId = email
                            }
                            if let first_name = assigneeDic.valueForKey("first_name") as? NSString
                            {
                                subAssigneeUser.firstName = first_name
                            }
                            if let id = assigneeDic.valueForKey("id") as? NSInteger
                            {
                                subAssigneeUser.subUserId = id
                            }
                            taskObj.taskAssignee = subAssigneeUser
                           
                        }
                        if let taskAssigneeTypeDic = taskAssigneeDic.valueForKey("assignee_type") as? NSDictionary
                        {
                            if let type = taskAssigneeTypeDic.valueForKey("assignable_type") as? NSString
                            {
                                taskObj.taskAssignTo = type
                            }
                        }
                    }
                    
                    if let reminderList = taskDic.valueForKey("remiders") as? NSArray
                    {
                        var reminderArray = NSMutableArray()
                        for (var i = 0; i < reminderList.count ; i++)
                        {
                            var reminder = Reminder()
                            var dic = reminderList.objectAtIndex(i) as! NSDictionary
                            if let reminder_time_value = dic.valueForKey("reminder_time_value") as? NSInteger
                            {
                                reminder.reminder_time_value = reminder_time_value
                            }
                            if let reminder_time = dic.valueForKey("reminder_time") as? NSString
                            {
                                reminder.reminder_time = reminder_time as String
                            }
                            if let reminder_id = dic.valueForKey("id") as? NSInteger
                            {
                                reminder.reminder_id = NSString(format:"%d",reminder_id) as String
                            }
                            reminderArray.addObject(reminder)
                        }
                        taskObj.taskReminder = reminderArray
                    }
                
                    if let timeEntryList = taskDic.valueForKey("time_entries") as? NSArray
                    {
                        var timeEntryArray = NSMutableArray()
                        for (var i = 0; i < timeEntryList.count ; i++)
                        {
                            var timeEntry = TimeEntry()
                            var dic = timeEntryList.objectAtIndex(i) as! NSDictionary
                            if let timeEntry_id = dic.valueForKey("id") as? NSInteger
                            {
                                timeEntry.time_id = timeEntry_id
                            }
                            if let rate = dic.valueForKey("rate") as? Float
                            {
                                timeEntry.rate = rate
                            }
                            if let date = dic.valueForKey("date") as? NSString
                            {
                                timeEntry.date = date as String
                            }
                            if let duration = dic.valueForKey("duration") as? NSString
                            {
                                timeEntry.duration = duration as String
                            }
                            if let notes = dic.valueForKey("notes") as? NSString
                            {
                                timeEntry.notes = notes as String
                            }
                            
                            if let activityDescription = dic.valueForKey("activity_description") as? NSDictionary
                            {
                                if let activity_description = activityDescription.valueForKey("name") as? NSString
                                {
                                    timeEntry.activity_description = activity_description as! String
                                }
                                if let activity_description_id = activityDescription.valueForKey("id") as? NSInteger
                                {
                                    timeEntry.activity_description_id = activity_description_id
                                }
                            }
                        
                            timeEntryArray.addObject(timeEntry)
                        }
                        taskObj.taskTimeEntryArray = timeEntryArray
                    }
                    taskArray.addObject(taskObj)
                }
                completion(nil, taskArray, responseObject as NSArray)
            }
            else
            {
                completion(nil, nil, nil)
            }
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error, nil, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteTask(taskId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteTaskLink = NSString(format: LOD_Task_Update, taskId)
        self.client.DELETE(deleteTaskLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func updateTask(params:NSDictionary, taskId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editTaskLink = NSString(format: LOD_Task_Update, taskId)
        self.client.PUT(editTaskLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func changeStatusTask(params:NSDictionary, taskId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editTaskLink = NSString(format: LOD_Chnage_Status, taskId)
        self.client.POST(editTaskLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    // For Activity Description
    func createDescription(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_createDescription as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }
    
    func getAllActivityDescription(completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(LOD_Activities_List as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil, responseObject as! NSArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    // For Time Entry Module
    func createTimeEntryWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_Time_Entry as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func getAllTimeEntry(var url:NSString,completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            var timeEntryArray:NSMutableArray = NSMutableArray(array: responseObject as! NSArray)
            
                completion(nil, timeEntryArray as NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func updateTimeEntry(params:NSDictionary, timeEntryId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editTimeEntryLink = NSString(format: LOD_Time_Entry_Update, timeEntryId)
        self.client.PUT(editTimeEntryLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteTimeEntry(timeEntryId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteTimeEntryLink = NSString(format: LOD_Time_Entry_Update, timeEntryId)
        self.client.DELETE(deleteTimeEntryLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func startStopTimer(timeEntryId:NSInteger,  completionBlock completion: ((NSError!) -> Void)!)
    {
        var startStopTimerUrl = NSString(format: LOD_Start_Stop_Timer, timeEntryId)
        
        self.client.GET(startStopTimerUrl as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
        
            completion(nil)
        
        }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
        
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }

    
    // For Matter Module
    func getAllMatter(completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(LOD_Matter_List as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            if let responseObject = responseObject as? NSArray
            {
                var matterArray = NSMutableArray()
                for(var i : Int = 0; i < responseObject.count; i++)
                {
                    
                    var matterObj : Matter = Matter()
                    var matterDic = responseObject.objectAtIndex(i) as! NSMutableDictionary
                    if let matterId = matterDic.valueForKey("id") as? NSInteger
                    {
                        matterObj.matterId = matterId
                    }
                    if let name = matterDic.valueForKey("matter_cid") as? NSString
                    {
                        matterObj.matterName = name
                    }
                    if let description = matterDic.valueForKey("description") as? NSString
                    {
                        matterObj.matterDescription = description
                    }
                    if let court_appoint = matterDic.valueForKey("court_appointed") as? Bool
                    {
                        matterObj.courtAppointed = court_appoint
                    }
                    if let bail_bond = matterDic.valueForKey("bail_bond_amount") as? NSInteger
                    {
                        matterObj.bailBondAmount = bail_bond
                    }
                    if let contigency = matterDic.valueForKey("contigency") as? Bool
                    {
                        matterObj.contigency = contigency
                    }
                    if let arrestDate = matterDic.valueForKey("arrest_date") as? NSString
                    {
                        matterObj.arrestDate = arrestDate
                    }
                    if let caseNo = matterDic.valueForKey("case_number") as? NSString
                    {
                        matterObj.caseNumber = caseNo
                    }
                    if let assignee = matterDic.valueForKey("billing_receiptant") as? NSMutableDictionary
                    {
                        matterObj.assigneeDic = assignee
                    }
                    if let openDate = matterDic.valueForKey("open_date") as? NSString
                    {
                        matterObj.openDate = openDate
                    }
                    if let billable = matterDic.valueForKey("billable") as? Bool
                    {
                        matterObj.billable = billable
                    }
                    if let plea = matterDic.valueForKey("plea") as? NSString
                    {
                        matterObj.plea = plea
                    }
                    if let status = matterDic.valueForKey("status") as? NSString
                    {
                        matterObj.status = status
                    }
                    if let notes = matterDic.valueForKey("special_notes") as? NSString
                    {
                        matterObj.specialNote = notes
                    }
                    if let insuranceNo = matterDic.valueForKey("insurance_claim_number") as? NSString
                    {
                        matterObj.insuranceNo = insuranceNo
                    }
                    if let incidentDate = matterDic.valueForKey("date_of_incident") as? NSString
                    {
                        matterObj.dateOfIncident = incidentDate
                    }
                    if let fillingDate = matterDic.valueForKey("filling_date") as? NSString
                    {
                        matterObj.fillingDate = fillingDate
                    }
                    if let location = matterDic.valueForKey("location") as? NSString
                    {
                        matterObj.location = location
                    }
                    if let child = matterDic.valueForKey("no_of_children") as? NSInteger
                    {
                        matterObj.numberOfChild = child
                    }
                    if let practice = matterDic.valueForKey("specialty") as? NSDictionary
                    {
                        matterObj.practiceAreaDic = practice
                    }
                    if let county = matterDic.valueForKey("county") as? NSString
                    {
                        matterObj.county = county
                    }
                    if let charge = matterDic.valueForKey("charges") as? NSString
                    {
                        matterObj.charges = charge
                    }
                    if let arresting = matterDic.valueForKey("arresting") as? NSDictionary
                    {
                        matterObj.arrestingOfficerDic = arresting
                    }
                    if let mrgPlace = matterDic.valueForKey("place_of_marriage") as? NSString
                    {
                        matterObj.marriagePlace = mrgPlace
                    }
                    if let pendingDate = matterDic.valueForKey("pending_date") as? NSString
                    {
                        matterObj.pendingDate = pendingDate
                    }
                    if let court = matterDic.valueForKey("court") as? NSDictionary
                    {
                        matterObj.courtDic = court
                    }
                    if let prosecutor = matterDic.valueForKey("prosecutor") as? NSDictionary
                    {
                        matterObj.prosecutorDic = prosecutor
                    }
                    if let contigencyFee = matterDic.valueForKey("contigency_fee") as? NSInteger
                    {
                        matterObj.contigencyFee = contigencyFee
                    }
                    if let hearingTime = matterDic.valueForKey("hearing_time") as? NSString
                    {
                        matterObj.hearingTime = hearingTime
                    }
                    if let dateOfSep = matterDic.valueForKey("date_of_separation") as? NSString
                    {
                        matterObj.dateOfSeperation = dateOfSep
                    }
                    if let oppParty = matterDic.valueForKey("opposing_party") as? NSDictionary
                    {
                        matterObj.opposingPartyDic = oppParty
                    }
                    if let conflict = matterDic.valueForKey("conflict_check") as? Bool
                    {
                        matterObj.conflictCheck = conflict
                    }
                    if let ref = matterDic.valueForKey("referral_source") as? NSDictionary
                    {
                        matterObj.referralSourcesDic = ref
                    }
                    if let response = matterDic.valueForKey("responsible_solicitor") as? NSDictionary
                    {
                        matterObj.responsibleAttorneyDic = response
                    }
                    if let retainer = matterDic.valueForKey("retainer") as? NSInteger
                    {
                        matterObj.retainer = retainer
                    }
                    if let arrignDate = matterDic.valueForKey("arraignment_date") as? NSString
                    {
                        matterObj.arraignmentDate = arrignDate
                    }
                    if let commPref = matterDic.valueForKey("communication_preference") as? NSString
                    {
                        matterObj.communicationPreferance = commPref
                    }
                    if let origin = matterDic.valueForKey("originating_solicitor") as? NSDictionary
                    {
                        matterObj.originatingAtorneyDic = origin
                    }
                    if let circuit = matterDic.valueForKey("circuit") as? NSString
                    {
                        matterObj.circuit = circuit
                    }
                    if let mrgDate = matterDic.valueForKey("date_of_marriage") as? NSString
                    {
                        matterObj.marriageDate = mrgDate
                    }
                    if let nextDate = matterDic.valueForKey("next_court_date") as? NSString
                    {
                        matterObj.nextCourtDate = nextDate
                    }
                    if let prosEmail = matterDic.valueForKey("prosecutor_email") as? NSString
                    {
                        matterObj.prosecutorEmail = prosEmail
                    }
                    if let juryTrial = matterDic.valueForKey("jury_trial") as? Bool
                    {
                        matterObj.juryTrial = juryTrial
                    }
                    if let judge = matterDic.valueForKey("judge") as? NSDictionary
                    {
                        matterObj.judgeDic = judge
                    }
                    if let billRate = matterDic.valueForKey("billing_rate") as? NSInteger
                    {
                        matterObj.billingRate = billRate
                    }
                    if let clientRef = matterDic.valueForKey("client_reference_number") as? NSString
                    {
                        matterObj.clientReference = clientRef
                    }
                    if let billType = matterDic.valueForKey("billing_type") as? NSString
                    {
                        matterObj.billingMethod = billType
                    }
                    if let clientArr = matterDic.valueForKey("client") as? NSDictionary
                    {
                        matterObj.client = clientArr as NSDictionary
                    }
                    if let oppCounsel = matterDic.valueForKey("opposing_counsel") as? NSDictionary
                    {
                        matterObj.opposingCounselDic = oppCounsel
                    }
                    if let docket = matterDic.valueForKey("docket_link") as? NSString
                    {
                        matterObj.docketLink = docket
                    }
                    if let closeDate = matterDic.valueForKey("close_date") as? NSString
                    {
                        matterObj.closeDate = closeDate
                    }
                    if let oppCounselMail = matterDic.valueForKey("opposing_counsel_email") as? NSString
                    {
                        matterObj.opposingEmail = oppCounselMail
                    }
                    if let permission = matterDic.valueForKey("matter_permission") as? NSString
                    {
                        matterObj.matterPermission = permission
                    }
                    if let tasks = matterDic.valueForKey("tasks") as? NSMutableArray
                    {
                        matterObj.taskList = tasks.objectAtIndex(0) as? NSDictionary
                    }
                    if let reminder = matterDic.valueForKey("remiders") as? NSMutableArray
                    {
                        var reminderList = NSMutableArray()
                        for(var i:Int = 0; i<reminder.count; i++)
                        {
                            var reminderObj:Reminder = Reminder()
                            var reminderDic = reminder.objectAtIndex(i) as! NSDictionary
                            if let email = reminderDic.valueForKey("email") as? NSString
                            {
                                reminderObj.email = email as! String
                            }
                            if let reminder_time = reminderDic.valueForKey("reminder_time") as? NSString
                            {
                                reminderObj.reminder_time = reminder_time as! String
                            }
                            if let reminder_time_value = reminderDic.valueForKey("reminder_time_value") as? NSInteger
                            {
                                reminderObj.reminder_time_value = reminder_time_value
                            }
                            reminderList.addObject(reminderObj)
                        }
                        matterObj.reminderList = reminderList
                    }
                    matterArray.addObject(matterObj)
                }
                completion(nil, matterArray)
            }
            else
            {
                completion(nil, nil)
            }
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func createMatterWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_createMatter as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }
    
    func deleteMatter(matterId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteMatterLink = NSString(format: LOD_deleteMatter, matterId)
        self.client.DELETE(deleteMatterLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    func updateMatter(params:NSDictionary, matterId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editMatterLink = NSString(format: LOD_updateMatter, matterId)
        self.client.PUT(editMatterLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    //Case Timeline api
    //Docuemnt Tampltes
    func getAllCaseTimeline(caseId:NSInteger ,completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(NSString(format: LOD_Timeline, caseId) as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            var responseDic = responseObject as! NSDictionary
            NSLog("%@",responseDic)
            var caseDataArray = NSMutableArray()
            if let caseData = responseDic.valueForKey("case_log_data") as? NSArray
            {
                for(var i:Int = 0; i < caseData.count; i++)
                {
                    var caseDic = caseData.objectAtIndex(i) as! NSDictionary
                    if let caseDicDate = caseDic.valueForKey("date") as? NSString , caseDicTemp =  caseDic.valueForKey("temp") as? NSArray
                    {
                        var dic = NSMutableDictionary()
                        dic.setValue(caseDicTemp, forKey: caseDicDate as String)
                        caseDataArray.addObject(dic)
                    }
                }
            }
            NSLog("%@",caseDataArray)
            completion(nil,caseDataArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    // For Calendar Module
    func createCalendarWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_CreateCalendar as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func getAllCalendar(completionBlock completion: ((NSError!, NSArray!) -> Void)!)
    {
        self.client.GET(LOD_getCalendarType as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil, responseObject as! NSArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func updateCalendar(params:NSDictionary, calendarId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var editCalendarLink = NSString(format: LOD_EditCalendar, calendarId)
        self.client.PUT(editCalendarLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteCalendar(calendarId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteCalendarLink = NSString(format: LOD_EditCalendar, calendarId)
        self.client.DELETE(deleteCalendarLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }

    
    // For Notes Module
    func createNotesWithParams(params:NSDictionary, matterId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var createNoteLink = NSString(format: LOD_createNotes, matterId)
        self.client.POST(createNoteLink as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                    
                }
            }
        }
    }
    
    func getAllNotes(matterId:NSInteger, completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        var getAllNoteLink = NSString(format: LOD_getAllNotes, matterId)
        self.client.GET(getAllNoteLink as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            var notesArray:NSMutableArray = NSMutableArray()
            if let responseObject = responseObject as? NSArray
            {
                for(var i : Int = 0; i < responseObject.count; i++)
                {
                    var notesObj : Notes = Notes()
                    var notesDic = responseObject.objectAtIndex(i) as! NSMutableDictionary
                    notesObj.noteId = notesDic.valueForKey("id") as! NSInteger
                    if let date =  notesDic.valueForKey("note_date") as? NSString
                    {
                        notesObj.noteDate = date as String
                    }
                    if let notes =  notesDic.valueForKey("note") as? NSString
                    {
                        notesObj.noteDescription = notes as String
                    }
                    if let subject =  notesDic.valueForKey("subject") as? String
                    {
                        notesObj.noteSubject = subject as String
                    }
                    notesArray.addObject(notesObj)
                }
            }
            completion(nil, notesArray as NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func updateNotes(params:NSDictionary, matterId:NSInteger, noteId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editNoteLink = NSString(format: LOD_updateNotes, matterId, noteId)
        self.client.PUT(editNoteLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteNote(matterId:NSInteger, noteId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteNoteLink = NSString(format: LOD_deleteNotes, matterId, noteId)
        self.client.DELETE(deleteNoteLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    // For Expense Module
    func createExpenseWithParams(params:NSDictionary, matterId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var createExpLink = NSString(format: LOD_createExpense, matterId)
        self.client.POST(createExpLink as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func getAllExpense(matterId:NSInteger, completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        var getAllExpLink = NSString(format: LOD_getAllExpenses, matterId)
        self.client.GET(getAllExpLink as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            var expArray:NSMutableArray = NSMutableArray()
            if let responseObject = responseObject as? NSArray
            {
                for(var i : Int = 0; i < responseObject.count; i++)
                {
                    var expObj : Expenses = Expenses()
                    var expDic = responseObject.objectAtIndex(i) as! NSMutableDictionary
                    expObj.expenseId = expDic.valueForKey("id") as! NSInteger
                    if let date =  expDic.valueForKey("date") as? NSString
                    {
                        expObj.expDate = date as String
                    }
                    if let notes =  expDic.valueForKey("notes") as? NSString
                    {
                        expObj.expDescription = notes as String
                    }
                    if let amt =  expDic.valueForKey("amount") as? NSInteger
                    {
                        expObj.expRate = amt
                    }
                    if let assignee = expDic.valueForKey("assignee") as? NSDictionary
                    {
                        expObj.expUserDic = assignee
                    }
                    expArray.addObject(expObj)
                }
            }
            completion(nil, expArray as NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func updateExpense(params:NSDictionary, matterId:NSInteger, expId:NSInteger , completionBlock completion: ((NSError!) -> Void)!)
    {
        var editExpLink = NSString(format: LOD_updateExpense, matterId, expId)
        self.client.PUT(editExpLink as String, parameters: params, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteExpense(matterId:NSInteger, expId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteExpLink = NSString(format: LOD_deleteExpense, matterId, expId)
        self.client.DELETE(deleteExpLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }

    // For Document Category Module
    func createDocumentCategoryWithParams(params:NSDictionary, completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_document_category, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func getAllDocumetCategory(completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(LOD_document_category, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            var docArray:NSMutableArray = NSMutableArray(array:responseObject as! NSArray)
            completion(nil, docArray as NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            completion(error, nil)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func deleteDocumentCategory(documentCatId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteDocCatLink = NSString(format: LOD_document_category_update, documentCatId)
        self.client.DELETE(deleteDocCatLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    func updateDocumentCategoryWithParams(params:NSDictionary, docCatId:Int, completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.PUT(NSString(format: LOD_document_category_update, docCatId) as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }

    
    func createFolderParams(params:NSDictionary, completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_document, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    func updateFolderParams(params:NSDictionary, var documentId:NSInteger ,completionBlock completion: ((NSError!) -> Void)!)
    {
        
        var updateFolderUrl = NSString(format: LOD_document_update, documentId)
        self.client.PUT(updateFolderUrl as String, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    //For judicial form
    func getAllJudicialForms(url:NSString,completionBlock completion: ((NSError!, NSMutableDictionary!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            //var docArray:NSMutableArray = NSMutableArray(array:responseObject as! NSDictionary)
            completion(nil, responseObject as! NSMutableDictionary)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }

    //For judicial form category
    func getAllJudicialFormsCategory(completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(LOD_JudicialForm_Category, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            //var docArray:NSMutableArray = NSMutableArray(array:responseObject as! NSDictionary)
            completion(nil, responseObject as! NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }

    // For Document Module
    func createDocumentWithParam(var image:UIImage?, var param:NSDictionary, var fileName:NSString) ->NSMutableURLRequest?
    {
        if let aImage = image
        {
            var request:NSMutableURLRequest = self.client.requestSerializer.multipartFormRequestWithMethod("POST", URLString: NSString(format:"%@%@", kBaseURL,LOD_document) as String, parameters: param as [NSObject : AnyObject], constructingBodyWithBlock: { (formData : AFMultipartFormData!) -> Void in
                formData.appendPartWithFileData(UIImageJPEGRepresentation(aImage, 1), name: NSString(format:"%@", KDocUploadUrl) as String, fileName: fileName as String, mimeType: "image/jpeg")
                }, error: nil)
            return request
        }
        return nil
    }

    func getAllDocumet(var url:NSString,completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            var docArray:NSMutableArray = NSMutableArray()
            var rootDictionary:NSMutableDictionary = NSMutableDictionary()
            
            if let responseObject = responseObject as? NSArray
            {
                NSLog("%@",responseObject)
                for(var i : Int = 0; i < responseObject.count; i++)
                {
                    var documentObj : Documents = Documents()
                    var documentDic = responseObject.objectAtIndex(i) as! NSMutableDictionary
                    documentObj.documentId = documentDic.valueForKey("id") as? NSInteger
                    if let document_category_id =  documentDic.valueForKey("document_category_id") as? NSInteger
                    {
                        documentObj.documentCatId = document_category_id
                    }
                    if let catName =  documentDic.valueForKey("speciality") as? NSString
                    {
                        documentObj.documentCatName = catName
                    }
                    if let document_type =  documentDic.valueForKey("document_type") as? NSString
                    {
                        documentObj.documentType = document_type
                    }
                    if let matter = documentDic.valueForKey("matter") as? NSString
                    {
                        documentObj.caseName = matter
                    }
                    if let file_size =  documentDic.valueForKey("file_size") as? NSInteger
                    {
                        documentObj.fileSize = file_size
                    }
                    if let matter_id = documentDic.valueForKey("matter_id") as? NSInteger
                    {
                        documentObj.caseId = matter_id
                    }
                    if let parent_id = documentDic.valueForKey("parent_id") as? NSInteger
                    {
                        documentObj.parentId = parent_id
                    }
                    if let name =  documentDic.valueForKey("name") as? NSString
                    {
                        documentObj.documentName = name
                    }
                    if let received_date =  documentDic.valueForKey("received_date") as? NSString
                    {
                        documentObj.receivedDate = received_date
                    }
                    if let full_storage_path = documentDic.valueForKey("full_storage_path") as? NSString
                    {
                        documentObj.fullStoragePath = full_storage_path
                    }
                    if let urlDic = documentDic.valueForKey("upload_url") as? NSDictionary
                    {
                        if let uploadedUrl =  urlDic.valueForKey("upload_url") as? NSDictionary
                        {
                            if let url =  uploadedUrl.valueForKey("url") as? NSString
                            {
                                documentObj.url = url
                            }
                        }
                    }
                    docArray.addObject(documentObj)
                }
            }
            completion(nil, docArray as NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    func updateDocumentWithParam(var image:UIImage?, var param:NSDictionary, var fileName:NSString, var documentId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var editDocLink = NSString(format:LOD_document_update,documentId)
        self.client.PUT(editDocLink as String, parameters: param, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?)-> Void in
            completion(nil)
            
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }
    
    func deleteDocument(documentId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteDocLink = NSString(format: LOD_document_update, documentId)
        self.client.DELETE(deleteDocLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    func movetoTrashDocument(documentId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteDocLink = NSString(format: LOD_document_movetotrash, documentId)
        self.client.GET(deleteDocLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    func restoreTrashedDocument(documentId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteDocLink = NSString(format: LOD_document_restore, documentId)
        self.client.GET(deleteDocLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
            completion(error)
            if let response = operation!.responseString
            {
                let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                if let d = data
                {
                    var jsonError: NSError?
                    if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                    {
                        var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                        alertView.show()
                    }
                }
            }
        }
    }
    
    // Api for move document
    func moveDocumentWithParams(params:NSDictionary,  completionBlock completion: ((NSError!) -> Void)!)
    {
        self.client.POST(LOD_MoveFolderDocument, parameters: params, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            
            completion(nil)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                        
                    }
                }
        }
    }

    //Docuemnt Tampltes
    func getAllDocumetTepmlate(completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        self.client.GET(LOD_Document_Template, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            var docArray:NSMutableArray = NSMutableArray()
            var rootDictionary:NSMutableDictionary = NSMutableDictionary()
            
            if let responseObject = responseObject as? NSArray
            {
                NSLog("%@",responseObject)
            
                for(var i : Int = 0; i < responseObject.count; i++)
                {
                    var templateObj : Template = Template()
                    var templateDic = responseObject.objectAtIndex(i) as! NSMutableDictionary
                    templateObj.id = templateDic.valueForKey("id") as? NSInteger
                    if let specilality =  templateDic.valueForKey("speciality") as? NSString
                    {
                        templateObj.speciality = specilality
                    }
                    if let filename =  templateDic.valueForKey("filename") as? NSString
                    {
                        templateObj.filename = filename
                    }
                    if let urlDic = templateDic.valueForKey("template_url") as? NSDictionary
                    {
                        if let uploadedUrl =  urlDic.valueForKey("template_url") as? NSDictionary
                        {
                            if let url =  uploadedUrl.valueForKey("url") as? NSString
                            {
                                templateObj.template_url = url
                            }
                        }
                    }
                    docArray.addObject(templateObj)
                }
            }
            completion(nil, docArray as NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    func deleteTemplate(templateId:NSInteger, completionBlock completion: ((NSError!) -> Void)!)
    {
        var deleteTemplateLink = NSString(format: LOD_Document_Template_Update, templateId)
        self.client.DELETE(deleteTemplateLink as String, parameters: nil, success: { ( var operation:AFHTTPRequestOperation? , var responseObject:AnyObject?) -> Void in
            completion(nil)
            })
            { (var operation:AFHTTPRequestOperation? , var error:NSError?) -> Void in
                
                completion(error)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }
    
    //Document End Point // Resources
    func getDocumentResorces(url:NSString, completionBlock completion: ((NSError!, NSMutableArray!) -> Void)!)
    {
        
        self.client.GET(url as String, parameters: nil, success: { (var operation:AFHTTPRequestOperation!, var responseObject:AnyObject?) -> Void in
            var docArray:NSMutableArray = NSMutableArray()
            if let response: AnyObject = responseObject
            {
                var dicInfo = response as! NSDictionary
                if(dicInfo.count > 0)
                {
                    var docObj : CourtListener = CourtListener()
                    var objectArry:NSArray = NSArray()
                    if let objectArr = dicInfo.valueForKey("objects") as? NSArray
                    {
                        objectArry = objectArr
                    }
                    else
                    {
                        if let objectArr = dicInfo.valueForKey("object") as? NSArray
                        {
                            objectArry = objectArr
                        }
                        else
                        {
                            objectArry = NSArray(object:dicInfo)
                        }
                    }
                    
                    if let metaDic = dicInfo.valueForKey("meta") as? NSDictionary
                    {
                        if let donate = metaDic.valueForKey("donate") as? NSString
                        {
                            docObj.donate = donate
                        }
                        if let limit = metaDic.valueForKey("limit") as? NSInteger
                        {
                            docObj.limit = limit
                        }
                        if let next = metaDic.valueForKey("next") as? NSString
                        {
                            docObj.next = next
                        }
                        if let offset = metaDic.valueForKey("offset") as? NSInteger
                        {
                            docObj.offset = offset
                        }
                        if let previous = metaDic.valueForKey("previous") as? NSString
                        {
                            docObj.previous = previous
                        }
                        if let request_uri = metaDic.valueForKey("request_uri") as? NSString
                        {
                            docObj.request_uri = request_uri
                        }
                        if let total_count = metaDic.valueForKey("total_count") as? NSInteger
                        {
                            docObj.total_count = total_count
                        }
                    }
                    docArray.addObject(docObj)
                    
                    //let the_queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
                    //dispatch_apply(objectArry.count , the_queue) { i -> Void in
                    
                    for(var i : Int = 0; i < objectArry.count; i++)
                    {
                        var obj : CourtListener = CourtListener()
                        var objDic = objectArry.objectAtIndex(i) as! NSDictionary
                        if let absolute = objDic.valueForKey("absolute_url") as? NSString
                        {
                            obj.absolute_url = absolute
                        }
                        if let caseName = objDic.valueForKey("case_name") as? NSString
                        {
                            obj.caseName = caseName
                        }
                        if let caseNumber = objDic.valueForKey("case_number") as? NSString
                        {
                            obj.caseNumber = caseNumber
                        }
                        if let citation = objDic.valueForKey("citation") as? NSString
                        {
                            obj.citation = citation
                        }
                        if let citation_court = objDic.valueForKey("cite_count") as? NSInteger
                        {
                            obj.citation_count = citation_court
                        }
                        if let court = objDic.valueForKey("court") as? NSString
                        {
                            obj.court = court
                        }
                        if let court_id = objDic.valueForKey("court_id") as? NSString
                        {
                            obj.court_id = court_id
                        }
                        if let date_argued = objDic.valueForKey("date_argued") as? NSString
                        {
                            obj.date_argued = date_argued
                        }
                        if let date_file = objDic.valueForKey("date_filed") as? NSString
                        {
                            obj.date_filed = date_file
                        }
                        if let downld_url = objDic.valueForKey("download_url") as? NSString
                        {
                            obj.download_url = downld_url
                        }
                        if let duration = objDic.valueForKey("duration") as? NSString
                        {
                            obj.duration = duration
                        }
                        if let id = objDic.valueForKey("id") as? NSInteger
                        {
                            obj.id = id
                        }
                        if let judges = objDic.valueForKey("judge") as? NSString
                        {
                            obj.judges = judges
                        }
                        if let judges = objDic.valueForKey("judges") as? NSString
                        {
                            obj.judges = judges
                        }
                        if let local_path = objDic.valueForKey("local_path") as? NSString
                        {
                            obj.local_path = local_path
                        }
                        if let resource_uri = objDic.valueForKey("resource_uri") as? NSString
                        {
                            obj.resource_uri = resource_uri
                        }
                        if let score = objDic.valueForKey("score") as? Float
                        {
                            obj.score = score
                        }
                        if let snippet = objDic.valueForKey("snippet") as? NSString
                        {
                            obj.snippet = snippet
                        }
                        if let source = objDic.valueForKey("source") as? NSString
                        {
                            obj.source = source
                        }
                        if let status = objDic.valueForKey("status") as? NSString
                        {
                            obj.status = status
                        }
                        if let natureOfSuit = objDic.valueForKey("suit_nature") as? NSString
                        {
                            obj.nature_of_suit = natureOfSuit
                        }
                        if let timestamp = objDic.valueForKey("timestamp") as? NSString
                        {
                            obj.date_modified = timestamp
                        }
                        
                        
                        //For detail doc
                        if let bolcked = objDic.valueForKey("blocked") as? Bool
                        {
                            obj.blocked = bolcked
                        }
                        if let ocr = objDic.valueForKey("extracted_by_ocr") as? Bool
                        {
                            obj.extracted_by_ocr = ocr
                        }
                        if let citation = objDic.valueForKey("citation") as? NSDictionary
                        {
                            obj.citationDic = citation
                        }
                        if let court_id = objDic.valueForKey("supreme_court_db_id") as? NSInteger
                        {
                            obj.supreme_court_db_id = court_id
                        }
                        if let precedent_status = objDic.valueForKey("precedential_status") as? NSString
                        {
                            obj.precedential_status = precedent_status
                        }
                        if let docket = objDic.valueForKey("docket") as? NSString
                        {
                            obj.docket = docket
                        }
                        if let time_retrived = objDic.valueForKey("time_retrieved") as? NSString
                        {
                            obj.time_retrived = time_retrived
                        }
                        if let date_modify = objDic.valueForKey("date_modified") as? NSString
                        {
                            obj.date_modified = date_modify
                        }
                        if let date_block = objDic.valueForKey("date_blocked") as? NSString
                        {
                            obj.date_blocked = date_block
                        }
                        if let sha1 = objDic.valueForKey("sha1") as? NSString
                        {
                            obj.sha1 = sha1
                        }
                        if let date_file = objDic.valueForKey("date_filed") as? NSString
                        {
                            obj.date_filed = date_file
                        }
                        if let html = objDic.valueForKey("html") as? NSString
                        {
                            obj.html = html
                        }
                        
                        docArray.addObject(obj)
                    }
                }
            }
            completion(nil, docArray as NSMutableArray)
            
            }) { (var operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
                completion(error, nil)
                if let response = operation!.responseString
                {
                    let data = operation?.responseString.dataUsingEncoding( NSUTF8StringEncoding, allowLossyConversion: false)
                    if let d = data
                    {
                        var jsonError: NSError?
                        if let json = NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary
                        {
                            var alertView:UIAlertView = UIAlertView(title: KAlertViewTitle, message: json.valueForKey("error") as! NSString as String, delegate: nil, cancelButtonTitle: "OK")
                            alertView.show()
                        }
                    }
                }
        }
    }


}
