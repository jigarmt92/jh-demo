//
//  AppUtilities.swift
//  NationalGPRApp
//
//  Created by Bigscal on 13/09/14.
//  Copyright (c) 2014 Bigscal. All rights reserved.
//

import Foundation
import UIKit
import SystemConfiguration

class AppUtilities : NSObject{
    
    func setButtonBorder(btn: UIButton) {
        btn.layer.borderWidth = 1.0;
        btn.layer.borderColor = UIColor(red: 212/255, green: 203/255, blue: 153/255, alpha: 1.0).CGColor;
    }
    
    class func convertDateToString(var formate:NSString, var date:NSDate) -> NSString
    {
        var formatter: NSDateFormatter = NSDateFormatter()
        formatter.timeZone = NSTimeZone.systemTimeZone()
        formatter.dateFormat = formate as String
        let stringDate: NSString = formatter.stringFromDate(date)
        return stringDate
    }
    
    class func convertStringToDate(var formate:NSString, var string:NSString) -> NSDate
    {
        var formatter: NSDateFormatter = NSDateFormatter()
        formatter.timeZone = NSTimeZone.systemTimeZone()
        formatter.dateFormat = formate as String
        if let dateFromString:NSDate = formatter.dateFromString(string as String) as NSDate?
        {
            return dateFromString
        }
        return NSDate()
    }
    
    class func isValidTextFieldInfo(textfield:UITextField)->Bool
    {
        var trimmed:NSString = (textfield.text as NSString).stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        
        if((isEmpty((textfield.text)!)) || trimmed.length == 0)
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    class func isValidTextViewInfo(textview:UITextView)->Bool
    {
        var trimmed:NSString = (textview.text as NSString).stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        
        if((isEmpty((textview.text)!)) || trimmed.length == 0)
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    class func isValidButtonTitleValue(sender:UIButton, title:NSString) -> Bool
    {
        if(((sender.titleLabel!.text as NSString!).isEqualToString(title as String)) == true)
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    class func cellHightWithMessage(message: NSString) -> CGFloat {
        var expectedLabelSize = message.boundingRectWithSize(CGSizeMake(218, CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.UsesLineFragmentOrigin, attributes: [NSFontAttributeName:UIFont.systemFontOfSize(15)], context: nil)
        var height = expectedLabelSize.size.height + CGFloat(kBufferAmount)
        return height < CGFloat(kMinimumHeight) ? CGFloat(kMinimumHeight) : height
    }
    
    class func cellHightWithMessage1(message: NSString) -> CGFloat {
        var expectedLabelSize = message.boundingRectWithSize(CGSizeMake(screenSize.width, CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.UsesLineFragmentOrigin, attributes: [NSFontAttributeName:UIFont.systemFontOfSize(18)], context: nil)
        var height = expectedLabelSize.size.height + CGFloat(kBufferAmount)
        return height < CGFloat(kMinimumHeight) ? CGFloat(kMinimumHeight) : height
    }
    
    class func showErrorToTextView(txtView:UITextView)
    {
        txtView.layer.borderWidth = 1.0;
        txtView.layer.borderColor = UIColor.redColor().CGColor
    }
    
    class func clearErrorToTextView(txtView:UITextView)
    {
        txtView.layer.borderWidth = 1.0;
        txtView.layer.borderColor = UIColor.clearColor().CGColor
    }
    
    class func showErrorToButton(btn:UIButton)
    {
        btn.layer.borderWidth = 1.0;
        btn.layer.borderColor = UIColor.redColor().CGColor
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    }
    
    class func clearErrorToButton(btn:UIButton)
    {
        btn.layer.borderWidth = 1.0;
        btn.layer.borderColor = UIColor.clearColor().CGColor
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    }
    
    class func compressImage(var image:UIImage)-> UIImage
    {
        UIGraphicsBeginImageContextWithOptions(CGSizeMake(100.0, 100.0), false, UIScreen.mainScreen().scale)
        image.drawInRect(CGRectMake(0, 0, 100, 100))
        var smallImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return smallImage
    }
    
    /*========================================================
    * function Name: isValidEmailAddress
    * function Purpose: check email address is valid
    * function Parameters: testStr: NSString
    * function ReturnType: Bool
    * function Description: check email address is valid
    *=====================================================*/
    class func checkConfirmPassword(pass: String,cpass: String)->Bool
    {
        if(pass==cpass){
            return true
        }
        return false
    }
    
    /*========================================================
    * function Name: isValidEmailAddress
    * function Purpose: check email address is valid
    * function Parameters: testStr: NSString
    * function ReturnType: Bool
    * function Description: check email address is valid
    *=====================================================*/
    class func isValidEmailAddress(testStr: NSString)->Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-za-z0-9.-]+\\.[A-Za-z]{2,4}"
        var emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(testStr)
    }
    
    // Validation for website
    class func isValidWebsite(string:NSString)->Bool
    {
        let websiteRegEx = "(www\\.)[\\w\\d\\-_]+\\.\\w{2,3}(\\.\\w{2})?(/(?<=/)(?:[\\w\\d\\-./_]+)?)?"
        var websiteTest = NSPredicate(format: "SELF MATCHES %@", websiteRegEx)
        if(websiteTest.evaluateWithObject(string) == false){
            let websiteRegEx = "(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+"
            var websiteTest = NSPredicate(format: "SELF MATCHES %@", websiteRegEx)
            return websiteTest.evaluateWithObject(string)
        }
        return websiteTest.evaluateWithObject(string)
    }
    
    /*========================================================
    * function Name: ValidatePassword
    * function Purpose: check reenter password is match with above password
    * function Parameters: var strPassword:NSString,var strConfirmPassword:NSString
    * function ReturnType: nil
    * function Description: check reenter password is match with above password
    *=====================================================*/
    class func ValidatePassword(var strPassword:NSString,var strConfirmPassword:NSString) ->Bool
    {
        return  strPassword.isEqualToString(strConfirmPassword as String) as Bool
    }
    
    /*========================================================
    * function Name: isValidateMobileNumber
    * function Purpose: check mobile number is valid or not
    * function Parameters: var MobileNumber:NSString
    * function ReturnType: bool
    * function Description: check mobile number is valid or not
    *=====================================================*/
    class func isValidateMobileNumber(var MobileNumber:NSString) -> Bool
    {
        var mobileRegEx = "[0-9]{10}"
        var mobileTest = NSPredicate(format: "SELF MATCHES %@", mobileRegEx)
        return mobileTest.evaluateWithObject(MobileNumber)
    }
    
    class func isValidText(var txtString : NSString) -> Bool
    {
        var txtRegEx = "[A-Za-z ]+"
        var txtTest = NSPredicate(format: "SELF MATCHES %@", txtRegEx)
        return txtTest.evaluateWithObject(txtString)
    }
    
    class func isValidTextWithNumber(var txtString : NSString) -> Bool
    {
        var txtRegEx = "[A-Za-z0-9 ]+"
        var txtTest = NSPredicate(format: "SELF MATCHES %@", txtRegEx)
        return txtTest.evaluateWithObject(txtString)
    }
    
    /*========================================================
    * function Name: isiPad
    * function Purpose: check device is ipad or iphone
    * function Parameters: nil
    * function ReturnType: bool
    * function Description: check device is ipad or iphone
    *=====================================================*/
    class func isiPad()->Bool
    {
        return (UIDevice.currentDevice().userInterfaceIdiom == .Pad)
    }
    
    /*========================================================
    * function Name: getScreenHeight
    * function Purpose: return the screen height of device
    * function Parameters: nil
    * function ReturnType: CGFloat
    * function Description: check device is ipad or iphone
    *=====================================================*/
    class func getScreenHeight() -> CGFloat {
        var screenrect:CGRect = UIScreen.mainScreen().bounds
        return screenrect.height
    }
    
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(sizeofValue(zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(&zeroAddress) {
            SCNetworkReachabilityCreateWithAddress(nil, UnsafePointer($0)).takeRetainedValue()
        }
        
        var flags: SCNetworkReachabilityFlags = 0
        if SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) == 0 {
            return false
        }
        
        let isReachable = (flags & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        
        return (isReachable && !needsConnection) ? true : false
    }
    /*===================================================
    * function Name : paddingTextField
    * function Params: textField:UITextField!
    * fuction  Return type: none
    * function Purpose: To set textfield Padding
    ===================================================*/
    
    class func paddingTextField(textField:UITextField!, size : CGFloat)
    {
        var paddingView:UIView = UIView(frame: CGRectMake(0, 0, size, textField.frame.size.height))
        textField.leftView = paddingView
        textField.leftViewMode = UITextFieldViewMode.Always
    }
    
    //convertStringToDate24
    class func convertStringToDate24(var formate:NSString, var string:NSString) -> NSString
    {
        var formatter: NSDateFormatter = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd hh:mm:ss a"
        var dateFromString:NSDate = formatter.dateFromString(string as String)!
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let stringDate: NSString = formatter.stringFromDate(dateFromString)
        return stringDate
    }
    
    class func convertStringToDate12(var formate:NSString, var string:NSString)->NSString
    {
        var formatter: NSDateFormatter = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if let dateFromString: NSDate = formatter.dateFromString(string as String)
        {
            formatter.dateFormat = formate as String
            var stringDate: String = formatter.stringFromDate(dateFromString)
            return stringDate
        }
        return ""
    }
    
    // Compare date from call history array
    class func sortByDate(array :NSArray) -> NSArray
    {
        var sortedArray:NSArray = array.sortedArrayUsingComparator { (var activity1:AnyObject!, var activity2:AnyObject!) -> NSComparisonResult in
            var dateString1: NSString, dateString2:NSString
            dateString1 = (activity1 as! CallHistory).start_time
            dateString2 = (activity2 as! CallHistory).start_time
            return dateString2.compare(dateString1 as String)
        }
        return sortedArray;
    }
    
    class func sortLogByDate(array :NSArray) -> NSArray
    {
        var sortedArray:NSArray = array.sortedArrayUsingComparator { (var activity1:AnyObject!, var activity2:AnyObject!) -> NSComparisonResult in
            var dateString1: NSString, dateString2:NSString
            dateString1 = (activity1 as! NSDictionary).valueForKey("created_at") as! NSString
            dateString2 = (activity2 as! NSDictionary).valueForKey("created_at") as! NSString
            return dateString2.compare(dateString1 as String)
        }
        return sortedArray;
    }

    
    //Get seconds from minute
    class func secondsForMinute(minute:NSString) -> NSInteger
    {
        var array = minute.componentsSeparatedByString(":") as NSArray
        var minute = ((array.objectAtIndex(0) as! NSString).integerValue)*60
        var seconds = (array.objectAtIndex(1) as! NSString).integerValue
        return minute + seconds
    }
    
    class func removeSecondsFromDate(var date:NSString)->NSString
    {
        //yyyy-MM-dd hh:mm:ss a
        var withoutSecond = date.substringToIndex(16)
        var time = date.substringFromIndex(20)
        var dateWithoutString = NSString(format: "%@ %@", withoutSecond,time)
        return dateWithoutString
    }
    
    class func addSecondsInDate(var date:NSString)->NSString
    {
        //yyyy-MM-dd hh:mm a
        var withoutSecond = date.substringToIndex(16)
        var time = date.substringFromIndex(17)
        var dateWithoutString = NSString(format: "%@:00 %@", withoutSecond,time)
        return dateWithoutString
    }
    
    class func convertHourIntoMinute(var minute:NSString, var hour:NSString)->NSString
    {
        var minuteFromHour = (hour.integerValue) * 60
        return NSString(format: "%d",minuteFromHour + (minute.integerValue))
    }
    
    class func calculateSeconds(var startDate:NSString)-> NSInteger
    {
        //var dateInString = self.convertDateToString("yyyy-MM-dd HH:mm:ss Z", date: NSDate())
        //var endDate = self.convertStringToDate("yyyy-MM-dd'T'HH:mm:ss'Z'", string: dateInString)
        var startDate = self.convertStringToDate(STANDARD_DATE_FORMAT, string:startDate)
        var secondsBetween = startDate.timeIntervalSinceDate(NSDate())
       
        return  Int(secondsBetween)
    }
    
    class func convertNumberInFormat(var number :NSInteger)->NSString
    {
        // Create formatter
        var formatter:NSNumberFormatter = NSNumberFormatter()
        formatter.numberStyle = NSNumberFormatterStyle.DecimalStyle
        var formattedOutput:NSString = formatter.stringFromNumber(number)!
        return formattedOutput
    }
    
    class func SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(version: NSString) -> Bool {
        return UIDevice.currentDevice().systemVersion.compare(version as String,
            options: NSStringCompareOptions.NumericSearch) != NSComparisonResult.OrderedAscending
    }
}