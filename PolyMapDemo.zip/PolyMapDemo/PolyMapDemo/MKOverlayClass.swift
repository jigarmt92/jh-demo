//
//  MKOverlayClass.swift
//  PolyMapDemo
//
//  Created by Dinesh Sailor on 7/8/16.
//  Copyright © 2016 Varshaa Weblabs. All rights reserved.
//

import MapKit

class MKOverlayClass: MKOverlayRenderer
{
    var overlayImage : UIImage!
    
    init(overlay: MKOverlay, overlayImage : UIImage)
    {
        self.overlayImage = overlayImage
        super.init(overlay: overlay)
    }

    override func drawMapRect(mapRect: MKMapRect, zoomScale: MKZoomScale, inContext ctx: CGContextRef)
    {
        let imgRef : CGImageRef = self.overlayImage.CGImage!
        let theMapRect: MKMapRect = self.overlay.boundingMapRect
        let theRect: CGRect = self.rectForMapRect(theMapRect)
        
        // Rotate around top left corner
        CGContextScaleCTM(ctx, 1.0, -1.0)
        CGContextTranslateCTM(ctx, 0.0, -theRect.size.height)
        CGContextDrawImage(ctx, theRect, imgRef)
    }
}
