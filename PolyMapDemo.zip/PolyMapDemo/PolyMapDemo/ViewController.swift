//
//  ViewController.swift
//  PolyMapDemo
//
//  Created by Dinesh Sailor on 7/7/16.
//  Copyright (c) 2016 Varshaa Weblabs. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate
{

    @IBOutlet var mapView: MKMapView!
    var polygonView : MKOverlayClass!
    var arr = ([[CLLocationCoordinate2D]])()
    var imgArray : NSMutableArray = NSMutableArray()
    var imgObj : UIImage = UIImage()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.mapView.delegate = self
        
        let initialLocation = CLLocation(latitude: 49.140838, longitude: -123.127886)
        centerMapOnLocation(initialLocation)
        
         let point = [[CLLocationCoordinate2DMake(49.142677, -123.135139),
                      CLLocationCoordinate2DMake(49.142730, -123.125794),
                      CLLocationCoordinate2DMake(49.140874, -123.125805),
                      CLLocationCoordinate2DMake(49.140885, -123.135214),CLLocationCoordinate2DMake(49.142300, -123.136500)],
        
                      [CLLocationCoordinate2DMake(49.152777, -123.145226),
                      CLLocationCoordinate2DMake(49.152756, -123.135802),
                      CLLocationCoordinate2DMake(49.150952, -123.135999),
                      CLLocationCoordinate2DMake(49.150900, -123.145300),CLLocationCoordinate2DMake(49.152352, -123.146525)]]
       
        
        self.arr = point
       
        self.imgArray.addObject(UIImage(named: "images")!)
        self.imgArray.addObject(UIImage(named: "poly")!)
        
        addBoundry()
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func addBoundry()
    {
        /*var points = [CLLocationCoordinate2DMake(49.142677, -123.135139),
                      CLLocationCoordinate2DMake(49.142730, -123.125794),
                      CLLocationCoordinate2DMake(49.140874, -123.125805),
                      CLLocationCoordinate2DMake(49.140885, -123.135214),CLLocationCoordinate2DMake(49.142300, -123.136500)]
        
        var points = [CLLocationCoordinate2DMake(49.152777, -123.145226),
                      CLLocationCoordinate2DMake(49.152756, -123.135802),
                      CLLocationCoordinate2DMake(49.150952, -123.135999),
                      CLLocationCoordinate2DMake(49.150900, -123.145300),CLLocationCoordinate2DMake(49.152352, -123.146525)]*/
    
        
        for i in 0 ..< self.arr.count
        {
            var points = self.arr[i]
            
            let polygon = MKPolygon(coordinates: &points, count: points.count)
            
            self.imgObj = self.imgArray.objectAtIndex(i) as! UIImage
            
            mapView.addOverlay(polygon)
        }
        
        //let polygon = MKPolygon(coordinates: &points, count: points.count)
    
        //mapView.addOverlay(polygon)
    }
    
    
    let regionRadius: CLLocationDistance = 1000
    func centerMapOnLocation(location: CLLocation)
    {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
            regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer
    {
        if overlay is MKPolygon
        {
           // let img : UIImage = polygonView.overlayImage
            polygonView = MKOverlayClass(overlay: overlay, overlayImage: self.imgObj) //MKPolygonRenderer(overlay: overlay)
            polygonView.alpha = 0.5
            return polygonView
        }
        return polygonView
    }

}

