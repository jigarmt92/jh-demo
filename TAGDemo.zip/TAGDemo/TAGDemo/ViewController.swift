//
//  ViewController.swift
//  TAGDemo
//
//  Created by Bigscal Mini on 11/03/16.
//  Copyright © 2016 Bigscal Mini. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tag : TLTagsControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tag.tags = ["FRA","AUG"]
        self.tag.tagPlaceholder = "Jigar"
        self.tag.reloadTagSubviews()
        /*
         JGProgressHUD *HUD = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
         HUD.indicatorView = [[JGProgressHUDPieIndicatorView alloc] initWithHUDStyle:HUD.style];
         HUD.textLabel.text = @"Loading";
         [HUD showInView:self.view];
         [HUD dismissAfterDelay:3.0];
         */
        let HUD : JGProgressHUD = JGProgressHUD(style: JGProgressHUDStyle.Dark)
        HUD.indicatorView = JGProgressHUDPieIndicatorView(HUDStyle: JGProgressHUDStyle.Dark)
        HUD.textLabel.text = "Loading..."
        HUD.showInView(self.view)
        HUD.layoutChangeAnimationDuration = 0.0
        
        HUD.dismissAfterDelay(3.0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

