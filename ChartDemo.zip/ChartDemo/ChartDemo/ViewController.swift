//
//  ViewController.swift
//  ChartDemo
//
//  Created by Dinesh Sailor on 7/8/16.
//  Copyright © 2016 Varshaa Weblabs. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UUChartDataSource
{

    @IBOutlet var customView : UIView!
    
    var chartView : UUChart!
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.chartView = UUChart(frame: self.customView.bounds, dataSource: self, style: UUChartStyle.Line)
        self.chartView.showInView(self.customView)
    }

    func getXTitles(num : Int) -> NSArray {
    
        let xTitles : NSMutableArray = NSMutableArray()
        for i in 0 ..< num
        {
            let str : NSString = NSString(format: "J-%d", i)
            xTitles.addObject(str)
        }
        return xTitles
    }

    func chartConfigAxisXLabel(chart: UUChart!) -> [AnyObject]! {
        return getXTitles(7) as [AnyObject]
    }
    
    func chartConfigAxisYValue(chart: UUChart!) -> [AnyObject]! {
        let ary1 = ["22","54","15","30","42","77","43"]
        let ary2 = ["76","34","54","23","16","32","17"]
        let ary3 = ["3","12","25","55","52"]
        return [ary1, ary2, ary3]
    }
    
    func chartConfigColors(chart: UUChart!) -> [AnyObject]! {
        return [UUColor.green(), UUColor.red(), UUColor.blueColor()]
    }
    
    func chartRange(chart: UUChart!) -> CGRange {
        return CGRangeMake(100, 0)
    }
    
    func chartHighlightRangeInLine(chart: UUChart!) -> CGRange {
        return CGRangeZero
    }
    
    func chart(chart: UUChart!, showHorizonLineAtIndex index: Int) -> Bool {
        return true
    }
    
    func chart(chart: UUChart!, showMaxMinAtIndex index: Int) -> Bool {
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

