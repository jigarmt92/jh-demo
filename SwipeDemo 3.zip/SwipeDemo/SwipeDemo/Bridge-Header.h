//
//  Bridge-Header.h
//  SwipeDemo
//
//  Created by BIGSCAL on 10/13/15.
//  Copyright (c) 2015 BIGSCAL. All rights reserved.
//

#import "NSObject+Swift.h"
#import "UIColor+FlatColors.h"