//
//  ViewController.swift
//  RealmDemo
//
//  Created by sagarr on 5/31/17.
//  Copyright © 2017 sagarr. All rights reserved.
//

import UIKit
import RealmSwift

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //PATH
        print(Realm.Configuration.defaultConfiguration.fileURL?.absoluteString as Any)
    }
    
    //MARK: Add task in Realm Database
    @IBAction func btnAddTask(sender : UIButton) {
        
        let realmObj = try! Realm()
        
        try! realmObj.write {
            let taskObj = TaskModel()
            taskObj.name = "Jigar"
            taskObj.createdAt = NSDate()
            taskObj.notes = "No need of notes"
            taskObj.isCompleted = true
            realmObj.add(taskObj)
        }

    }
    
    //MARK: Display task from Realm Database
    @IBAction func btnGetTask(sender : UIButton) {
        
        let taskObj = try! Realm().objects(TaskModel.self)
        
        for i in 0..<taskObj.count
        {
            let obj = taskObj[i] as TaskModel
            
            print(obj.name)
        }
    }
    
    //MARK: Delete Task
    @IBAction func btnDeleteTask(sender : UIButton) {
        let realmObj = try! Realm()
        try! realmObj.write {
            let taskObj = try! Realm().objects(TaskModel.self)
            if taskObj.count > 0 {
                let obj = taskObj[0] as TaskModel
                realmObj.delete(obj)
                print("Deleted")
            }
        }
    }
    
    //MARK: Update Task
    @IBAction func btnUpdateTask(sender : UIButton) {
        let realmObj = try! Realm()
        try! realmObj.write {
            let taskObj = try! Realm().objects(TaskModel.self)
            if taskObj.count > 0 {
                let obj = taskObj[0] as TaskModel
                obj.setValue(false, forKey: "isCompleted")
                print("Updated")
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

