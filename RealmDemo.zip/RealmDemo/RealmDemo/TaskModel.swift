//
//  TaskModel.swift
//  RealmDemo
//
//  Created by sagarr on 5/31/17.
//  Copyright © 2017 sagarr. All rights reserved.
//

import UIKit
import RealmSwift

class TaskModel: Object {
    
   dynamic var name = ""
   dynamic var createdAt = NSDate()
   dynamic var notes = ""
   dynamic var isCompleted = false

}
