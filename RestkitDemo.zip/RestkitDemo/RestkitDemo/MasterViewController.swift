//
//  MasterViewController.swift
//  RestkitDemo
//
//  Created by Bigscal on 6/8/16.
//  Copyright © 2016 BigScal. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    var detailViewController: DetailViewController? = nil
    var objects = [AnyObject]()


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.leftBarButtonItem = self.editButtonItem()

        let addButton = UIBarButtonItem(barButtonSystemItem: .Add, target: self, action: "insertNewObject:")
        self.navigationItem.rightBarButtonItem = addButton
        if let split = self.splitViewController {
            let controllers = split.viewControllers
            self.detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
        
        // initialize AFNetworking HTTPClient
        let baseURL: NSURL = NSURL(string: "https://boxbuild-staging.clientprototype.net")!
        let client: AFHTTPClient = AFHTTPClient(baseURL: baseURL)
        
        // initialize RestKit
        let objectManager: RKObjectManager = RKObjectManager(HTTPClient: client)
        //let objectManager: RKObjectManager = RKObjectManager(baseURL: baseURL)
        
        self.configureRestKit()
        self.loadWelcomeScreen()
    }
    
    /*========================================================
    * function Name:
    * function Purpose:
    * function Parameters:
    * function ReturnType: nil
    *=======================================================*/
    func configureRestKit()
    {
        // setup object mappings
        let dataModalMapping: RKObjectMapping = RKObjectMapping(forClass: DataModal.classForCoder())
        dataModalMapping.addAttributeMappingsFromArray(["title","desciption","hero_images","buttons"])
        
        // register mappings with the provider using a response descriptor
        let responseDescriptor: RKResponseDescriptor = RKResponseDescriptor(mapping: dataModalMapping, method: .GET, pathPattern: "/api/v1/app/screens/welcome.json?client_id=1", keyPath: nil, statusCodes: NSIndexSet(index: 200))
        //objectManager.addResponseDescriptor(responseDescriptor)
        RKObjectManager.sharedManager().addResponseDescriptor(responseDescriptor)
    }
    
    /*========================================================
    * function Name:
    * function Purpose:
    * function Parameters:
    * function ReturnType: nil
    *=======================================================*/
    func loadWelcomeScreen()
    {
        RKObjectManager.sharedManager().getObjectsAtPath("/api/v1/app/screens/welcome.json?client_id=1", parameters: nil, success: { (operation, mappingResult) -> Void in
            
            }) { (opertaion, error) -> Void in
                let dict : NSMutableDictionary = try! NSJSONSerialization.JSONObjectWithData(opertaion.HTTPRequestOperation.responseData, options: NSJSONReadingOptions.MutableContainers) as! NSMutableDictionary
                print("Dictionary---------------------",dict)
    
                let dataModalObj = DataModal()
                dataModalObj.title = dict.valueForKey("title") as! NSString
                dataModalObj.desciption = dict.valueForKey("desciption") as! NSString
                dataModalObj.hero_images = dict.valueForKey("hero_images") as! NSArray
                dataModalObj.buttons = dict.valueForKey("buttons") as! NSDictionary
                
                self.objects.insert(dataModalObj, atIndex: 0)
                let indexPath = NSIndexPath(forRow: 0, inSection: 0)
                self.tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
                print("Error--------------------------",error.description)
                
                //self.getPassport()
                //self.postPassport()
                //self.updatePassport()
                //self.deletePassport()
        }
    }
    
    /*========================================================
    * function Name:
    * function Purpose:
    * function Parameters:
    * function ReturnType: nil
    *=======================================================*/
    func getPassport() {
        let objectMapping: RKObjectMapping = RKObjectMapping(forClass: Passport.classForCoder())
        objectMapping.addAttributeMappingsFromArray(["country","country_iso3","passport_number","expiry_date"])
        let responseDescriptor: RKResponseDescriptor = RKResponseDescriptor(mapping: objectMapping, method: .GET, pathPattern: "/api/v1/current_user/passports.json", keyPath: nil, statusCodes: NSIndexSet(index: 200))
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-EMAIL", value: "pushpa@bigscal.com")
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-TOKEN", value: "Zg8SsxEMg4H5z2CTVA97Yfsypm24f9L4yg")
        RKObjectManager.sharedManager().addResponseDescriptor(responseDescriptor)
        
        RKObjectManager.sharedManager().getObjectsAtPath("/api/v1/current_user/passports.json", parameters: nil, success: { (operation, result) -> Void in
                let dict = try! NSJSONSerialization.JSONObjectWithData(operation.HTTPRequestOperation.responseData, options: NSJSONReadingOptions.MutableContainers) as! NSDictionary
                print(dict)
            }) { (operation, error) -> Void in
                print("Error--------------",error.description)
        }
    }
    
    /*========================================================
    * function Name:
    * function Purpose:
    * function Parameters:
    * function ReturnType: nil
    *=======================================================*/
    func postPassport(){
        let objectMapping: RKObjectMapping = RKObjectMapping(forClass: Passport.classForCoder())
    objectMapping.addAttributeMappingsFromDictionary(["passport[country_iso3]":"country_iso3","passport[passport_number]":"passport_number","passport[expiry_date]":"expiry_date","passport[image]":"image"])
        let responseDescriptor: RKResponseDescriptor = RKResponseDescriptor(mapping: objectMapping, method: .POST, pathPattern: "/api/v1/current_user/passports.json", keyPath: nil, statusCodes: NSIndexSet(index: 200))
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-EMAIL", value: "pushpa@bigscal.com")
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-TOKEN", value: "Zg8SsxEMg4H5z2CTVA97Yfsypm24f9L4yg")
        RKObjectManager.sharedManager().addResponseDescriptor(responseDescriptor)
        
        let data = try! NSData(contentsOfURL: NSURL(string: "https://svbtleusercontent.com/tylerhayes_24609708604080_small.png")!, options: NSDataReadingOptions.DataReadingMappedAlways)
        
        let passportObj = Passport()
        passportObj.country_iso3 = "USA"
        passportObj.passport_number = "878754542121"
        passportObj.expiry_date = "2016-12-30"
        passportObj.image = data
        
        let dict = ["passport[country_iso3]":"USA","passport[passport_number]":"878754542121","passport[expiry_date]":"2016-12-30","passport[image]":data]
        RKObjectManager.sharedManager().postObject(passportObj, path: "/api/v1/current_user/passports.json", parameters: dict, success: { (operation, result) -> Void in
            let dict = try! NSJSONSerialization.JSONObjectWithData(operation.HTTPRequestOperation.responseData, options: NSJSONReadingOptions.MutableContainers)
            print("dict------------",dict)
            }) { (operation, error) -> Void in
                print("Error---------------",error.description)
        }
    }
    
    /*========================================================
    * function Name:
    * function Purpose:
    * function Parameters:
    * function ReturnType: nil
    *=======================================================*/
    func updatePassport() {
        let objectMapping: RKObjectMapping = RKObjectMapping(forClass: Passport.classForCoder())
    objectMapping.addAttributeMappingsFromDictionary(["passport[country_iso3]":"country_iso3","passport[passport_number]":"passport_number","passport[expiry_date]":"expiry_date","passport[image]":"image"])
        let responseDescriptor: RKResponseDescriptor = RKResponseDescriptor(mapping: objectMapping, method: .PATCH, pathPattern: "/api/v1/current_user/passports/103.json", keyPath: nil, statusCodes: NSIndexSet(index: 200))
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-EMAIL", value: "pushpa@bigscal.com")
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-TOKEN", value: "Zg8SsxEMg4H5z2CTVA97Yfsypm24f9L4yg")
        RKObjectManager.sharedManager().addResponseDescriptor(responseDescriptor)
        
        let data = try! NSData(contentsOfURL: NSURL(string: "https://svbtleusercontent.com/tylerhayes_24609708604080_small.png")!, options: NSDataReadingOptions.DataReadingMappedAlways)
        
        let passportObj = Passport()
        passportObj.country_iso3 = "PAK"
        passportObj.passport_number = "88888888888888"
        passportObj.expiry_date = "2016-12-30"
        passportObj.image = data
        
        let dict = ["passport[country_iso3]":"PAK","passport[passport_number]":"88888888888888","passport[expiry_date]":"2016-12-30","passport[image]":data]
        
        RKObjectManager.sharedManager().patchObject(passportObj, path: "/api/v1/current_user/passports/103.json", parameters: dict, success: { (operation, result) -> Void in
            let dict = try! NSJSONSerialization.JSONObjectWithData(operation.HTTPRequestOperation.responseData, options: NSJSONReadingOptions.MutableContainers)
            print("dict-------------",dict)
            }) { (operation, error) -> Void in
                print("Error------------",error.description)
        }
    }
    
    /*========================================================
    * function Name:
    * function Purpose:
    * function Parameters:
    * function ReturnType: nil
    *=======================================================*/
    func deletePassport() {
        let objectMapping: RKObjectMapping = RKObjectMapping(forClass: Passport.classForCoder())
        objectMapping.addAttributeMappingsFromArray(["country_iso3","country","passport_number","expiry_date"])
        let responseDescriptor: RKResponseDescriptor = RKResponseDescriptor(mapping: objectMapping, method: .DELETE, pathPattern: "/api/v1/current_user/passports/103.json", keyPath: nil, statusCodes: NSIndexSet(index: 200))
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-EMAIL", value: "pushpa@bigscal.com")
        RKObjectManager.sharedManager().HTTPClient.setDefaultHeader("X-API-TOKEN", value: "Zg8SsxEMg4H5z2CTVA97Yfsypm24f9L4yg")
        RKObjectManager.sharedManager().addResponseDescriptor(responseDescriptor)
        
        let passportObj = Passport()
        passportObj.id = 103
        
        RKObjectManager.sharedManager().deleteObject(passportObj, path: "/api/v1/current_user/passports/103.json", parameters: nil, success: { (operation, result) -> Void in
            let dict = try! NSJSONSerialization.JSONObjectWithData(operation.HTTPRequestOperation.responseData, options: NSJSONReadingOptions.MutableContainers)
            print("dict------------",dict)
            }) { (operation, error) -> Void in
                print("Error------------",error.description)
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.collapsed
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func insertNewObject(sender: AnyObject) {
        objects.insert(NSDate(), atIndex: 0)
        let indexPath = NSIndexPath(forRow: 0, inSection: 0)
        self.tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
    }

    // MARK: - Segues

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let object = objects[indexPath.row] as! DataModal //NSDate
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = object
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Table View

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objects.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)

        //let object = objects[indexPath.row] as! NSDate
        //cell.textLabel!.text = object.description
        let object = objects[indexPath.row] as! DataModal
        cell.textLabel!.text = object.title as String
        return cell
    }

    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            objects.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }


}

