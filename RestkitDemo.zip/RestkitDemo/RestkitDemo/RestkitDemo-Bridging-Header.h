//
//  RestkitDemo-Bridging-Header.h
//  RestkitDemo
//
//  Created by Bigscal on 6/8/16.
//  Copyright © 2016 BigScal. All rights reserved.
//

#ifndef RestkitDemo_Bridging_Header_h
#define RestkitDemo_Bridging_Header_h

#import <RestKit/RestKit.h>


#endif /* RestkitDemo_Bridging_Header_h */
