//
//  DataModal.swift
//  RestkitDemo
//
//  Created by Bigscal on 6/8/16.
//  Copyright © 2016 BigScal. All rights reserved.
//

import Foundation

class DataModal: NSObject {
    
    var title: NSString!
    var desciption: NSString!
    var hero_images: NSArray!
    var buttons: NSDictionary!
}

class Passport: NSObject {
    
    var country: NSString!
    var country_iso3: NSString!
    var passport_number: NSString!
    var expiry_date: NSString!
    var image: NSData!
    var id: Int!
}