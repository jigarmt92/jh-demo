//
//  DetailViewController.swift
//  RestkitDemo
//
//  Created by Bigscal on 6/8/16.
//  Copyright © 2016 BigScal. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailDescriptionLabel: UILabel!


    var detailItem: DataModal?
        {
        didSet {
            // Update the view.
            self.configureView()
        }
    }
    
    var str : NSString{
    
        didSet{
            
        }
    }

    func configureView() {
        // Update the user interface for the detail item.
        if let detail = self.detailItem {
            if let label = self.detailDescriptionLabel {
                label.text = detail.title as String
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

