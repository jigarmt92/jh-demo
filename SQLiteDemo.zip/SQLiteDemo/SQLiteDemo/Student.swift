//
//  Student.swift
//  SQLiteDemo
//
//  Created by BIGSCAL on 12/10/15.
//  Copyright © 2015 BIGSCAL. All rights reserved.
//

import UIKit

class Student : SQLTable
{
    var id = -1
    var fname = ""
    var lname = ""
    
    init() {
        super.init(tableName:"student")
    }
    
    required convenience init(tableName:String) {
        self.init()
    }
}
