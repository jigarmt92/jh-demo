//
//  AddRecordViewController.swift
//  SQLiteDemo
//
//  Created by BIGSCAL on 12/10/15.
//  Copyright © 2015 BIGSCAL. All rights reserved.
//

import UIKit

class AddRecordViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var txtFname : UITextField!
    @IBOutlet var txtLname : UITextField!
    
    var isEdit : Bool = false
    var data : Student = Student()
    let db = SQLiteDB.sharedInstance()

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if(self.isEdit == false)
        {
            self.navigationItem.title = "Add Record"
        }
        else
        {
            self.navigationItem.title = "Edit Record"
            self.txtFname.text = data.fname
            self.txtLname.text = data.lname
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func btnSaveClick(sender : UIButton)
    {
        // Validations
        if (txtFname.text!.isEmpty || txtLname.text!.isEmpty)
        {
            let alert = UIAlertView(title:"SQLiteDB", message:"Please add name first!", delegate:nil, cancelButtonTitle: "OK")
            alert.show()
        }
        
        // Save
        
        let std = Student()
        std.fname = txtFname.text!
        std.lname = txtLname.text!

        if(self.isEdit == false)
        {
            if std.save().success
            {
                let alert = UIAlertView(title:"SQLiteDB", message:"Category successfully saved!", delegate:nil, cancelButtonTitle: "OK")
                alert.show()
                self.navigationController?.popViewControllerAnimated(true)
            }
        }
        else
        {
            let sql = NSString(format: "update student set fname = '%@', lname = '%@' where id = '%d'", std.fname, std.lname, data.id)
            db.execute(sql as String)
            let alert = UIAlertView(title:"SQLiteDB", message:"Category successfully updated!", delegate:nil, cancelButtonTitle: "OK")
            alert.show()
            self.navigationController?.popViewControllerAnimated(true)
        }

    }

}
