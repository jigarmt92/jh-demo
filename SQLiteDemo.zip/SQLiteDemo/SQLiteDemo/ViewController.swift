//
//  ViewController.swift
//  SQLiteDemo
//
//  Created by BIGSCAL on 12/10/15.
//  Copyright © 2015 BIGSCAL. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tbl : UITableView!
    
    var data = [Student]()
    let db = SQLiteDB.sharedInstance()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl.delegate = self
        self.tbl.dataSource = self
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        data = Student().allRows()
        tbl.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func addClick(sender : UIBarButtonItem)
    {
        let addVC = self.storyboard?.instantiateViewControllerWithIdentifier("ADDVC") as! AddRecordViewController
        self.navigationController?.pushViewController(addVC, animated: true)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let cnt = data.count
        return cnt

    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : UITableViewCell = (UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell") as? UITableViewCell)!
        let std = data[indexPath.row]
        cell.textLabel?.text = std.fname + " " + std.lname
        return cell
    }
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if(editingStyle == UITableViewCellEditingStyle.Delete)
        {
            let std = data[indexPath.row]
            let sql = NSString(format: "delete from student where id = %d", std.id)
            db.execute(sql as String)
            data = Student().allRows()
            tbl.reloadData()
        }
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let std = data[indexPath.row]
        let addVC = self.storyboard?.instantiateViewControllerWithIdentifier("ADDVC") as! AddRecordViewController
        addVC.data = std
        addVC.isEdit = true
        self.navigationController?.pushViewController(addVC, animated: true)
    }
}

