//
//  DBManager.swift
//  SQLiteDemo
//
//  Created by BIGSCAL on 12/10/15.
//  Copyright © 2015 BIGSCAL. All rights reserved.
//

import UIKit

class DBManager: NSObject
{
    var databaseFilename : NSString!
    var documentsDirectory : NSString!

    convenience init(dbFilename: String) {
        self.init()
        // Set the documents directory path to the documentsDirectory property.
        var paths : [AnyObject] = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.ApplicationDirectory, NSSearchPathDomainMask.AllDomainsMask, true)
        self.documentsDirectory = paths[0] as! NSString
        // Keep the database filename.
        self.databaseFilename = dbFilename
        // Copy the database file into the documents directory if necessary.
        self.copy()
    }}
